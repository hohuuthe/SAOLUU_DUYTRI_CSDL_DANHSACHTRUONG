--
-- PostgreSQL database dump
--

\restrict 2DAufPS12b0sE2uWrkKeEeNIxZdYpGje7ARnbrHMbOmBgM9nwcm8ET6vFpFVbua

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS "pgrst_drop_watch";
DROP EVENT TRIGGER IF EXISTS "pgrst_ddl_watch";
DROP EVENT TRIGGER IF EXISTS "issue_pg_net_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_graphql_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_cron_access";
DROP EVENT TRIGGER IF EXISTS "issue_graphql_placeholder";
DROP EVENT TRIGGER IF EXISTS "ensure_rls";
DROP PUBLICATION IF EXISTS "supabase_realtime_messages_publication";
DROP PUBLICATION IF EXISTS "supabase_realtime";
DROP POLICY IF EXISTS "Chỉ tài khoản đăng nhập mới được xem danh sách " ON "public"."danh_sach_truong";
DROP POLICY IF EXISTS "Cho phép đọc tên miền hợp lệ" ON "public"."dia_chi_truy_cap";
DROP POLICY IF EXISTS "Cho phép tài khoản đăng nhập xóa dữ liệu" ON "public"."tai_khoan";
DROP POLICY IF EXISTS "Cho phép tài khoản đăng nhập xem dữ liệu" ON "public"."tai_khoan";
DROP POLICY IF EXISTS "Cho phép tài khoản đăng nhập toàn quyền trên dia_ch" ON "public"."dia_chi_truy_cap";
DROP POLICY IF EXISTS "Cho phép tài khoản đăng nhập toàn quyền trên danh_s" ON "public"."danh_sach_truong";
DROP POLICY IF EXISTS "Cho phép tài khoản đăng nhập thêm dữ liệu" ON "public"."tai_khoan";
DROP POLICY IF EXISTS "Cho phép tài khoản đăng nhập sửa dữ liệu" ON "public"."tai_khoan";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_upload_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_oauth_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_flow_state_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_auth_factor_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_user_id_fkey";
DROP TRIGGER IF EXISTS "update_objects_updated_at" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_objects_delete" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_buckets_delete" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "enforce_bucket_name_length_trigger" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "tr_check_filters" ON "realtime"."subscription";
DROP INDEX IF EXISTS "storage"."vector_indexes_name_bucket_id_idx";
DROP INDEX IF EXISTS "storage"."name_prefix_search";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name_lower";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name";
DROP INDEX IF EXISTS "storage"."idx_multipart_uploads_list";
DROP INDEX IF EXISTS "storage"."buckets_analytics_unique_name_idx";
DROP INDEX IF EXISTS "storage"."bucketid_objname";
DROP INDEX IF EXISTS "storage"."bname";
DROP INDEX IF EXISTS "realtime"."subscription_subscription_id_entity_filters_action_filter_selec";
DROP INDEX IF EXISTS "realtime"."messages_inserted_at_topic_index";
DROP INDEX IF EXISTS "realtime"."ix_realtime_subscription_entity";
DROP INDEX IF EXISTS "public"."idx_danh_sach_truong_slug";
DROP INDEX IF EXISTS "public"."idx_danh_sach_truong_domain";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_credential_id_key";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_expires_at_idx";
DROP INDEX IF EXISTS "auth"."users_is_anonymous_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_email_idx";
DROP INDEX IF EXISTS "auth"."users_email_partial_key";
DROP INDEX IF EXISTS "auth"."user_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."unique_phone_factor_per_user";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_pattern_idx";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_domain_idx";
DROP INDEX IF EXISTS "auth"."sessions_user_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_oauth_client_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_not_after_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_for_email_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_created_at_idx";
DROP INDEX IF EXISTS "auth"."saml_providers_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_updated_at_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_session_id_revoked_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_parent_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_user_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_idx";
DROP INDEX IF EXISTS "auth"."recovery_token_idx";
DROP INDEX IF EXISTS "auth"."reauthentication_token_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_user_id_token_type_key";
DROP INDEX IF EXISTS "auth"."one_time_tokens_token_hash_hash_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_relates_to_hash_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_user_order_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_user_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_clients_deleted_at_idx";
DROP INDEX IF EXISTS "auth"."oauth_auth_pending_exp_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_id_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_friendly_name_unique";
DROP INDEX IF EXISTS "auth"."mfa_challenge_created_at_idx";
DROP INDEX IF EXISTS "auth"."idx_users_name";
DROP INDEX IF EXISTS "auth"."idx_users_last_sign_in_at_desc";
DROP INDEX IF EXISTS "auth"."idx_users_email";
DROP INDEX IF EXISTS "auth"."idx_users_created_at_desc";
DROP INDEX IF EXISTS "auth"."idx_user_id_auth_method";
DROP INDEX IF EXISTS "auth"."idx_oauth_client_states_created_at";
DROP INDEX IF EXISTS "auth"."idx_auth_code";
DROP INDEX IF EXISTS "auth"."identities_user_id_idx";
DROP INDEX IF EXISTS "auth"."identities_email_idx";
DROP INDEX IF EXISTS "auth"."flow_state_created_at_idx";
DROP INDEX IF EXISTS "auth"."factor_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_new_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_current_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_provider_type_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_identifier_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_enabled_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_created_at_idx";
DROP INDEX IF EXISTS "auth"."confirmation_token_idx";
DROP INDEX IF EXISTS "auth"."audit_logs_instance_id_idx";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_name_key";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_vectors" DROP CONSTRAINT IF EXISTS "buckets_vectors_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_analytics" DROP CONSTRAINT IF EXISTS "buckets_analytics_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."subscription" DROP CONSTRAINT IF EXISTS "pk_subscription";
ALTER TABLE IF EXISTS "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_payload_exclusive";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_05" DROP CONSTRAINT IF EXISTS "messages_2026_05_05_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_04" DROP CONSTRAINT IF EXISTS "messages_2026_05_04_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_03" DROP CONSTRAINT IF EXISTS "messages_2026_05_03_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_02" DROP CONSTRAINT IF EXISTS "messages_2026_05_02_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_01" DROP CONSTRAINT IF EXISTS "messages_2026_05_01_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tai_khoan" DROP CONSTRAINT IF EXISTS "tai_khoan_ten_dang_nhap_key";
ALTER TABLE IF EXISTS ONLY "public"."tai_khoan" DROP CONSTRAINT IF EXISTS "tai_khoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."duytricsdl" DROP CONSTRAINT IF EXISTS "duytricsdl_pkey";
ALTER TABLE IF EXISTS ONLY "public"."dia_chi_truy_cap" DROP CONSTRAINT IF EXISTS "dia_chi_truy_cap_pkey";
ALTER TABLE IF EXISTS ONLY "public"."dia_chi_truy_cap" DROP CONSTRAINT IF EXISTS "dia_chi_truy_cap_domain_key";
ALTER TABLE IF EXISTS ONLY "public"."danh_sach_truong" DROP CONSTRAINT IF EXISTS "danh_sach_truong_slug_key";
ALTER TABLE IF EXISTS ONLY "public"."danh_sach_truong" DROP CONSTRAINT IF EXISTS "danh_sach_truong_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_phone_key";
ALTER TABLE IF EXISTS ONLY "auth"."sso_providers" DROP CONSTRAINT IF EXISTS "sso_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_entity_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_token_unique";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_client_unique";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_clients" DROP CONSTRAINT IF EXISTS "oauth_clients_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_client_states" DROP CONSTRAINT IF EXISTS "oauth_client_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_code_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_last_challenged_at_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_authentication_method_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."instances" DROP CONSTRAINT IF EXISTS "instances_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_provider_id_provider_unique";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."flow_state" DROP CONSTRAINT IF EXISTS "flow_state_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_identifier_key";
ALTER TABLE IF EXISTS ONLY "auth"."audit_log_entries" DROP CONSTRAINT IF EXISTS "audit_log_entries_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "amr_id_pk";
ALTER TABLE IF EXISTS "auth"."refresh_tokens" ALTER COLUMN "id" DROP DEFAULT;
DROP TABLE IF EXISTS "storage"."vector_indexes";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads_parts";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads";
DROP TABLE IF EXISTS "storage"."objects";
DROP TABLE IF EXISTS "storage"."migrations";
DROP TABLE IF EXISTS "storage"."buckets_vectors";
DROP TABLE IF EXISTS "storage"."buckets_analytics";
DROP TABLE IF EXISTS "storage"."buckets";
DROP TABLE IF EXISTS "realtime"."subscription";
DROP TABLE IF EXISTS "realtime"."schema_migrations";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_05";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_04";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_03";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_02";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_01";
DROP TABLE IF EXISTS "realtime"."messages";
DROP TABLE IF EXISTS "public"."tai_khoan";
DROP TABLE IF EXISTS "public"."duytricsdl";
DROP TABLE IF EXISTS "public"."dia_chi_truy_cap";
DROP TABLE IF EXISTS "public"."danh_sach_truong";
DROP TABLE IF EXISTS "auth"."webauthn_credentials";
DROP TABLE IF EXISTS "auth"."webauthn_challenges";
DROP TABLE IF EXISTS "auth"."users";
DROP TABLE IF EXISTS "auth"."sso_providers";
DROP TABLE IF EXISTS "auth"."sso_domains";
DROP TABLE IF EXISTS "auth"."sessions";
DROP TABLE IF EXISTS "auth"."schema_migrations";
DROP TABLE IF EXISTS "auth"."saml_relay_states";
DROP TABLE IF EXISTS "auth"."saml_providers";
DROP SEQUENCE IF EXISTS "auth"."refresh_tokens_id_seq";
DROP TABLE IF EXISTS "auth"."refresh_tokens";
DROP TABLE IF EXISTS "auth"."one_time_tokens";
DROP TABLE IF EXISTS "auth"."oauth_consents";
DROP TABLE IF EXISTS "auth"."oauth_clients";
DROP TABLE IF EXISTS "auth"."oauth_client_states";
DROP TABLE IF EXISTS "auth"."oauth_authorizations";
DROP TABLE IF EXISTS "auth"."mfa_factors";
DROP TABLE IF EXISTS "auth"."mfa_challenges";
DROP TABLE IF EXISTS "auth"."mfa_amr_claims";
DROP TABLE IF EXISTS "auth"."instances";
DROP TABLE IF EXISTS "auth"."identities";
DROP TABLE IF EXISTS "auth"."flow_state";
DROP TABLE IF EXISTS "auth"."custom_oauth_providers";
DROP TABLE IF EXISTS "auth"."audit_log_entries";
DROP FUNCTION IF EXISTS "storage"."update_updated_at_column"();
DROP FUNCTION IF EXISTS "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text");
DROP FUNCTION IF EXISTS "storage"."protect_delete"();
DROP FUNCTION IF EXISTS "storage"."operation"();
DROP FUNCTION IF EXISTS "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text");
DROP FUNCTION IF EXISTS "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text");
DROP FUNCTION IF EXISTS "storage"."get_size_by_bucket"();
DROP FUNCTION IF EXISTS "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text");
DROP FUNCTION IF EXISTS "storage"."foldername"("name" "text");
DROP FUNCTION IF EXISTS "storage"."filename"("name" "text");
DROP FUNCTION IF EXISTS "storage"."extension"("name" "text");
DROP FUNCTION IF EXISTS "storage"."enforce_bucket_name_length"();
DROP FUNCTION IF EXISTS "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb");
DROP FUNCTION IF EXISTS "storage"."allow_only_operation"("expected_operation" "text");
DROP FUNCTION IF EXISTS "storage"."allow_any_operation"("expected_operations" "text"[]);
DROP FUNCTION IF EXISTS "realtime"."wal2json_escape_identifier"("name" "text");
DROP FUNCTION IF EXISTS "realtime"."topic"();
DROP FUNCTION IF EXISTS "realtime"."to_regrole"("role_name" "text");
DROP FUNCTION IF EXISTS "realtime"."subscription_check_filters"();
DROP FUNCTION IF EXISTS "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."quote_wal2json"("entity" "regclass");
DROP FUNCTION IF EXISTS "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text");
DROP FUNCTION IF EXISTS "realtime"."cast"("val" "text", "type_" "regtype");
DROP FUNCTION IF EXISTS "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]);
DROP FUNCTION IF EXISTS "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text");
DROP FUNCTION IF EXISTS "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "public"."verify_custom_login"("p_username" "text", "p_password" "text");
DROP FUNCTION IF EXISTS "public"."rls_auto_enable"();
DROP FUNCTION IF EXISTS "public"."hash_password"("p_password" "text");
DROP FUNCTION IF EXISTS "pgbouncer"."get_auth"("p_usename" "text");
DROP FUNCTION IF EXISTS "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb");
DROP FUNCTION IF EXISTS "extensions"."set_graphql_placeholder"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_drop_watch"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_ddl_watch"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_net_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_graphql_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_cron_access"();
DROP FUNCTION IF EXISTS "auth"."uid"();
DROP FUNCTION IF EXISTS "auth"."role"();
DROP FUNCTION IF EXISTS "auth"."jwt"();
DROP FUNCTION IF EXISTS "auth"."email"();
DROP TYPE IF EXISTS "storage"."buckettype";
DROP TYPE IF EXISTS "realtime"."wal_rls";
DROP TYPE IF EXISTS "realtime"."wal_column";
DROP TYPE IF EXISTS "realtime"."user_defined_filter";
DROP TYPE IF EXISTS "realtime"."equality_op";
DROP TYPE IF EXISTS "realtime"."action";
DROP TYPE IF EXISTS "auth"."one_time_token_type";
DROP TYPE IF EXISTS "auth"."oauth_response_type";
DROP TYPE IF EXISTS "auth"."oauth_registration_type";
DROP TYPE IF EXISTS "auth"."oauth_client_type";
DROP TYPE IF EXISTS "auth"."oauth_authorization_status";
DROP TYPE IF EXISTS "auth"."factor_type";
DROP TYPE IF EXISTS "auth"."factor_status";
DROP TYPE IF EXISTS "auth"."code_challenge_method";
DROP TYPE IF EXISTS "auth"."aal_level";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "supabase_vault";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP SCHEMA IF EXISTS "vault";
DROP SCHEMA IF EXISTS "storage";
DROP SCHEMA IF EXISTS "realtime";
DROP SCHEMA IF EXISTS "pgbouncer";
DROP SCHEMA IF EXISTS "graphql_public";
DROP SCHEMA IF EXISTS "graphql";
DROP SCHEMA IF EXISTS "extensions";
DROP SCHEMA IF EXISTS "auth";
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "extensions";


ALTER SCHEMA "extensions" OWNER TO "postgres";

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql";


ALTER SCHEMA "graphql" OWNER TO "supabase_admin";

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql_public";


ALTER SCHEMA "graphql_public" OWNER TO "supabase_admin";

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA "pgbouncer";


ALTER SCHEMA "pgbouncer" OWNER TO "pgbouncer";

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "realtime";


ALTER SCHEMA "realtime" OWNER TO "supabase_admin";

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "vault";


ALTER SCHEMA "vault" OWNER TO "supabase_admin";

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";


--
-- Name: EXTENSION "supabase_vault"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "supabase_vault" IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."aal_level" AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE "auth"."aal_level" OWNER TO "supabase_auth_admin";

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."code_challenge_method" AS ENUM (
    's256',
    'plain'
);


ALTER TYPE "auth"."code_challenge_method" OWNER TO "supabase_auth_admin";

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_status" AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE "auth"."factor_status" OWNER TO "supabase_auth_admin";

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_type" AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE "auth"."factor_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_authorization_status" AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE "auth"."oauth_authorization_status" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_client_type" AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE "auth"."oauth_client_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_registration_type" AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE "auth"."oauth_registration_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_response_type" AS ENUM (
    'code'
);


ALTER TYPE "auth"."oauth_response_type" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."one_time_token_type" AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE "auth"."one_time_token_type" OWNER TO "supabase_auth_admin";

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."action" AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE "realtime"."action" OWNER TO "supabase_admin";

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."equality_op" AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE "realtime"."equality_op" OWNER TO "supabase_admin";

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."user_defined_filter" AS (
	"column_name" "text",
	"op" "realtime"."equality_op",
	"value" "text"
);


ALTER TYPE "realtime"."user_defined_filter" OWNER TO "supabase_admin";

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_column" AS (
	"name" "text",
	"type_name" "text",
	"type_oid" "oid",
	"value" "jsonb",
	"is_pkey" boolean,
	"is_selectable" boolean
);


ALTER TYPE "realtime"."wal_column" OWNER TO "supabase_admin";

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_rls" AS (
	"wal" "jsonb",
	"is_rls_enabled" boolean,
	"subscription_ids" "uuid"[],
	"errors" "text"[]
);


ALTER TYPE "realtime"."wal_rls" OWNER TO "supabase_admin";

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE "storage"."buckettype" AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE "storage"."buckettype" OWNER TO "supabase_storage_admin";

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "email"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "role"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "uid"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_cron_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_cron_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_cron_access"() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_graphql_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


ALTER FUNCTION "extensions"."grant_pg_graphql_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_graphql_access"() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_net_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_net_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_net_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_net_access"() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_ddl_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_ddl_watch"() OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_drop_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_drop_watch"() OWNER TO "supabase_admin";

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."set_graphql_placeholder"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION "extensions"."set_graphql_placeholder"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."set_graphql_placeholder"() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql("text", "text", "jsonb", "jsonb"); Type: FUNCTION; Schema: graphql_public; Owner: supabase_admin
--

CREATE FUNCTION "graphql_public"."graphql"("operationName" "text" DEFAULT NULL::"text", "query" "text" DEFAULT NULL::"text", "variables" "jsonb" DEFAULT NULL::"jsonb", "extensions" "jsonb" DEFAULT NULL::"jsonb") RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


ALTER FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") OWNER TO "supabase_admin";

--
-- Name: get_auth("text"); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION "pgbouncer"."get_auth"("p_usename" "text") RETURNS TABLE("username" "text", "password" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION "pgbouncer"."get_auth"("p_usename" "text") OWNER TO "supabase_admin";

--
-- Name: hash_password("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."hash_password"("p_password" "text") RETURNS "text"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  RETURN crypt(p_password, gen_salt('bf'));
END;
$$;


ALTER FUNCTION "public"."hash_password"("p_password" "text") OWNER TO "postgres";

--
-- Name: rls_auto_enable(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rls_auto_enable"() RETURNS "event_trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


ALTER FUNCTION "public"."rls_auto_enable"() OWNER TO "postgres";

--
-- Name: verify_custom_login("text", "text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."verify_custom_login"("p_username" "text", "p_password" "text") RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $_$
DECLARE
  v_db_password text;
BEGIN
  -- Lấy mật khẩu từ DB dựa vào tên đăng nhập
  SELECT mat_khau INTO v_db_password 
  FROM public.tai_khoan 
  WHERE ten_dang_nhap ILIKE p_username AND trang_thai_kich_hoat = true;

  -- Nếu không tìm thấy tài khoản hoặc tài khoản bị khóa
  IF v_db_password IS NULL THEN
    RETURN false;
  END IF;

  -- Kiểm tra xem mật khẩu trong DB có phải là chuỗi băm bcrypt không (thường bắt đầu bằng $2a$, $2b$, $2x$, $2y$)
  IF v_db_password LIKE '$2a$%' OR v_db_password LIKE '$2b$%' OR v_db_password LIKE '$2x$%' OR v_db_password LIKE '$2y$%' THEN
    -- Nếu là chuỗi băm, sử dụng hàm crypt để kiểm tra
    RETURN v_db_password = crypt(p_password, v_db_password);
  ELSE
    -- Nếu là plain text (chưa băm), so sánh trực tiếp (Hỗ trợ tương thích ngược)
    RETURN v_db_password = p_password;
  END IF;
END;
$_$;


ALTER FUNCTION "public"."verify_custom_login"("p_username" "text", "p_password" "text") OWNER TO "postgres";

--
-- Name: apply_rls("jsonb", integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer DEFAULT (1024 * 1024)) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "plpgsql"
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) OWNER TO "supabase_admin";

--
-- Name: broadcast_changes("text", "text", "text", "text", "text", "record", "record", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text" DEFAULT 'ROW'::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") OWNER TO "supabase_admin";

--
-- Name: build_prepared_statement_sql("text", "regclass", "realtime"."wal_column"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) RETURNS "text"
    LANGUAGE "sql"
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) OWNER TO "supabase_admin";

--
-- Name: cast("text", "regtype"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") RETURNS "jsonb"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") OWNER TO "supabase_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") OWNER TO "supabase_admin";

--
-- Name: is_visible_through_filters("realtime"."wal_column"[], "realtime"."user_defined_filter"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) RETURNS boolean
    LANGUAGE "sql" IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) OWNER TO "supabase_admin";

--
-- Name: list_changes("name", "name", integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) RETURNS TABLE("wal" "jsonb", "is_rls_enabled" boolean, "subscription_ids" "uuid"[], "errors" "text"[], "slot_changes_count" bigint)
    LANGUAGE "sql"
    SET "log_min_messages" TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) OWNER TO "supabase_admin";

--
-- Name: quote_wal2json("regclass"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."quote_wal2json"("entity" "regclass") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


ALTER FUNCTION "realtime"."quote_wal2json"("entity" "regclass") OWNER TO "supabase_admin";

--
-- Name: send("jsonb", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_admin";

--
-- Name: send_binary("bytea", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_admin";

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."subscription_check_filters"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        else
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


ALTER FUNCTION "realtime"."subscription_check_filters"() OWNER TO "supabase_admin";

--
-- Name: to_regrole("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."to_regrole"("role_name" "text") RETURNS "regrole"
    LANGUAGE "sql" IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION "realtime"."to_regrole"("role_name" "text") OWNER TO "supabase_admin";

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."topic"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION "realtime"."topic"() OWNER TO "supabase_realtime_admin";

--
-- Name: wal2json_escape_identifier("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


ALTER FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") OWNER TO "supabase_admin";

--
-- Name: allow_any_operation("text"[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) OWNER TO "supabase_storage_admin";

--
-- Name: allow_only_operation("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_only_operation"("expected_operation" "text") RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION "storage"."allow_only_operation"("expected_operation" "text") OWNER TO "supabase_storage_admin";

--
-- Name: can_insert_object("text", "text", "uuid", "jsonb"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") OWNER TO "supabase_storage_admin";

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."enforce_bucket_name_length"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION "storage"."enforce_bucket_name_length"() OWNER TO "supabase_storage_admin";

--
-- Name: extension("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: filename("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: foldername("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_common_prefix("text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";

--
-- Name: list_multipart_uploads_with_delimiter("text", "text", "text", integer, "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "next_key_token" "text" DEFAULT ''::"text", "next_upload_token" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "id" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text") OWNER TO "supabase_storage_admin";

--
-- Name: list_objects_with_delimiter("text", "text", "text", integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "start_after" "text" DEFAULT ''::"text", "next_token" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "metadata" "jsonb", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone)
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text") OWNER TO "supabase_storage_admin";

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."operation"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION "storage"."operation"() OWNER TO "supabase_storage_admin";

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."protect_delete"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION "storage"."protect_delete"() OWNER TO "supabase_storage_admin";

--
-- Name: search("text", "text", integer, integer, integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0, "search" "text" DEFAULT ''::"text", "sortcolumn" "text" DEFAULT 'name'::"text", "sortorder" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_by_timestamp("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_v2("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "start_after" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text", "sort_column" "text" DEFAULT 'name'::"text", "sort_column_after" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION "storage"."update_updated_at_column"() OWNER TO "supabase_storage_admin";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" json,
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "audit_log_entries"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."custom_oauth_providers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider_type" "text" NOT NULL,
    "identifier" "text" NOT NULL,
    "name" "text" NOT NULL,
    "client_id" "text" NOT NULL,
    "client_secret" "text" NOT NULL,
    "acceptable_client_ids" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "scopes" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "pkce_enabled" boolean DEFAULT true NOT NULL,
    "attribute_mapping" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "authorization_params" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "email_optional" boolean DEFAULT false NOT NULL,
    "issuer" "text",
    "discovery_url" "text",
    "skip_nonce_check" boolean DEFAULT false NOT NULL,
    "cached_discovery" "jsonb",
    "discovery_cached_at" timestamp with time zone,
    "authorization_url" "text",
    "token_url" "text",
    "userinfo_url" "text",
    "jwks_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "custom_oauth_providers_authorization_url_https" CHECK ((("authorization_url" IS NULL) OR ("authorization_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_authorization_url_length" CHECK ((("authorization_url" IS NULL) OR ("char_length"("authorization_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_client_id_length" CHECK ((("char_length"("client_id") >= 1) AND ("char_length"("client_id") <= 512))),
    CONSTRAINT "custom_oauth_providers_discovery_url_length" CHECK ((("discovery_url" IS NULL) OR ("char_length"("discovery_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_identifier_format" CHECK (("identifier" ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::"text")),
    CONSTRAINT "custom_oauth_providers_issuer_length" CHECK ((("issuer" IS NULL) OR (("char_length"("issuer") >= 1) AND ("char_length"("issuer") <= 2048)))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_https" CHECK ((("jwks_uri" IS NULL) OR ("jwks_uri" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_length" CHECK ((("jwks_uri" IS NULL) OR ("char_length"("jwks_uri") <= 2048))),
    CONSTRAINT "custom_oauth_providers_name_length" CHECK ((("char_length"("name") >= 1) AND ("char_length"("name") <= 100))),
    CONSTRAINT "custom_oauth_providers_oauth2_requires_endpoints" CHECK ((("provider_type" <> 'oauth2'::"text") OR (("authorization_url" IS NOT NULL) AND ("token_url" IS NOT NULL) AND ("userinfo_url" IS NOT NULL)))),
    CONSTRAINT "custom_oauth_providers_oidc_discovery_url_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("discovery_url" IS NULL) OR ("discovery_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_issuer_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NULL) OR ("issuer" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_requires_issuer" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NOT NULL))),
    CONSTRAINT "custom_oauth_providers_provider_type_check" CHECK (("provider_type" = ANY (ARRAY['oauth2'::"text", 'oidc'::"text"]))),
    CONSTRAINT "custom_oauth_providers_token_url_https" CHECK ((("token_url" IS NULL) OR ("token_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_token_url_length" CHECK ((("token_url" IS NULL) OR ("char_length"("token_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_https" CHECK ((("userinfo_url" IS NULL) OR ("userinfo_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_length" CHECK ((("userinfo_url" IS NULL) OR ("char_length"("userinfo_url") <= 2048)))
);


ALTER TABLE "auth"."custom_oauth_providers" OWNER TO "supabase_auth_admin";

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."flow_state" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "auth_code" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "code_challenge" "text",
    "provider_type" "text" NOT NULL,
    "provider_access_token" "text",
    "provider_refresh_token" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "authentication_method" "text" NOT NULL,
    "auth_code_issued_at" timestamp with time zone,
    "invite_token" "text",
    "referrer" "text",
    "oauth_client_state_id" "uuid",
    "linking_target_id" "uuid",
    "email_optional" boolean DEFAULT false NOT NULL
);


ALTER TABLE "auth"."flow_state" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "flow_state"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."flow_state" IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."identities" (
    "provider_id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "email" "text" GENERATED ALWAYS AS ("lower"(("identity_data" ->> 'email'::"text"))) STORED,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "identities"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN "identities"."email"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."identities"."email" IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "instances"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_amr_claims" (
    "session_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "authentication_method" "text" NOT NULL,
    "id" "uuid" NOT NULL
);


ALTER TABLE "auth"."mfa_amr_claims" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_amr_claims"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_amr_claims" IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_challenges" (
    "id" "uuid" NOT NULL,
    "factor_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "verified_at" timestamp with time zone,
    "ip_address" "inet" NOT NULL,
    "otp_code" "text",
    "web_authn_session_data" "jsonb"
);


ALTER TABLE "auth"."mfa_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_challenges"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_challenges" IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_factors" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "friendly_name" "text",
    "factor_type" "auth"."factor_type" NOT NULL,
    "status" "auth"."factor_status" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "secret" "text",
    "phone" "text",
    "last_challenged_at" timestamp with time zone,
    "web_authn_credential" "jsonb",
    "web_authn_aaguid" "uuid",
    "last_webauthn_challenge_data" "jsonb"
);


ALTER TABLE "auth"."mfa_factors" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_factors"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_factors" IS 'auth: stores metadata about factors';


--
-- Name: COLUMN "mfa_factors"."last_webauthn_challenge_data"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."mfa_factors"."last_webauthn_challenge_data" IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_authorizations" (
    "id" "uuid" NOT NULL,
    "authorization_id" "text" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "redirect_uri" "text" NOT NULL,
    "scope" "text" NOT NULL,
    "state" "text",
    "resource" "text",
    "code_challenge" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "response_type" "auth"."oauth_response_type" DEFAULT 'code'::"auth"."oauth_response_type" NOT NULL,
    "status" "auth"."oauth_authorization_status" DEFAULT 'pending'::"auth"."oauth_authorization_status" NOT NULL,
    "authorization_code" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:03:00'::interval) NOT NULL,
    "approved_at" timestamp with time zone,
    "nonce" "text",
    CONSTRAINT "oauth_authorizations_authorization_code_length" CHECK (("char_length"("authorization_code") <= 255)),
    CONSTRAINT "oauth_authorizations_code_challenge_length" CHECK (("char_length"("code_challenge") <= 128)),
    CONSTRAINT "oauth_authorizations_expires_at_future" CHECK (("expires_at" > "created_at")),
    CONSTRAINT "oauth_authorizations_nonce_length" CHECK (("char_length"("nonce") <= 255)),
    CONSTRAINT "oauth_authorizations_redirect_uri_length" CHECK (("char_length"("redirect_uri") <= 2048)),
    CONSTRAINT "oauth_authorizations_resource_length" CHECK (("char_length"("resource") <= 2048)),
    CONSTRAINT "oauth_authorizations_scope_length" CHECK (("char_length"("scope") <= 4096)),
    CONSTRAINT "oauth_authorizations_state_length" CHECK (("char_length"("state") <= 4096))
);


ALTER TABLE "auth"."oauth_authorizations" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_client_states" (
    "id" "uuid" NOT NULL,
    "provider_type" "text" NOT NULL,
    "code_verifier" "text",
    "created_at" timestamp with time zone NOT NULL
);


ALTER TABLE "auth"."oauth_client_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "oauth_client_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."oauth_client_states" IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_clients" (
    "id" "uuid" NOT NULL,
    "client_secret_hash" "text",
    "registration_type" "auth"."oauth_registration_type" NOT NULL,
    "redirect_uris" "text" NOT NULL,
    "grant_types" "text" NOT NULL,
    "client_name" "text",
    "client_uri" "text",
    "logo_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "client_type" "auth"."oauth_client_type" DEFAULT 'confidential'::"auth"."oauth_client_type" NOT NULL,
    "token_endpoint_auth_method" "text" NOT NULL,
    CONSTRAINT "oauth_clients_client_name_length" CHECK (("char_length"("client_name") <= 1024)),
    CONSTRAINT "oauth_clients_client_uri_length" CHECK (("char_length"("client_uri") <= 2048)),
    CONSTRAINT "oauth_clients_logo_uri_length" CHECK (("char_length"("logo_uri") <= 2048)),
    CONSTRAINT "oauth_clients_token_endpoint_auth_method_check" CHECK (("token_endpoint_auth_method" = ANY (ARRAY['client_secret_basic'::"text", 'client_secret_post'::"text", 'none'::"text"])))
);


ALTER TABLE "auth"."oauth_clients" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_consents" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "scopes" "text" NOT NULL,
    "granted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_at" timestamp with time zone,
    CONSTRAINT "oauth_consents_revoked_after_granted" CHECK ((("revoked_at" IS NULL) OR ("revoked_at" >= "granted_at"))),
    CONSTRAINT "oauth_consents_scopes_length" CHECK (("char_length"("scopes") <= 2048)),
    CONSTRAINT "oauth_consents_scopes_not_empty" CHECK (("char_length"(TRIM(BOTH FROM "scopes")) > 0))
);


ALTER TABLE "auth"."oauth_consents" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."one_time_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_type" "auth"."one_time_token_type" NOT NULL,
    "token_hash" "text" NOT NULL,
    "relates_to" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "one_time_tokens_token_hash_check" CHECK (("char_length"("token_hash") > 0))
);


ALTER TABLE "auth"."one_time_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255),
    "session_id" "uuid"
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "refresh_tokens"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_providers" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "entity_id" "text" NOT NULL,
    "metadata_xml" "text" NOT NULL,
    "metadata_url" "text",
    "attribute_mapping" "jsonb",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "name_id_format" "text",
    CONSTRAINT "entity_id not empty" CHECK (("char_length"("entity_id") > 0)),
    CONSTRAINT "metadata_url not empty" CHECK ((("metadata_url" = NULL::"text") OR ("char_length"("metadata_url") > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK (("char_length"("metadata_xml") > 0))
);


ALTER TABLE "auth"."saml_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_providers" IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_relay_states" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "request_id" "text" NOT NULL,
    "for_email" "text",
    "redirect_to" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "flow_state_id" "uuid",
    CONSTRAINT "request_id not empty" CHECK (("char_length"("request_id") > 0))
);


ALTER TABLE "auth"."saml_relay_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_relay_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_relay_states" IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "schema_migrations"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "factor_id" "uuid",
    "aal" "auth"."aal_level",
    "not_after" timestamp with time zone,
    "refreshed_at" timestamp without time zone,
    "user_agent" "text",
    "ip" "inet",
    "tag" "text",
    "oauth_client_id" "uuid",
    "refresh_token_hmac_key" "text",
    "refresh_token_counter" bigint,
    "scopes" "text",
    CONSTRAINT "sessions_scopes_length" CHECK (("char_length"("scopes") <= 4096))
);


ALTER TABLE "auth"."sessions" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sessions"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sessions" IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN "sessions"."not_after"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."not_after" IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN "sessions"."refresh_token_hmac_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_hmac_key" IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN "sessions"."refresh_token_counter"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_counter" IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_domains" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "domain" "text" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK (("char_length"("domain") > 0))
);


ALTER TABLE "auth"."sso_domains" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_domains"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_domains" IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_providers" (
    "id" "uuid" NOT NULL,
    "resource_id" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "disabled" boolean,
    CONSTRAINT "resource_id not empty" CHECK ((("resource_id" = NULL::"text") OR ("char_length"("resource_id") > 0)))
);


ALTER TABLE "auth"."sso_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_providers" IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN "sso_providers"."resource_id"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sso_providers"."resource_id" IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" "text" DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" "text" DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    "is_sso_user" boolean DEFAULT false NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_anonymous" boolean DEFAULT false NOT NULL,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "users"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN "users"."is_sso_user"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."users"."is_sso_user" IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_challenges" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "challenge_type" "text" NOT NULL,
    "session_data" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    CONSTRAINT "webauthn_challenges_challenge_type_check" CHECK (("challenge_type" = ANY (ARRAY['signup'::"text", 'registration'::"text", 'authentication'::"text"])))
);


ALTER TABLE "auth"."webauthn_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_credentials" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "credential_id" "bytea" NOT NULL,
    "public_key" "bytea" NOT NULL,
    "attestation_type" "text" DEFAULT ''::"text" NOT NULL,
    "aaguid" "uuid",
    "sign_count" bigint DEFAULT 0 NOT NULL,
    "transports" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "backup_eligible" boolean DEFAULT false NOT NULL,
    "backed_up" boolean DEFAULT false NOT NULL,
    "friendly_name" "text" DEFAULT ''::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_used_at" timestamp with time zone
);


ALTER TABLE "auth"."webauthn_credentials" OWNER TO "supabase_auth_admin";

--
-- Name: danh_sach_truong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."danh_sach_truong" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "domain" "text" NOT NULL,
    "ten_truong" "text" NOT NULL,
    "dia_chi_truong" "text",
    "so_dien_thoai" "text",
    "nguoi_quan_ly" "text",
    "thoi_gian_bat_dau_su_dung" timestamp with time zone DEFAULT "now"(),
    "thoi_gian_ket_thuc_su_dung" timestamp with time zone,
    "trang_thai_kich_hoat" boolean DEFAULT true,
    "supabase_url" "text" NOT NULL,
    "supabase_key" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "thong_bao" "text",
    "slug" "text"
);


ALTER TABLE "public"."danh_sach_truong" OWNER TO "postgres";

--
-- Name: dia_chi_truy_cap; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."dia_chi_truy_cap" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "domain" "text" NOT NULL,
    "ten_truong_so_huu" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."dia_chi_truy_cap" OWNER TO "postgres";

--
-- Name: duytricsdl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."duytricsdl" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "so" bigint DEFAULT 0,
    "thoigian" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."duytricsdl" OWNER TO "postgres";

--
-- Name: tai_khoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tai_khoan" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "ten_dang_nhap" "text" NOT NULL,
    "mat_khau" "text" NOT NULL,
    "ho_ten" "text",
    "vai_tro" "text" DEFAULT 'MANAGER'::"text" NOT NULL,
    "trang_thai_kich_hoat" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "tai_khoan_vai_tro_check" CHECK (("vai_tro" = ANY (ARRAY['Admin'::"text", 'MANAGER'::"text"])))
);


ALTER TABLE "public"."tai_khoan" OWNER TO "postgres";

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea"
)
PARTITION BY RANGE ("inserted_at");


ALTER TABLE "realtime"."messages" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_05_01; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_01" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea"
);


ALTER TABLE "realtime"."messages_2026_05_01" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_02; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_02" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea"
);


ALTER TABLE "realtime"."messages_2026_05_02" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_03; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_03" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea"
);


ALTER TABLE "realtime"."messages_2026_05_03" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_04; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_04" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea"
);


ALTER TABLE "realtime"."messages_2026_05_04" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_05; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_05" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea"
);


ALTER TABLE "realtime"."messages_2026_05_05" OWNER TO "supabase_admin";

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."schema_migrations" (
    "version" bigint NOT NULL,
    "inserted_at" timestamp(0) without time zone
);


ALTER TABLE "realtime"."schema_migrations" OWNER TO "supabase_admin";

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."subscription" (
    "id" bigint NOT NULL,
    "subscription_id" "uuid" NOT NULL,
    "entity" "regclass" NOT NULL,
    "filters" "realtime"."user_defined_filter"[] DEFAULT '{}'::"realtime"."user_defined_filter"[] NOT NULL,
    "claims" "jsonb" NOT NULL,
    "claims_role" "regrole" GENERATED ALWAYS AS ("realtime"."to_regrole"(("claims" ->> 'role'::"text"))) STORED NOT NULL,
    "created_at" timestamp without time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "action_filter" "text" DEFAULT '*'::"text",
    "selected_columns" "text"[],
    CONSTRAINT "subscription_action_filter_check" CHECK (("action_filter" = ANY (ARRAY['*'::"text", 'INSERT'::"text", 'UPDATE'::"text", 'DELETE'::"text"])))
);


ALTER TABLE "realtime"."subscription" OWNER TO "supabase_admin";

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE "realtime"."subscription" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "realtime"."subscription_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false,
    "avif_autodetection" boolean DEFAULT false,
    "file_size_limit" bigint,
    "allowed_mime_types" "text"[],
    "owner_id" "text",
    "type" "storage"."buckettype" DEFAULT 'STANDARD'::"storage"."buckettype" NOT NULL
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "buckets"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."buckets"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_analytics" (
    "name" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'ANALYTICS'::"storage"."buckettype" NOT NULL,
    "format" "text" DEFAULT 'ICEBERG'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "deleted_at" timestamp with time zone
);


ALTER TABLE "storage"."buckets_analytics" OWNER TO "supabase_storage_admin";

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_vectors" (
    "id" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'VECTOR'::"storage"."buckettype" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."buckets_vectors" OWNER TO "supabase_storage_admin";

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."objects" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED,
    "version" "text",
    "owner_id" "text",
    "user_metadata" "jsonb"
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "objects"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."objects"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads" (
    "id" "text" NOT NULL,
    "in_progress_size" bigint DEFAULT 0 NOT NULL,
    "upload_signature" "text" NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "version" "text" NOT NULL,
    "owner_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_metadata" "jsonb",
    "metadata" "jsonb"
);


ALTER TABLE "storage"."s3_multipart_uploads" OWNER TO "supabase_storage_admin";

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads_parts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "upload_id" "text" NOT NULL,
    "size" bigint DEFAULT 0 NOT NULL,
    "part_number" integer NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "etag" "text" NOT NULL,
    "owner_id" "text",
    "version" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."s3_multipart_uploads_parts" OWNER TO "supabase_storage_admin";

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."vector_indexes" (
    "id" "text" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL COLLATE "pg_catalog"."C",
    "bucket_id" "text" NOT NULL,
    "data_type" "text" NOT NULL,
    "dimension" integer NOT NULL,
    "distance_metric" "text" NOT NULL,
    "metadata_configuration" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."vector_indexes" OWNER TO "supabase_storage_admin";

--
-- Name: messages_2026_05_01; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_01" FOR VALUES FROM ('2026-05-01 00:00:00') TO ('2026-05-02 00:00:00');


--
-- Name: messages_2026_05_02; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_02" FOR VALUES FROM ('2026-05-02 00:00:00') TO ('2026-05-03 00:00:00');


--
-- Name: messages_2026_05_03; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_03" FOR VALUES FROM ('2026-05-03 00:00:00') TO ('2026-05-04 00:00:00');


--
-- Name: messages_2026_05_04; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_04" FOR VALUES FROM ('2026-05-04 00:00:00') TO ('2026-05-05 00:00:00');


--
-- Name: messages_2026_05_05; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_05" FOR VALUES FROM ('2026-05-05 00:00:00') TO ('2026-05-06 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
4ab940a0-686b-4685-ac38-9d5e566db113	4ab940a0-686b-4685-ac38-9d5e566db113	{"sub": "4ab940a0-686b-4685-ac38-9d5e566db113", "email": "host_quanlytd.vercel.app@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-02 04:21:33.186117+00	2026-05-02 04:21:33.186175+00	2026-05-02 04:21:33.186175+00	13bff018-307b-465f-97b2-c01172bb898c
964af5e8-7c20-40b1-b6ff-3a448dfc265a	964af5e8-7c20-40b1-b6ff-3a448dfc265a	{"sub": "964af5e8-7c20-40b1-b6ff-3a448dfc265a", "email": "host_localhost@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-02 04:23:38.015175+00	2026-05-02 04:23:38.015234+00	2026-05-02 04:23:38.015234+00	1e4b805c-b45a-42f8-b0c4-7156fa321436
f38b5572-029f-4d74-ac31-3d5e278df151	f38b5572-029f-4d74-ac31-3d5e278df151	{"sub": "f38b5572-029f-4d74-ac31-3d5e278df151", "email": "host_lehoan.vercel.app@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-02 04:28:31.272117+00	2026-05-02 04:28:31.272174+00	2026-05-02 04:28:31.272174+00	7326bb6c-a959-4a3e-90d4-6a11bf59ff3e
b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	{"sub": "b01761d2-e8bb-4bd5-9735-e8bfb8c2f411", "email": "host_quanlythiduaxoahk.vercel.app@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-03 21:59:26.375658+00	2026-05-03 21:59:26.375714+00	2026-05-03 21:59:26.375714+00	45cc6c24-c941-41a4-a7c7-bf906c205fb4
815c5ba4-df3e-470b-a277-f6e9b9c1941e	815c5ba4-df3e-470b-a277-f6e9b9c1941e	{"sub": "815c5ba4-df3e-470b-a277-f6e9b9c1941e", "email": "host_hethongquanlythiduacsdlmoi.vercel.app@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-09 03:51:09.733355+00	2026-05-09 03:51:09.733405+00	2026-05-09 03:51:09.733405+00	d06cd73d-f7db-4f47-ae20-29d7dca9dd66
adea62ce-52d6-489d-82e7-362203d85c01	adea62ce-52d6-489d-82e7-362203d85c01	{"sub": "adea62ce-52d6-489d-82e7-362203d85c01", "email": "host_he-thong-quan-ly-thi-dua-csdl-moi-1.vercel.app@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-12 03:33:37.090525+00	2026-05-12 03:33:37.090577+00	2026-05-12 03:33:37.090577+00	ec014ffc-f40c-46c0-99b6-e77c45fd5d4b
4528c17c-395c-4e97-981c-17dbe2bc8181	4528c17c-395c-4e97-981c-17dbe2bc8181	{"sub": "4528c17c-395c-4e97-981c-17dbe2bc8181", "email": "host_@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-12 03:55:40.205321+00	2026-05-12 03:55:40.205371+00	2026-05-12 03:55:40.205371+00	015a4f91-4bae-4385-9573-eaf4585edb3e
99321c1d-2254-4bbe-a5df-d14e52829a39	99321c1d-2254-4bbe-a5df-d14e52829a39	{"sub": "99321c1d-2254-4bbe-a5df-d14e52829a39", "email": "admin@htqltd.local", "email_verified": false, "phone_verified": false}	email	2026-05-12 06:27:35.31799+00	2026-05-12 06:27:35.318041+00	2026-05-12 06:27:35.318041+00	f20e4e71-16e6-4090-af4a-401d8a698732
dd2562d3-83c2-4544-9636-9e4809b41ea7	dd2562d3-83c2-4544-9636-9e4809b41ea7	{"sub": "dd2562d3-83c2-4544-9636-9e4809b41ea7", "email": "hohuuthe@htqltd.local", "email_verified": false, "phone_verified": false}	email	2026-05-12 08:09:50.7663+00	2026-05-12 08:09:50.766348+00	2026-05-12 08:09:50.766348+00	2097c5bb-605d-42a1-bfe2-7741a802d68c
46283390-81d3-4324-9d77-9cfd33c224bc	46283390-81d3-4324-9d77-9cfd33c224bc	{"sub": "46283390-81d3-4324-9d77-9cfd33c224bc", "email": "host_quanlythiduamoi1.vercel.app@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-12 23:34:48.827831+00	2026-05-12 23:34:48.827885+00	2026-05-12 23:34:48.827885+00	d3c0476e-97ca-4218-8d63-ea0dfe812e47
aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	{"sub": "aa09c8ca-e8b5-48c6-8a28-533a5ec44d65", "email": "host_quanlythiduamoi11.huuthe87.workers.dev@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-18 08:14:28.420879+00	2026-05-18 08:14:28.420924+00	2026-05-18 08:14:28.420924+00	fb8e37ad-e45e-4a85-b9f7-848096bf21bc
722d8397-103b-4234-8e9d-e329674e79f2	722d8397-103b-4234-8e9d-e329674e79f2	{"sub": "722d8397-103b-4234-8e9d-e329674e79f2", "email": "host_lehoan@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-18 11:05:48.800806+00	2026-05-18 11:05:48.800868+00	2026-05-18 11:05:48.800868+00	4c5315f0-c5d1-44dc-bfb2-02012992fc87
a24e2881-8767-4f08-9552-fc3376516585	a24e2881-8767-4f08-9552-fc3376516585	{"sub": "a24e2881-8767-4f08-9552-fc3376516585", "email": "host_htqltd.vercel.app@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-18 13:02:00.947195+00	2026-05-18 13:02:00.947244+00	2026-05-18 13:02:00.947244+00	3476607f-c244-4041-a707-94e2be01acd5
a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	{"sub": "a3bf7198-1be3-4e4d-82a4-5de1009f5ea2", "email": "htqltd_vercel_app@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-20 10:16:05.075227+00	2026-05-20 10:16:05.075286+00	2026-05-20 10:16:05.075286+00	7f8bfd1c-7a4c-4077-a06f-2ba49aa882b5
0b718cac-6cd9-494a-9076-e924f23783d0	0b718cac-6cd9-494a-9076-e924f23783d0	{"sub": "0b718cac-6cd9-494a-9076-e924f23783d0", "email": "htqltd_huuthe87_workers_dev@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-20 11:11:02.225717+00	2026-05-20 11:11:02.225773+00	2026-05-20 11:11:02.225773+00	705835e5-0f64-452d-a792-7e3892630b77
a670a3d7-db76-4536-ad05-13c3ee563069	a670a3d7-db76-4536-ad05-13c3ee563069	{"sub": "a670a3d7-db76-4536-ad05-13c3ee563069", "email": "hethongquanlythidua_vercel_app@system.local", "email_verified": false, "phone_verified": false}	email	2026-05-21 13:31:13.333725+00	2026-05-21 13:31:13.333786+00	2026-05-21 13:31:13.333786+00	28cfcf96-1ad4-431f-b021-a3de719e6c69
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
33b7d1ab-6afa-4e78-8054-9f10d6785317	2026-05-02 04:21:33.222087+00	2026-05-02 04:21:33.222087+00	password	1a5aaa6c-0364-4a29-96a9-daa2cd62b96d
fe48fec9-e8ab-45bf-9784-95306b918f50	2026-05-02 04:21:33.468978+00	2026-05-02 04:21:33.468978+00	password	72f709f6-1902-41eb-91e6-d7478eb77b80
d80eeef9-7f60-430e-aa92-7338c610945f	2026-05-02 04:21:46.070412+00	2026-05-02 04:21:46.070412+00	password	c662d4f5-4c95-4758-b08a-d1a41e22a402
466e6a53-e33d-48f9-95ae-f09fb3b3115a	2026-05-02 04:23:29.599392+00	2026-05-02 04:23:29.599392+00	password	74cd8c87-67dc-4c72-abdd-2103d93ba465
45754a10-35ca-4df9-b875-d663f5bd909c	2026-05-02 04:23:38.025499+00	2026-05-02 04:23:38.025499+00	password	0c3bcb05-db52-4281-9f38-63f72ef5abc6
57a1e782-c07e-4939-8c69-91b13f802291	2026-05-02 04:23:38.141102+00	2026-05-02 04:23:38.141102+00	password	f55ecac9-9530-4aa4-b8b7-83bde21c8847
b3307f87-98fe-4dad-89ce-8601e272788a	2026-05-02 04:24:03.428386+00	2026-05-02 04:24:03.428386+00	password	92bce71b-3845-418a-be88-5e4eddbc44b4
804d6c6c-ca99-41d3-990d-6bfd4ffad049	2026-05-02 04:28:31.285711+00	2026-05-02 04:28:31.285711+00	password	e01d52b4-841b-45f2-8244-92ac3e2ecd0d
cf9830e4-6181-47ea-81e9-d5a240f1b268	2026-05-02 04:28:31.489594+00	2026-05-02 04:28:31.489594+00	password	1ecbb81b-1810-49bb-9f06-d898f9313b94
28a05a6c-f93c-4ae7-a2fe-515a017b22b2	2026-05-02 04:33:51.189723+00	2026-05-02 04:33:51.189723+00	password	8cefb898-5993-4725-aec8-ff8d5d9c1657
821e4a8e-f196-4463-8955-3143be845fa2	2026-05-02 04:34:40.325649+00	2026-05-02 04:34:40.325649+00	password	35d1a322-998a-4e6d-93dd-e15c77b9ee73
a92d68db-1b89-4e69-aa57-ba5bf6fc7f31	2026-05-02 04:40:47.138064+00	2026-05-02 04:40:47.138064+00	password	6b474563-6cae-4840-a244-01987c611b1a
96eeb8b7-fcc0-4f65-9a07-c3faef5de35a	2026-05-02 04:40:51.345252+00	2026-05-02 04:40:51.345252+00	password	781ee100-9751-45dd-9cf4-437f8e392c96
e1580ec9-13cb-4eba-824d-3309cd46673f	2026-05-02 04:40:55.817191+00	2026-05-02 04:40:55.817191+00	password	142d863f-3089-413e-8e88-704059324943
06ac7d91-24e8-432a-8035-9dbc6b58eea2	2026-05-02 04:40:59.173686+00	2026-05-02 04:40:59.173686+00	password	5e10dcb9-a0dd-4387-a701-cd9505f06cc8
b67d3dd7-de96-4d3e-ac0d-0dd2f7719857	2026-05-02 04:41:02.426814+00	2026-05-02 04:41:02.426814+00	password	eb47d1a9-d641-4e49-8896-e06c5f85c730
392d861d-3204-432f-bb0e-2056b90df667	2026-05-02 04:41:05.933503+00	2026-05-02 04:41:05.933503+00	password	de023f3f-3f79-4d22-92d1-3baeccc4529c
026083a6-1d23-410b-96d4-8597b44e1b61	2026-05-02 04:41:13.938203+00	2026-05-02 04:41:13.938203+00	password	d213bb22-0fce-49b8-a952-63700dbe40a6
b6bb26ff-1681-4569-9860-b60c2bb4cd1b	2026-05-02 04:42:27.593759+00	2026-05-02 04:42:27.593759+00	password	88268f9a-d726-4638-a57f-98db77c614a9
7677b361-1287-4171-838b-fcaeef3064fc	2026-05-02 04:45:45.476916+00	2026-05-02 04:45:45.476916+00	password	7e358175-37f4-42bd-94fc-3cd0a8c362ba
88de18de-51fc-44d8-b4be-589d24024016	2026-05-02 04:58:20.200954+00	2026-05-02 04:58:20.200954+00	password	7e90d3ef-f2a7-428d-91d0-a1319455e28a
1c8aaf7a-e986-442a-a4f1-cd23f00965e7	2026-05-02 04:58:38.550185+00	2026-05-02 04:58:38.550185+00	password	2f20c5b3-9ea6-47ed-b02c-436e3a7bb0d4
06f81853-71c5-41a3-a9ef-fd26babaee86	2026-05-02 05:53:44.322638+00	2026-05-02 05:53:44.322638+00	password	6493c219-a623-4121-a45a-730263508fac
cc270bd5-e464-4abf-ad82-45f365a5ce65	2026-05-02 05:53:49.880427+00	2026-05-02 05:53:49.880427+00	password	56bd70ef-c765-408d-83e4-c7b369712eca
dc79cde6-2e0f-469f-8b84-34a0d28f9b31	2026-05-02 05:55:01.483068+00	2026-05-02 05:55:01.483068+00	password	81c951a2-9215-49b3-bad5-ddc17c28310d
754e992e-fa7b-408d-897a-282c738fa033	2026-05-02 05:55:09.531824+00	2026-05-02 05:55:09.531824+00	password	c0cb5e78-0481-4ef5-838d-edcb9de09e4d
c49a3657-35a0-4a1c-909b-4d96ed90d760	2026-05-02 05:55:26.017849+00	2026-05-02 05:55:26.017849+00	password	625777df-246b-4b51-a99e-88bac79a3e84
96a31004-fc0c-4089-9b23-5157395e0ada	2026-05-02 05:57:21.775786+00	2026-05-02 05:57:21.775786+00	password	07b1316f-53b4-4bc4-9a77-1478ddb92e2f
705862d9-316f-44cd-9b78-894aeb5849e8	2026-05-02 05:57:23.590462+00	2026-05-02 05:57:23.590462+00	password	6182706e-8d15-411c-a6a5-cd4b1c5328f1
e5e90106-5c37-4cac-b92e-04f516686b91	2026-05-02 05:57:26.428907+00	2026-05-02 05:57:26.428907+00	password	bff1382c-c0ed-402a-b65b-edd5437ad9e4
53e3d7bf-bb34-4163-ba07-88c033a433eb	2026-05-02 05:57:39.374381+00	2026-05-02 05:57:39.374381+00	password	2e46ae4b-f88d-4abe-a63d-725fae1e3b42
5e277aad-a35f-4e3e-9e48-4c6a22e87211	2026-05-02 05:58:15.010324+00	2026-05-02 05:58:15.010324+00	password	34187bd3-59ea-42c0-9acb-f7aeb6ef87fc
3c15d471-3d8f-44a1-aa25-1ed0df78014d	2026-05-02 06:00:03.494912+00	2026-05-02 06:00:03.494912+00	password	0716bdab-42fd-4d76-8c42-996c12eff697
bd699fce-89d6-4ece-8206-8d0014a68d35	2026-05-02 06:37:21.829614+00	2026-05-02 06:37:21.829614+00	password	f954be9c-dd15-4e43-9ce3-fa03562fc7a9
f78530e3-fde5-41ae-9447-d7ad678cfe6d	2026-05-02 06:37:24.18506+00	2026-05-02 06:37:24.18506+00	password	90769750-ca73-41c3-9396-a851bfa2ea76
ad8c3800-408e-4cef-a792-6f7e52d6c934	2026-05-02 06:37:26.414858+00	2026-05-02 06:37:26.414858+00	password	c3897f46-9503-4500-a134-c131f2661ac4
d6eb78ec-5c35-4d7e-88e4-2263e73d778f	2026-05-02 06:37:59.631247+00	2026-05-02 06:37:59.631247+00	password	ce97e2e3-0e58-4cd7-b00f-d11c8690db39
c3153f94-b511-4422-8b04-8dcb9af1a41e	2026-05-02 06:38:02.018947+00	2026-05-02 06:38:02.018947+00	password	1773248c-7cd7-4079-8394-1504be0cce98
e2d9a855-e6be-4c0d-8288-639a122b6f3e	2026-05-02 06:38:05.476451+00	2026-05-02 06:38:05.476451+00	password	f0a91b03-29ec-44f7-9387-b355185912d2
bdc32057-66ff-41a6-93a9-940be1bc0d09	2026-05-02 06:38:14.416225+00	2026-05-02 06:38:14.416225+00	password	c01acbb8-d6a1-46df-89c6-024a7d7a644e
514591f8-e3de-4fa7-9d7f-eb7aca8583af	2026-05-02 06:39:16.053697+00	2026-05-02 06:39:16.053697+00	password	5f9b2fed-bc08-44c0-8f85-492506147021
e6f1f035-a515-4098-be59-6d15e041e217	2026-05-02 06:55:13.587322+00	2026-05-02 06:55:13.587322+00	password	627cad11-7fb4-4c0a-b61d-3469cac3070d
d0894bda-d535-449f-bf40-8de4aaddbf1c	2026-05-02 06:56:18.868749+00	2026-05-02 06:56:18.868749+00	password	44f8df30-b3b9-42e9-8da4-d97aa616e6f9
a84a833c-a2b5-44f4-8c2a-a399a379d936	2026-05-02 08:52:50.778086+00	2026-05-02 08:52:50.778086+00	password	4e944b3c-4755-411d-9f16-38429156a3ae
2e9522de-c53c-4553-9fb4-83d3b84dee12	2026-05-02 08:53:44.268614+00	2026-05-02 08:53:44.268614+00	password	ee751782-7165-4ed6-9e7b-9b3b4a9848bf
650b000f-04ff-4b36-b79f-b3132ea261e6	2026-05-02 09:00:08.839217+00	2026-05-02 09:00:08.839217+00	password	f9fdc156-aee4-404b-9b35-39bdef6f130f
c4c78cf4-2454-4f6b-9521-a25cdb1a6372	2026-05-02 09:00:20.09222+00	2026-05-02 09:00:20.09222+00	password	7a9fe29a-be19-41ea-96fe-c8d337c93f63
0aec5984-ed0b-43ca-a858-b799ae654320	2026-05-02 09:02:29.703898+00	2026-05-02 09:02:29.703898+00	password	a1752875-5f9c-43a9-aa3e-aa5f5322fcaa
382e79a5-86cc-48ce-9330-bb3af3120d37	2026-05-02 09:03:06.123517+00	2026-05-02 09:03:06.123517+00	password	7daa8346-7743-4e6f-bcb6-c85ca39c5ef9
88064374-0038-4f87-9c89-33b03b2c6ebb	2026-05-02 12:19:36.219571+00	2026-05-02 12:19:36.219571+00	password	0b57cd1b-5c89-4730-9895-8e3c0d307fb8
56f40644-a46e-4b9d-bc70-9aaaeccdb16d	2026-05-02 12:19:37.126588+00	2026-05-02 12:19:37.126588+00	password	82d8ac0c-2f5f-42e6-8ca2-374f7245a80d
21c543e6-45e1-421c-a020-9452576cc618	2026-05-02 12:20:41.535639+00	2026-05-02 12:20:41.535639+00	password	ccf77240-c84f-45d5-9c66-8b7c3ae27d07
ddfa30f6-58ea-4e9d-a093-67527e6ff780	2026-05-02 12:23:13.645369+00	2026-05-02 12:23:13.645369+00	password	207f253b-0098-4a9e-b367-d0dff430cf64
0d3579c1-e372-4e2b-bb02-69db33b9bc26	2026-05-02 15:16:13.91539+00	2026-05-02 15:16:13.91539+00	password	2621b81b-c106-4e7e-bffe-07155cdfa488
23b7c766-3cb4-4a2c-9f25-dc5b8fd3e2a7	2026-05-02 18:44:40.763183+00	2026-05-02 18:44:40.763183+00	password	885db504-d0bc-4af6-baf8-0b69fa2a6c67
9ff2d49a-0569-4ccd-8a2a-07613b12a4cc	2026-05-03 01:56:30.824691+00	2026-05-03 01:56:30.824691+00	password	5fb5b440-490d-478b-8bf4-2d80561f5b6f
d78cba54-dfa1-45d7-9b3c-93bed98faf41	2026-05-03 02:47:02.882597+00	2026-05-03 02:47:02.882597+00	password	c1b73e7b-fbb4-4dd7-853e-158497f59b7c
3f72b81d-e0bf-4670-a270-a11e881e5a4b	2026-05-03 02:47:14.198771+00	2026-05-03 02:47:14.198771+00	password	14643271-a83a-4205-9da8-ac3c26aebf9b
6a7349b7-75e7-4c97-83fd-9d17fbb07ffc	2026-05-03 04:01:21.820542+00	2026-05-03 04:01:21.820542+00	password	8f9d40d4-9245-4f9c-b16f-0573aec26afc
d74905c3-fec3-4820-b20d-e1349512c6ed	2026-05-03 04:39:13.24179+00	2026-05-03 04:39:13.24179+00	password	268e0b5d-282e-4a7d-a853-68b24fb5300d
a52311de-cdd2-4a89-84ae-8eedf990bbda	2026-05-03 05:23:38.380789+00	2026-05-03 05:23:38.380789+00	password	bc34d422-6f7d-416d-b563-babe66c76b9d
ad9840ec-a4da-4fa8-a435-76bbecd7797f	2026-05-03 05:23:52.016981+00	2026-05-03 05:23:52.016981+00	password	9a110e45-a0cc-41af-9e6e-1ee57fb93489
b9321a65-c87f-4f04-b85a-dff2e11a17f0	2026-05-03 05:24:06.515135+00	2026-05-03 05:24:06.515135+00	password	fe80af02-00ce-494c-9d74-98c1b74c6420
b715b6bc-65aa-4eae-8152-45c4662c8810	2026-05-03 05:32:28.529149+00	2026-05-03 05:32:28.529149+00	password	0c744f77-522d-4faa-bcb2-7c42da354cb7
d4805735-6eb4-4564-8cd3-83a83d78161f	2026-05-03 07:29:39.210432+00	2026-05-03 07:29:39.210432+00	password	df4eccc1-c776-4fb2-9652-8dac20d61ebd
9ee81a2d-a12f-4aed-a93b-1f433fcefa1e	2026-05-03 07:29:57.273405+00	2026-05-03 07:29:57.273405+00	password	91490441-cdb4-4556-b9c2-f6d576b91037
c0090a18-ab2b-4241-8232-6b35d64d2331	2026-05-03 07:31:22.227073+00	2026-05-03 07:31:22.227073+00	password	a5d1ba03-b01a-4c14-bc73-0642ff8bb34b
768d1a95-0656-47b9-a287-de7cf7527a9f	2026-05-03 07:31:45.51558+00	2026-05-03 07:31:45.51558+00	password	790e53b3-9e42-4f17-84b1-a0571f2da591
b3768cfd-d804-4614-8e89-3f8706254c0c	2026-05-03 07:56:39.26241+00	2026-05-03 07:56:39.26241+00	password	bda73acd-6b99-446e-bde4-44463ec59fd0
56526efc-a07a-478d-8d21-c8b6daf81614	2026-05-03 07:58:57.606819+00	2026-05-03 07:58:57.606819+00	password	f6cf3d92-d877-400c-a6e7-b95d1f582d5f
247d96af-6468-451c-a0f4-bb7f60f1602c	2026-05-03 07:59:40.71709+00	2026-05-03 07:59:40.71709+00	password	fb1adfd2-c92d-43f1-a839-d224b0afdf7c
6034532e-5aaa-4e9e-aadd-41781795e7f3	2026-05-03 09:10:46.734504+00	2026-05-03 09:10:46.734504+00	password	b534380b-1d04-40af-acb2-f8cc65a1a1b5
36386704-5e12-48a3-b786-724e0cc4af2c	2026-05-03 09:59:10.184786+00	2026-05-03 09:59:10.184786+00	password	d73e51e1-206d-4891-ba59-4bc276517a56
ebf24002-4d07-43ad-b133-359f38413558	2026-05-03 10:27:08.237589+00	2026-05-03 10:27:08.237589+00	password	3acc9b92-73ba-49bc-b690-8b76148a1bab
7a277f46-870b-4b87-b4e4-f675fa56ee59	2026-05-03 11:13:58.823101+00	2026-05-03 11:13:58.823101+00	password	720a33d3-ed8e-4fd5-a86f-815af28f36c2
4cae1f82-8a7b-47d8-b29c-5c5b2c8ed74b	2026-05-03 11:52:38.372043+00	2026-05-03 11:52:38.372043+00	password	7f2e0736-9676-43cb-9161-1899b9b886cd
561e4790-29c5-4a5d-80a8-120e433316d9	2026-05-03 11:54:34.347996+00	2026-05-03 11:54:34.347996+00	password	347c71a7-14ea-4e3f-b0a0-8a7578d43d2c
ccc9e3bb-b175-465c-97a5-99bd17654f8f	2026-05-03 11:56:01.741501+00	2026-05-03 11:56:01.741501+00	password	756a0e82-0048-4b1c-b0a0-f8513a18769f
2cce2503-5db3-4118-8a57-57002c6c48f5	2026-05-03 13:13:34.652021+00	2026-05-03 13:13:34.652021+00	password	521f262c-0332-46f5-914c-2cb77bea37b6
e85d209a-b9ad-48b1-872b-99f0bca62010	2026-05-03 13:16:26.629611+00	2026-05-03 13:16:26.629611+00	password	30b415d6-1648-4256-98d6-d15a5e34e149
1f96eb1f-911d-4904-ae06-1fe125ec6767	2026-05-03 13:16:31.510437+00	2026-05-03 13:16:31.510437+00	password	f3776a48-5d31-4541-ae3b-6187bec20c54
537ddd17-cb00-4948-a643-c30f4e51befb	2026-05-03 13:22:18.816546+00	2026-05-03 13:22:18.816546+00	password	5d6a3edd-0d83-40bb-ae5d-b778baf636f1
5ce13903-ac1b-47fb-aab1-028b1e8ca7c5	2026-05-03 14:26:26.996657+00	2026-05-03 14:26:26.996657+00	password	3a9dcda6-1f28-460b-9d04-3a164065a611
7fa38bed-e54f-4e21-8cce-170b243f8176	2026-05-03 14:36:10.286509+00	2026-05-03 14:36:10.286509+00	password	a8d43d4b-365e-4c57-99f5-d2479e898d1f
736b82b5-2088-4768-9db5-1d8eda930207	2026-05-03 14:41:01.57414+00	2026-05-03 14:41:01.57414+00	password	d0e4c060-df57-48a5-a699-af462e2a445a
742aefac-0409-46bd-b62b-86b1c289997e	2026-05-03 15:59:17.314146+00	2026-05-03 15:59:17.314146+00	password	8f90b681-2f8b-49b2-a5fa-399abbd7307c
022cd7fd-2ec7-4ac3-a757-19426e25751f	2026-05-03 21:59:26.407477+00	2026-05-03 21:59:26.407477+00	password	4328ea5b-d537-4215-8f0f-9d76c3daa65f
b41fdbac-f7bd-4f02-bdc8-1ed1b3618154	2026-05-03 21:59:26.613828+00	2026-05-03 21:59:26.613828+00	password	51613167-2d6d-4afa-a510-de96a21fde8a
780646ad-33f4-4a25-a2a9-a031228410b1	2026-05-03 21:59:44.620735+00	2026-05-03 21:59:44.620735+00	password	fa48a275-67a8-4031-8858-e4c6825a724a
6d3855ed-1ae2-4518-b7ee-094074e817d8	2026-05-03 22:00:19.370357+00	2026-05-03 22:00:19.370357+00	password	3a52029a-e84e-429b-a51a-2a2b76940bd6
d2f43092-dd37-45cd-8216-e3b3d4c54888	2026-05-03 22:00:58.741944+00	2026-05-03 22:00:58.741944+00	password	37f86303-0df3-4fdb-8735-30ec776cfada
792ee504-7c04-4eb4-82c7-21b0e9a203fd	2026-05-03 22:01:46.298951+00	2026-05-03 22:01:46.298951+00	password	426d9b1a-91f6-4000-8ca9-74a6895bbfd2
f8286ee6-c5ce-4d82-b3f9-29a0be4001fb	2026-05-03 22:02:23.771236+00	2026-05-03 22:02:23.771236+00	password	ca7892fb-b934-4aa7-afbc-70a59e339819
b78e2a4c-3b59-4244-94d3-cc3e2b06c5d4	2026-05-03 22:02:28.532029+00	2026-05-03 22:02:28.532029+00	password	427c129f-b8d0-4e83-abae-ea5d8577e187
1cd4ba68-d656-43e6-9e30-2239b47592ee	2026-05-03 22:02:33.414314+00	2026-05-03 22:02:33.414314+00	password	57c27eb8-049b-4b9f-8fcf-70ef2b7bdd7f
08814b95-d98f-4cf5-9a81-a315ff7e8bd5	2026-05-03 22:02:49.443438+00	2026-05-03 22:02:49.443438+00	password	56a48b02-7b33-4895-a61a-de1d237b0230
626a55b8-0ca2-4e39-b766-d07386f7b714	2026-05-03 22:03:26.683803+00	2026-05-03 22:03:26.683803+00	password	c24f9a56-d5e1-4c30-992b-d91330d73d45
9ac05af9-ad69-4376-bb18-dbead4e76184	2026-05-03 22:03:31.431358+00	2026-05-03 22:03:31.431358+00	password	01bbf478-16d1-401c-99a2-253365789e9b
bb2bf0d4-cc91-4375-b5af-26bcd39c3379	2026-05-03 22:04:11.864782+00	2026-05-03 22:04:11.864782+00	password	497a64b3-dd74-4b1b-8350-4afe961afa70
923e429d-a30b-4418-87d6-9098640cb4cc	2026-05-03 22:07:20.044464+00	2026-05-03 22:07:20.044464+00	password	f17b1dc8-35ae-4db5-9533-35988f158597
5ead0212-844b-4856-adb6-4cc0958c5ff1	2026-05-03 22:07:37.307729+00	2026-05-03 22:07:37.307729+00	password	37def760-f5e0-4d6e-91c8-05efcf033707
9b1cb33b-bf9e-4668-9bff-8d67256854d0	2026-05-03 22:07:56.055953+00	2026-05-03 22:07:56.055953+00	password	6c0c9ba3-4348-42fd-8872-fdcd387c9d76
1af02e38-a092-4598-94d8-524b3f66d341	2026-05-03 22:08:12.695718+00	2026-05-03 22:08:12.695718+00	password	e8785558-5c03-4650-8dd8-d22c3848d75e
cb73a2ef-d2c6-48fb-aad5-48b8400fe70e	2026-05-03 22:08:25.401151+00	2026-05-03 22:08:25.401151+00	password	c07f9783-7356-46fb-9786-a6439d8b9305
b203a927-4a6a-4278-aaf9-98ab8a5d6a5c	2026-05-03 22:08:35.000291+00	2026-05-03 22:08:35.000291+00	password	c24b3e77-f0c6-4244-a269-a01b004c28b6
c2b0cead-50e1-40b2-aeca-b1a29ed75868	2026-05-03 22:09:00.464735+00	2026-05-03 22:09:00.464735+00	password	9d87f1b8-e05d-4225-b18d-37ac0b9ff4aa
5b2678ca-9731-4ebc-aadf-45023ecb4158	2026-05-03 22:12:19.073904+00	2026-05-03 22:12:19.073904+00	password	132850b1-7f10-4d27-8c92-c49a8dac8262
47576508-f0b5-4200-9159-4cb5ca7a2d0e	2026-05-03 22:12:40.527597+00	2026-05-03 22:12:40.527597+00	password	f41c8b80-3ec9-4d40-b570-50c96625d6c6
4229f572-9f64-4c02-88f0-f44489af96a7	2026-05-03 22:13:04.867473+00	2026-05-03 22:13:04.867473+00	password	6d104712-4aaa-42e4-bf11-730eafae270e
0fd134a3-c414-4f98-98d4-46bb2f36961c	2026-05-03 22:13:11.959158+00	2026-05-03 22:13:11.959158+00	password	30299ca7-726d-4a1a-b5bc-2c826568b032
7df728e3-6131-4355-9671-2393c55818ea	2026-05-03 22:13:17.169705+00	2026-05-03 22:13:17.169705+00	password	aa658b9d-e8ec-48e4-bb9d-beacf4a6ca4a
c13af329-b9a5-469d-b414-e30846f97a76	2026-05-03 22:13:20.28882+00	2026-05-03 22:13:20.28882+00	password	2a9ee705-6933-4d0b-a13a-4bf04d81d5a7
379fa945-8e84-41fd-9538-e1b44f180a44	2026-05-03 22:13:24.099297+00	2026-05-03 22:13:24.099297+00	password	ac7e8d4c-a0ce-41a3-af56-05418578d798
3de0434e-c832-4ecb-b6ff-d61acd0fd8c0	2026-05-03 22:16:01.859516+00	2026-05-03 22:16:01.859516+00	password	6ebdbe39-ab16-4b6d-a0f8-47d3731c08f4
8f7cef5c-cde4-4648-a32d-acb6abe3df5d	2026-05-03 22:16:50.849762+00	2026-05-03 22:16:50.849762+00	password	3fa73781-c47f-49b4-af72-bd1e73389b1e
41a740ad-869b-41d1-9f3e-357c7b2781cc	2026-05-03 22:23:25.303613+00	2026-05-03 22:23:25.303613+00	password	66ef8218-265e-4c8b-ab34-0b26b73520ad
fcc8d616-9e96-4cd5-bd27-13e38b0a4022	2026-05-03 22:55:34.225612+00	2026-05-03 22:55:34.225612+00	password	bd70d192-7e8d-40f3-ac1f-5d32b5b9f8e0
e22c7e96-caf6-4617-bad4-d8cd3f0f6afa	2026-05-03 22:59:40.119505+00	2026-05-03 22:59:40.119505+00	password	dc9ec4d8-415d-4eb4-8afd-1b4d4ae19700
b01a92b3-3e87-4abf-b47a-33ab1e635878	2026-05-03 23:00:15.852762+00	2026-05-03 23:00:15.852762+00	password	851eda78-93a1-4675-b94e-69fb34ce1b58
0cebdc4f-0f13-4a4a-9c63-428e8eec2907	2026-05-03 23:00:28.823992+00	2026-05-03 23:00:28.823992+00	password	14982baf-5841-4771-a250-05d1b6537ae7
bc10560b-e57f-4ac5-a305-c182f7a9a115	2026-05-03 23:01:22.052932+00	2026-05-03 23:01:22.052932+00	password	b6fa53c7-a99f-4f97-8b97-e7c5cbb60dca
e633cdf3-eb03-4599-8582-ab3392b66e94	2026-05-03 23:01:29.589912+00	2026-05-03 23:01:29.589912+00	password	859d1dae-b68e-4273-8c5a-4b235d08d956
b79c7b8e-ebf8-477f-9caf-1270504e7c2a	2026-05-03 23:02:49.286449+00	2026-05-03 23:02:49.286449+00	password	d4b26eba-8c46-4b84-bc5d-f487abffb984
8d7355e6-a022-4420-8e3e-8eb16655824e	2026-05-03 23:59:59.648062+00	2026-05-03 23:59:59.648062+00	password	920db6f3-470c-4596-84aa-39b783904259
831ade6e-9235-4b82-ace7-3131601855e8	2026-05-04 00:00:06.310532+00	2026-05-04 00:00:06.310532+00	password	202fbe28-a57b-43ea-b1f4-bd0c37480f47
c4a790ae-b218-4496-9d77-a507dc6cb04c	2026-05-04 00:00:12.764171+00	2026-05-04 00:00:12.764171+00	password	42e0ce1f-6c2e-405f-b15e-aa4b86ae40f0
bb66c957-0f8b-4e6c-a415-d2dcc5834d44	2026-05-04 00:04:32.005301+00	2026-05-04 00:04:32.005301+00	password	167b3e1b-f268-4e7c-b259-7a466e0367c3
10cb3316-ab6d-4fc6-b596-e9613d3a6d46	2026-05-04 00:05:59.377532+00	2026-05-04 00:05:59.377532+00	password	d355a994-d0fa-4c96-a4f2-4d6d60c7139b
2fcf52d4-0cb8-47dd-b03b-cb2220f8fb37	2026-05-04 00:17:57.269286+00	2026-05-04 00:17:57.269286+00	password	f3f7d90e-95f2-4809-812b-034b6e5cb019
23d59a86-9247-4898-8047-3804c31c1e05	2026-05-04 00:56:02.00534+00	2026-05-04 00:56:02.00534+00	password	4d3db437-7978-4ec6-8c68-00ca0e03019e
e852b441-c39d-4f92-b90c-9a8a107022a6	2026-05-04 01:03:33.090062+00	2026-05-04 01:03:33.090062+00	password	fb7f363e-3236-4596-98c4-7e0980deb0ca
29317481-fe82-4e3c-8ee9-6f715d883ef3	2026-05-04 01:03:46.292003+00	2026-05-04 01:03:46.292003+00	password	8a1c8a51-6c20-4aaf-8cc3-0393f815e0e8
5e135e1a-3a5a-4cbe-895a-b1a0eb391547	2026-05-04 01:20:39.017877+00	2026-05-04 01:20:39.017877+00	password	3805e8c7-bba3-4ff1-96c8-025b592d4f7a
c8c88c22-cce2-4579-a097-b2304a209b9e	2026-05-04 01:27:22.533396+00	2026-05-04 01:27:22.533396+00	password	ca8ebfe0-f222-41ca-aed9-691ad598cbfd
ab0bb280-ecc9-419f-803b-d805c78081fa	2026-05-04 02:07:03.795385+00	2026-05-04 02:07:03.795385+00	password	8dbe77e0-c574-4c92-b003-0429b899295e
b5855e91-6a0b-4ac5-a5f7-2ef3e8c74a68	2026-05-04 02:08:05.494287+00	2026-05-04 02:08:05.494287+00	password	333a13f0-aef5-461d-b288-0f7b91d0f25b
cd941f5c-3252-48a7-988a-0a3146fd740b	2026-05-04 02:32:25.724741+00	2026-05-04 02:32:25.724741+00	password	26de2906-605b-4c6d-a1ac-c2c64f289185
f12cb778-ad5b-4be4-a29e-b85813586f7a	2026-05-04 02:40:01.933952+00	2026-05-04 02:40:01.933952+00	password	ed507104-da54-4bcc-864e-2f51102ab2bc
8fef52f0-97ea-46ec-905e-2c973b458cec	2026-05-04 03:39:05.408764+00	2026-05-04 03:39:05.408764+00	password	a2a22425-3eea-4d9c-af93-fc4cc19fcf7b
c42ba9ff-32f4-4266-bc13-fa88c4c0615b	2026-05-04 07:31:44.452301+00	2026-05-04 07:31:44.452301+00	password	e887f953-0999-466a-b6b6-52ec2401b69e
18c7adf2-4889-44d9-a8ac-78ac6e4b2814	2026-05-04 07:32:54.831975+00	2026-05-04 07:32:54.831975+00	password	fdfa3a0a-0534-479c-b788-f15d606c51ba
6eebc915-64ad-4ae5-846c-16c522ca6700	2026-05-04 07:52:28.216626+00	2026-05-04 07:52:28.216626+00	password	b4509764-ea53-4283-97a3-761dc8806310
3e3cf196-c0b0-4aa0-92d6-005722817aa4	2026-05-04 09:21:46.205888+00	2026-05-04 09:21:46.205888+00	password	58657cdf-abed-4b29-93b4-13089f69f536
84cf9fcb-bd20-460e-bbb7-3d892d0c3a1c	2026-05-04 09:37:41.72373+00	2026-05-04 09:37:41.72373+00	password	71596d5f-7370-4f49-ba5b-fb495d32c29d
d5b5d670-e6bc-4109-b80d-5ab30aa44c62	2026-05-04 09:42:32.106186+00	2026-05-04 09:42:32.106186+00	password	b24c4500-26e5-47e5-a6b0-3514eb005d36
809f7948-cf83-433e-9729-73562edcfd7d	2026-05-04 12:08:40.368871+00	2026-05-04 12:08:40.368871+00	password	1147a2fe-5a28-4fa2-9f33-fb72ed9de947
b10743eb-1bbd-4db7-9987-582a0a1ffa6d	2026-05-04 14:16:09.710956+00	2026-05-04 14:16:09.710956+00	password	b679e898-4ef2-48a2-b64e-0cd8c6ae88ec
36c71719-a2bb-4990-98a6-16242d2c5d7c	2026-05-04 14:18:04.00283+00	2026-05-04 14:18:04.00283+00	password	0b21b417-2209-4f37-b7f1-639f2e7233f0
dc2f16f9-42d7-4dfb-9ea2-1357b661d5f2	2026-05-04 15:23:17.107115+00	2026-05-04 15:23:17.107115+00	password	2f4faa72-c505-4703-92d7-0ca898f42092
d9aafebd-ec9a-4ad9-9a8d-5a953fe27aed	2026-05-04 16:10:21.373759+00	2026-05-04 16:10:21.373759+00	password	e2951fff-d091-4415-ba92-a81ebfeaa433
437a42a6-bbfb-4520-ba9b-a3144a745219	2026-05-04 16:44:49.966552+00	2026-05-04 16:44:49.966552+00	password	9602785c-cabb-4ee7-8d93-5fb8a24ecef2
83afb629-f15b-4b1b-b504-61faa740f181	2026-05-04 17:21:18.914312+00	2026-05-04 17:21:18.914312+00	password	aaa8a3dd-4a30-4a0f-bcb8-9f32d70b8149
cfb77a1f-d3f3-4097-8d6d-bf41d217d032	2026-05-04 17:21:27.784165+00	2026-05-04 17:21:27.784165+00	password	4f83b9d9-5bbd-4c2d-9e3b-6931519152b2
32b21aee-7494-4636-99ab-3ba93cf6d61a	2026-05-04 17:36:45.986676+00	2026-05-04 17:36:45.986676+00	password	465bdf56-c9e0-47e8-85ae-6085acd33fa7
f2c660b3-218f-4580-b4cc-ab3f3575bfba	2026-05-04 17:37:24.081403+00	2026-05-04 17:37:24.081403+00	password	41acf6c7-446b-407d-a460-c8ea441a66ae
60e843bf-f5e1-440d-aca1-f57505a5ca87	2026-05-04 17:38:23.542805+00	2026-05-04 17:38:23.542805+00	password	a6580520-a554-4811-8bd9-56861630b17a
56f174b4-b753-4e53-aa4b-dc66466ecd85	2026-05-04 17:38:31.126653+00	2026-05-04 17:38:31.126653+00	password	185afeea-4150-47d9-ab40-70c498d52f6d
702ee476-a304-466a-b2d4-167e25ca8e1f	2026-05-04 17:38:56.003953+00	2026-05-04 17:38:56.003953+00	password	0bbcc67c-930c-4491-9a72-10e680117522
db460c34-8d43-4b40-b7e3-c1fa1155843b	2026-05-04 17:39:16.528753+00	2026-05-04 17:39:16.528753+00	password	80decb17-bf3d-40ff-831b-7b7f9dddcc53
2fd61c0c-8b07-4014-820d-d7461997775c	2026-05-04 17:40:04.263644+00	2026-05-04 17:40:04.263644+00	password	7f7f56cc-3be8-48b1-a143-4f58c7a3a855
b829fbc2-ac7f-4400-b2e0-7fafa8d8a23a	2026-05-04 17:40:58.728205+00	2026-05-04 17:40:58.728205+00	password	63043b8e-ee82-4cda-9d09-97899c0c1289
0b624b14-677c-4b59-af68-9ae7eacab824	2026-05-04 18:22:16.253957+00	2026-05-04 18:22:16.253957+00	password	4e2b6f7e-e0d7-42ef-8890-957254fdba9e
9ab5e877-1c1f-45e9-95bc-299c35df278e	2026-05-04 22:59:10.022268+00	2026-05-04 22:59:10.022268+00	password	48fedf8b-2f29-4875-a46f-221fe128b7df
1d883c9e-7522-4fef-962d-14d2b6ba2c06	2026-05-04 23:53:27.477519+00	2026-05-04 23:53:27.477519+00	password	7a90af0d-6d15-4164-9cce-2e7596f8f8c2
f0b124f4-0361-46da-9f5f-aeb9ae5c0485	2026-05-04 23:53:57.500972+00	2026-05-04 23:53:57.500972+00	password	25bba930-25fb-4152-ba45-02bd9edbee61
7d2e53f6-aa50-4511-b01b-1cee76b254f5	2026-05-04 23:54:45.409479+00	2026-05-04 23:54:45.409479+00	password	9bf3ea3d-8474-452a-94f9-837767f3b8d1
90b90c10-6111-42ec-9389-9b40a939a336	2026-05-04 23:57:35.644896+00	2026-05-04 23:57:35.644896+00	password	bafa4af6-db11-4db4-a7d1-65dddf3984c7
4328172b-7786-419d-af8a-594897d67a2b	2026-05-05 00:09:20.19794+00	2026-05-05 00:09:20.19794+00	password	0b17c792-8aaf-40b2-a841-082d4b0fce01
e8b716fd-1ada-449c-ab5f-63881e9b5da8	2026-05-05 00:13:39.175319+00	2026-05-05 00:13:39.175319+00	password	079f25a7-0d7e-4fcc-8fe0-30522e7d50ee
b0d4b141-d279-4131-8612-399170fb322c	2026-05-05 00:18:48.768364+00	2026-05-05 00:18:48.768364+00	password	8c2984f6-80d0-426d-9cca-c09ae35850c1
4f222a82-6691-45a2-8183-1b5b10c08068	2026-05-05 00:44:25.24305+00	2026-05-05 00:44:25.24305+00	password	5c92b649-9a98-495c-99e3-7d335591e2cb
96062ea5-a33c-4f49-9d84-a49de190e469	2026-05-05 01:12:29.023666+00	2026-05-05 01:12:29.023666+00	password	21845682-4e00-46bb-baeb-3c1a16139491
f9134f67-ae73-4392-918c-ab90ead4c86c	2026-05-05 01:13:28.269588+00	2026-05-05 01:13:28.269588+00	password	27f22344-3b2a-45a6-b77d-7f8608eab0e2
97d7fa3a-1847-4e68-8e17-b84597eda1fc	2026-05-05 01:14:41.015147+00	2026-05-05 01:14:41.015147+00	password	93c1aae6-e97c-4240-a40d-43fa567d8db7
714a10fb-95bf-4df0-9823-b91bf611988d	2026-05-05 01:14:44.825288+00	2026-05-05 01:14:44.825288+00	password	94456fd4-6c79-410a-bc66-715c417fa0ea
bc1d548e-88d2-41cb-8b94-7a4ee7a2f968	2026-05-05 01:15:07.15782+00	2026-05-05 01:15:07.15782+00	password	a8eab076-3434-48a2-b363-9c729e0d8c91
bb92ab88-d663-4927-8185-f9832e5f4ff0	2026-05-05 01:15:32.550346+00	2026-05-05 01:15:32.550346+00	password	b5dfa2a9-129f-4fe9-8dc0-4db0e1211464
4e01c41a-75a9-4761-acb4-d7f0b502b177	2026-05-05 01:20:04.821674+00	2026-05-05 01:20:04.821674+00	password	c347f80e-5cbf-46d9-bf12-f527c40d7d5d
c4629844-c5b0-4f4a-b675-9e79aa8079fc	2026-05-05 01:38:58.942351+00	2026-05-05 01:38:58.942351+00	password	b9cebf43-8494-4abf-9247-1a9ed4ba7e8b
451979bd-fcab-4e8e-9cec-dc5fafa65aa0	2026-05-05 04:14:37.649409+00	2026-05-05 04:14:37.649409+00	password	dcb49d0c-4efa-45eb-a08c-b0f51b7b5ff2
19fa2897-d1e9-4457-aa6b-634c3358732c	2026-05-05 04:14:59.525618+00	2026-05-05 04:14:59.525618+00	password	c8fc758d-0e14-40f2-a1d6-1bd0e0233b0a
e9edff2f-72e3-4119-8742-d18f83784b8e	2026-05-05 05:07:58.944379+00	2026-05-05 05:07:58.944379+00	password	77c4113f-28e5-4e66-be30-831b26a26560
0252ff6a-4f5d-419e-bada-5db881b3f557	2026-05-05 05:29:52.071206+00	2026-05-05 05:29:52.071206+00	password	60261712-1717-41c6-a060-1b51d62b31ac
17eebc96-a8e4-40b8-a4f4-8cf185e8d585	2026-05-05 05:30:14.428493+00	2026-05-05 05:30:14.428493+00	password	47f54687-0560-4df4-9917-870b95cdd931
e3768ef2-e43a-4d91-9192-0635f30bba15	2026-05-05 06:43:20.158699+00	2026-05-05 06:43:20.158699+00	password	d97f067c-76f5-4a71-9a59-e8da266c45bc
746ac5b7-ba5d-4437-99a1-1b7b2b98af3c	2026-05-05 07:31:06.079372+00	2026-05-05 07:31:06.079372+00	password	566d8266-962c-4f29-a22f-a900bc9a655a
bdc600f7-ab51-420b-bd57-886abc293f1c	2026-05-05 07:48:22.034618+00	2026-05-05 07:48:22.034618+00	password	5a975fed-e8a7-499e-a946-8f52ef5d5340
ddfb7882-9b63-4979-aa59-280bcbd46f83	2026-05-05 07:48:26.336755+00	2026-05-05 07:48:26.336755+00	password	32ce54a8-3c4c-41e3-bbd5-c5c40a05b78e
76ef158e-2723-424e-88a7-e33cee110365	2026-05-05 07:48:32.391893+00	2026-05-05 07:48:32.391893+00	password	d850635b-7406-498c-a1b8-1d0393a87048
66c61761-aad9-4b27-99e0-2b1a3aedeea1	2026-05-05 07:49:04.985136+00	2026-05-05 07:49:04.985136+00	password	e940bec5-2b41-41d0-adfd-0cb067ae287a
7226c412-1d6a-4b0a-8e7a-91509f076113	2026-05-05 07:49:09.268172+00	2026-05-05 07:49:09.268172+00	password	3fc93fcc-1939-4afe-8df7-3a1093e60954
a4898a5c-7896-4a83-9e90-e9f68f802f27	2026-05-05 08:45:35.938648+00	2026-05-05 08:45:35.938648+00	password	88d40121-8c6f-45af-9440-76ecb480f015
55ba7369-bbaf-49f5-8f5e-eee95ba064d4	2026-05-05 08:45:59.411679+00	2026-05-05 08:45:59.411679+00	password	ad65f40c-5703-4556-88c6-55e52aa036f7
f9d66a5c-41d0-44b0-837f-216b42c285f5	2026-05-05 08:47:11.778707+00	2026-05-05 08:47:11.778707+00	password	5876ca27-1443-4e5d-bbe0-38a4f3b0d16b
23d9aa11-b4fd-4b88-a669-115f51f985db	2026-05-05 08:48:25.154434+00	2026-05-05 08:48:25.154434+00	password	7ca7c0bc-4f44-4f7a-aa48-2e35f2eaf458
0b5f07f0-84b0-4989-b852-a4a2b3c30d4e	2026-05-05 08:48:30.915638+00	2026-05-05 08:48:30.915638+00	password	dd2e9e39-36bf-419a-8a48-50b7d22005fb
35a91ad8-6b74-4eff-b707-d1afc380544b	2026-05-05 08:49:01.520973+00	2026-05-05 08:49:01.520973+00	password	b792cd8c-df0a-4dc9-a050-41e614634f9a
9b5bc7a9-258f-442d-ae44-48e725494b93	2026-05-05 08:51:18.403273+00	2026-05-05 08:51:18.403273+00	password	eba079f1-1c7d-482d-9166-0d94c3bb83fc
565d57e9-fa45-4c55-b129-fa5bb637ecc7	2026-05-05 08:51:25.524366+00	2026-05-05 08:51:25.524366+00	password	e4f72340-eef6-4965-b388-37ea987f67d0
cf928da7-81eb-4794-b216-c72f55f4a71e	2026-05-05 08:51:33.088124+00	2026-05-05 08:51:33.088124+00	password	f99b7aff-4a8d-4db4-ae6b-1ada2db67817
3e54b0ef-5541-4cd6-9512-b209c912c316	2026-05-05 08:52:17.365399+00	2026-05-05 08:52:17.365399+00	password	1305fe40-bfca-4910-b00a-c0edc0b36cff
bbbe0ad9-7faf-46df-bee3-932207d777c0	2026-05-05 08:52:22.373248+00	2026-05-05 08:52:22.373248+00	password	97450cdc-18ca-4cc1-961d-aee9ad5dcb93
ed9c373b-f361-4d5c-92b6-e33984a3a641	2026-05-05 08:52:30.482103+00	2026-05-05 08:52:30.482103+00	password	6783ea45-624b-4b8c-bce0-066d28adaa7b
d4b17260-a81f-4b65-b30b-ac1f0999dbcc	2026-05-05 08:52:35.356093+00	2026-05-05 08:52:35.356093+00	password	6abee478-a280-491f-a374-e3805b1b6a18
287b93fc-d59f-4367-8299-7f5f0b7b3614	2026-05-05 08:52:50.631786+00	2026-05-05 08:52:50.631786+00	password	d71c2bcf-d28b-427d-87a2-18eb628bc8e9
52409d80-f00d-4a3b-9058-7c6c9e0f1f22	2026-05-05 08:52:55.680919+00	2026-05-05 08:52:55.680919+00	password	22884bf1-78f1-4996-bbfa-e4bb2f5863b8
ce95d173-00c9-4acd-a35d-5f3e7715b72c	2026-05-05 08:53:16.411832+00	2026-05-05 08:53:16.411832+00	password	8b4e6f48-65dc-49d8-a15d-4531721a4086
177749b0-dfdb-4a9c-9af1-a7c841ae36ab	2026-05-05 08:56:05.829705+00	2026-05-05 08:56:05.829705+00	password	5e45a942-3116-487c-8bdf-557058242102
ae763eb9-2669-4978-80a0-d0d6986f2644	2026-05-05 08:56:42.181844+00	2026-05-05 08:56:42.181844+00	password	8cc492c8-e651-4b75-a94c-97ad38569fac
81d36529-2bb9-40f8-ba59-8664a2b95ba8	2026-05-05 09:04:51.17518+00	2026-05-05 09:04:51.17518+00	password	72cfee47-01bb-4e16-bf0a-524d9cf78ed0
36c21b72-c61d-4396-a6ae-33fdc6229e5f	2026-05-05 09:05:00.164345+00	2026-05-05 09:05:00.164345+00	password	273f9fa9-6ada-4b5c-8eac-379604068957
65377ec6-9c52-4c5c-9004-2480cc30ef2d	2026-05-05 09:05:04.317678+00	2026-05-05 09:05:04.317678+00	password	0be66b9f-a86f-4bc8-b0dd-d4c58ed3f697
b595635b-14cc-49aa-8083-a6101cc26f30	2026-05-05 09:05:06.405601+00	2026-05-05 09:05:06.405601+00	password	aafe14ae-0f31-43fa-9b14-40644276b9b7
8c44043c-b0e9-43cb-a6a3-15800a3b3dc7	2026-05-05 09:05:07.670705+00	2026-05-05 09:05:07.670705+00	password	5158b61a-9c93-4acf-b85c-ccb98b351ca7
ef39d3aa-435e-4897-9f6e-dd3d3502525b	2026-05-05 09:05:10.258121+00	2026-05-05 09:05:10.258121+00	password	a59f0bd8-ddff-47f7-a246-070a18bcc51a
8977b9fc-f710-4aad-9a7e-a75d814e3af2	2026-05-05 09:05:13.142673+00	2026-05-05 09:05:13.142673+00	password	2bab7602-a571-4dfd-a11b-3458e40db29c
b3cb45ed-5a14-4f7c-a5c4-248b9a629f5a	2026-05-05 09:05:16.133597+00	2026-05-05 09:05:16.133597+00	password	18f0984a-2f16-4e0b-95dd-f3b21b873968
46d0eeab-9af3-4b0c-9087-f94bb88b00f3	2026-05-05 09:05:19.325751+00	2026-05-05 09:05:19.325751+00	password	0dd4f780-7581-43dc-b4ad-8e82ab206bff
e001f007-5fa5-4dea-8be0-f4fc21e1c910	2026-05-05 09:05:31.452328+00	2026-05-05 09:05:31.452328+00	password	2551803f-e565-4ae4-a34e-d77992145a84
00e11523-c130-4426-9cc2-3b3e25e2df5b	2026-05-05 09:05:37.735035+00	2026-05-05 09:05:37.735035+00	password	cf77e386-ccad-469b-b791-0e8c83127584
4683efc8-ceab-4973-845c-958e1c86b6a1	2026-05-05 09:06:05.619727+00	2026-05-05 09:06:05.619727+00	password	28737b52-2c85-472c-b09b-4f1daac6f551
2c037710-a3bc-4d20-8c2c-1a82e824d15c	2026-05-05 09:06:43.116204+00	2026-05-05 09:06:43.116204+00	password	bf7c9a56-a1a3-4434-98e1-39f35ac2fe5a
46ca7411-881f-41d6-8c7b-e9c47735c1c0	2026-05-05 09:10:41.038762+00	2026-05-05 09:10:41.038762+00	password	b4a68fc3-1c74-4526-a3c3-32c150da8dde
b4a45a6f-f318-4044-a329-1bb5a47b4e77	2026-05-05 09:11:35.744785+00	2026-05-05 09:11:35.744785+00	password	1a2e77b3-b313-4a54-9409-041ff3a792a6
ff560c57-9b1a-486b-9827-c9f1fa6a654d	2026-05-05 09:11:39.601246+00	2026-05-05 09:11:39.601246+00	password	dbaa6558-c022-4966-a411-5c2a542571d2
b80661e0-77c3-41b0-80c0-543588924842	2026-05-05 09:11:44.224116+00	2026-05-05 09:11:44.224116+00	password	8944cf9c-9ca1-4f81-9a8c-14559d926ff7
4e118ef6-0f15-41f2-8a65-8ec1c8efeb91	2026-05-05 09:11:52.908066+00	2026-05-05 09:11:52.908066+00	password	e78bdf12-e93b-4f0e-b550-2efe1ac96a13
0b729218-9ab7-48c8-b1d9-f0b394264d21	2026-05-05 09:11:58.73351+00	2026-05-05 09:11:58.73351+00	password	a8622e39-f350-4a94-afea-f5bccbcfc232
fb0964c0-18e1-4f09-b14f-ca6e79636db6	2026-05-05 09:19:49.558471+00	2026-05-05 09:19:49.558471+00	password	fdaf41ba-d6e8-4fe2-8967-6245777a6f8e
3edd612f-ebe1-4e68-ad26-ee80767bf38c	2026-05-05 09:19:53.726174+00	2026-05-05 09:19:53.726174+00	password	39ee02ce-d0c1-4e92-866c-16f4cefa4f50
69dc4520-f8ca-4afc-9dca-31ab6e2f89ea	2026-05-05 09:19:57.488836+00	2026-05-05 09:19:57.488836+00	password	a485a7ff-e76c-4da5-b0eb-64eac38bbdc9
287b9f54-27ef-442f-bfff-69f8809e55c2	2026-05-05 09:20:00.430935+00	2026-05-05 09:20:00.430935+00	password	81063d93-eeb5-456f-9c5d-5cef0fa799b7
cff2cf55-bbb3-421a-8a2d-c483a48677b4	2026-05-05 09:20:07.951635+00	2026-05-05 09:20:07.951635+00	password	e66335f0-3729-4209-b3b8-0c0d1207c52d
198a0c13-e000-4910-93a9-1f047793fa96	2026-05-05 09:20:10.580556+00	2026-05-05 09:20:10.580556+00	password	b339b7d8-f28f-437e-b044-8d278abde095
f425b5a9-6712-4bec-894b-0684b4920443	2026-05-05 09:20:13.242137+00	2026-05-05 09:20:13.242137+00	password	86fdcc8d-d495-4f88-88f4-d5227c9ec1fd
7146453c-0da3-4d01-8fe3-597aba3e7f76	2026-05-05 09:20:37.402165+00	2026-05-05 09:20:37.402165+00	password	f3e08f42-51a1-47c9-ba60-ca9b288b7dec
5794d0fb-3de4-4a21-ad88-30608322e40d	2026-05-05 09:20:43.027374+00	2026-05-05 09:20:43.027374+00	password	9f11b6e7-ca54-465c-b378-4069b7012533
56ba64c8-0127-42fe-8c08-22d48bf593c0	2026-05-05 09:20:46.172925+00	2026-05-05 09:20:46.172925+00	password	de843fbe-bf5f-42c5-86ef-b33d92833d17
9e79887b-ebb7-41a3-b557-f086a8bbe84e	2026-05-05 09:20:48.918394+00	2026-05-05 09:20:48.918394+00	password	b6c1b36e-6cc3-44bd-a6ef-64458178e733
2904744f-6e4b-42eb-b5f7-2cb01aba1201	2026-05-05 09:20:51.682395+00	2026-05-05 09:20:51.682395+00	password	82a52361-a21b-44a2-b28d-860b32de5a7a
d8530133-e9f3-403f-9671-9f97a29031fc	2026-05-05 09:36:00.27775+00	2026-05-05 09:36:00.27775+00	password	c05c4e68-1e88-4263-a419-930552405a71
dec25eb0-01a7-4a53-9713-f05ec9688102	2026-05-05 09:36:35.014709+00	2026-05-05 09:36:35.014709+00	password	92807f42-092d-4390-9be2-84261216caec
065a6a8a-307c-4549-ab89-f7b2d3fa6071	2026-05-05 09:39:01.739703+00	2026-05-05 09:39:01.739703+00	password	b396a118-ed9e-447b-8781-753290950b3a
266ab7ad-fee4-4060-b714-0df6ae56f7ef	2026-05-05 09:39:05.591442+00	2026-05-05 09:39:05.591442+00	password	c317aefd-bfa3-44d9-bc15-79e1e05b14eb
f66a48a1-8e28-4f9b-9060-24e981e39b13	2026-05-05 09:39:10.522315+00	2026-05-05 09:39:10.522315+00	password	19dd617c-facd-4ecd-8e9f-33ab652f890a
6f5185ee-9a32-495e-acd8-a237e0906983	2026-05-05 09:39:22.301248+00	2026-05-05 09:39:22.301248+00	password	1e665381-5626-4057-b445-c3dfda64228e
ee259390-b741-418f-a143-07dadf976d40	2026-05-05 09:39:36.410014+00	2026-05-05 09:39:36.410014+00	password	b967295d-1106-43af-898d-565da5525d6e
66d1ad24-ea77-448c-ba47-b9253b785162	2026-05-05 09:39:53.293055+00	2026-05-05 09:39:53.293055+00	password	8afd1e1d-106c-4c07-9856-07fc5834337d
b2fd433f-56d3-42f3-83e7-5f310c97989b	2026-05-05 09:40:04.115579+00	2026-05-05 09:40:04.115579+00	password	2b5625ea-11f6-498d-a327-113835892e0f
170e25f2-52c2-4794-98ba-1607557e84e3	2026-05-05 09:40:07.73815+00	2026-05-05 09:40:07.73815+00	password	d3878aa8-fd68-4b41-a791-229cb7d63718
5bb6dec3-adb6-4c26-bbd0-732eebcc49cd	2026-05-05 09:40:45.295691+00	2026-05-05 09:40:45.295691+00	password	d14f23ce-12ad-47af-b162-a6a46271798a
f56b1375-f128-47ed-ba05-dda6cfd4c37d	2026-05-05 09:41:02.045629+00	2026-05-05 09:41:02.045629+00	password	34581df2-b5bb-4c7a-b3b5-cadb4c9037b0
416aa2ba-63fa-4b96-aacb-fc0886a05708	2026-05-05 09:52:06.174796+00	2026-05-05 09:52:06.174796+00	password	76cddf76-70bf-4f8a-bbc4-ada67db65ed1
c57cfdf1-6c5b-434f-8c6d-973a38aedb0a	2026-05-05 09:52:45.692447+00	2026-05-05 09:52:45.692447+00	password	daea8954-8c6f-4eb2-92d0-f975e51b9290
2bb14976-f280-4aa1-979c-c185709ef86e	2026-05-05 09:52:51.087591+00	2026-05-05 09:52:51.087591+00	password	0086e932-40a2-42bc-840b-559d79001165
9676c8c5-b532-41d3-869b-3940abe754e9	2026-05-05 09:52:54.082757+00	2026-05-05 09:52:54.082757+00	password	4bb1ae0f-e1c1-4105-95ca-668eb475a1bc
9cc2c579-cbb7-4420-9edd-6459c8824156	2026-05-05 09:52:57.716408+00	2026-05-05 09:52:57.716408+00	password	e12b1d06-688e-4b42-b909-3f0ca56c03a9
c72404dc-1467-4c5d-a894-ae5b39e36053	2026-05-05 09:53:00.973016+00	2026-05-05 09:53:00.973016+00	password	feadf059-5eb9-47f8-a16a-7b79b08e1564
b7b68fe3-ca3a-4cd2-a60f-75772440c0d9	2026-05-05 09:53:03.966604+00	2026-05-05 09:53:03.966604+00	password	b2e464fc-bb42-49ee-8d0e-70ec5071c5ba
37620b72-37c5-4ae6-9372-cc9b5914e607	2026-05-05 09:53:13.575134+00	2026-05-05 09:53:13.575134+00	password	89ca88ea-5139-455f-bd34-899e88b8df5a
fa708d2b-9f81-4ad4-bd43-479b2f2af26f	2026-05-05 09:53:52.294437+00	2026-05-05 09:53:52.294437+00	password	7d9dec9f-b931-4a07-896f-bd312fc92a54
75028800-d27a-4e77-877e-028fa64bca10	2026-05-05 10:01:37.936392+00	2026-05-05 10:01:37.936392+00	password	2f1c2967-ead8-459d-a80e-336489d65d4c
5603fb42-13c5-4cb2-912a-003124de62e4	2026-05-05 10:01:48.635302+00	2026-05-05 10:01:48.635302+00	password	c28c8826-0d2c-4822-a4a3-4d2345a4e5c3
783ccce5-9ec5-43f9-a305-06e7f4b2c23c	2026-05-05 10:02:12.447373+00	2026-05-05 10:02:12.447373+00	password	c603dfc1-482f-480b-b563-39350dbec326
031c3e37-a433-403f-838e-08c403e13ee8	2026-05-05 10:02:19.67747+00	2026-05-05 10:02:19.67747+00	password	e30f9f27-2ce4-4b73-9eeb-1d1633926a97
f5b8ecfe-4e0f-4947-87d0-b89d590c13ee	2026-05-05 10:04:00.046657+00	2026-05-05 10:04:00.046657+00	password	f7b372fb-de3d-46a8-be8d-eed522b7ec0e
41bd728f-cd6d-4f75-b567-dda95e0017a2	2026-05-05 10:09:33.916673+00	2026-05-05 10:09:33.916673+00	password	80d3e493-027c-44bf-8260-e54f0fd24cb8
532a2e5e-b419-4c51-95ee-3d31ae7bc179	2026-05-05 10:14:01.932954+00	2026-05-05 10:14:01.932954+00	password	84333211-53fa-4627-902f-0f080a705a47
a9d35b7d-c90a-4e56-8d70-28ece2cdd63e	2026-05-05 10:14:14.382355+00	2026-05-05 10:14:14.382355+00	password	85b9eb3d-6cbe-4d91-a192-48e3997c48b0
188540b9-3fc4-410a-ba05-91e0d39416bf	2026-05-05 10:23:59.627689+00	2026-05-05 10:23:59.627689+00	password	f1a63d65-45b8-4aa5-90da-0d3c302ec7a7
fdd1f54c-7b4a-4a3e-9ad4-fe69cb23377f	2026-05-05 10:29:47.67816+00	2026-05-05 10:29:47.67816+00	password	b2fcd0ba-71cc-44f7-b504-8ca27924fdf2
4005f373-5f9d-486e-b912-8a0e4f8386d1	2026-05-05 10:40:02.406327+00	2026-05-05 10:40:02.406327+00	password	070a41ca-bcfb-4be9-a1dc-ffca5ca71698
5920c8c1-8ed5-4a6c-b7f5-cf52005b5df9	2026-05-05 11:16:33.223065+00	2026-05-05 11:16:33.223065+00	password	35a6e7bc-4ec4-466e-bdad-a02acc408d46
60432168-ba3d-4b59-ae8b-7dc310046b03	2026-05-05 11:16:51.240855+00	2026-05-05 11:16:51.240855+00	password	9204158a-fb35-4315-ba33-4705ef160590
f698b2cd-bbd1-48df-8711-abc037c2f86a	2026-05-05 11:20:48.761711+00	2026-05-05 11:20:48.761711+00	password	c6aed6a7-7263-479b-814f-bcdc14274804
ccda3d9e-6f2e-437a-a296-e31f80a264aa	2026-05-05 11:25:37.438719+00	2026-05-05 11:25:37.438719+00	password	8f77ee6c-8057-467c-8282-8d23f3a1e7d5
62604bc2-0044-4523-9d70-226c132e60b9	2026-05-05 11:25:40.149643+00	2026-05-05 11:25:40.149643+00	password	dea21b85-0e8c-4832-b10d-54ad26d10824
c3fb64f6-59ca-4d6b-a1ca-efacdd08b485	2026-05-05 11:25:42.069417+00	2026-05-05 11:25:42.069417+00	password	90371735-0116-44ae-b65f-0b4074e96dad
cd004805-a941-4a3c-8165-63081c3947a5	2026-05-05 11:25:44.074181+00	2026-05-05 11:25:44.074181+00	password	33658c38-da82-453c-bdde-7803922d14b6
d4306924-41ef-4da4-9f0a-805505044a54	2026-05-05 11:25:45.95609+00	2026-05-05 11:25:45.95609+00	password	d93d6bda-3b88-4a33-b736-d928ff401d64
520f80a6-4a95-4538-af31-c36d708826d1	2026-05-05 11:25:49.137482+00	2026-05-05 11:25:49.137482+00	password	dd15b63d-9072-4953-a232-e219e341d8c4
29b67951-dd20-4cfb-a3d4-9dbdfa17ba40	2026-05-05 11:25:51.035757+00	2026-05-05 11:25:51.035757+00	password	f842462a-d848-4e94-a427-b1dfcbe52c24
01df7d0c-48ba-4179-9b9c-f031f6a6c797	2026-05-05 11:25:53.018589+00	2026-05-05 11:25:53.018589+00	password	a26283e9-7d65-40b5-a08c-e39371cfa427
70b3669a-dea5-4f1f-846f-a70c85148727	2026-05-05 11:25:55.715336+00	2026-05-05 11:25:55.715336+00	password	f50e6a4d-3ea1-4685-9b9f-04d027982d3a
1d65b308-36d6-4962-bbe1-eaee021b88ea	2026-05-05 11:26:01.674117+00	2026-05-05 11:26:01.674117+00	password	e37086a1-6785-4040-86d2-5c867ef5f040
70ed0cf8-9b7c-4ad0-accc-c6034e7de1c9	2026-05-05 11:26:04.08407+00	2026-05-05 11:26:04.08407+00	password	df9d357a-a989-4309-991a-a0f29ea25e2d
d37d81b0-8e0f-454e-b267-2dedb65d530e	2026-05-05 13:28:14.586283+00	2026-05-05 13:28:14.586283+00	password	8b272386-af85-4c60-86b0-066c2f23f835
c25d9809-45d9-4a72-b6a6-bc6ec95f4969	2026-05-05 15:25:21.114082+00	2026-05-05 15:25:21.114082+00	password	bb6c5c37-c827-493e-b3f6-56b55c5176f4
242199f4-395a-454d-83e0-67cfa7222f97	2026-05-06 13:53:49.80642+00	2026-05-06 13:53:49.80642+00	password	fee697ab-5f7d-4f8f-bb09-80a0b6a7ebde
79ec4ab0-5548-45ec-800d-94b0d3f11ceb	2026-05-07 01:30:43.646913+00	2026-05-07 01:30:43.646913+00	password	0fc51f91-5f42-45a4-964f-ae5ca837b270
60ba9e8b-0479-4868-97bf-ef70c2bb3266	2026-05-07 03:32:13.591769+00	2026-05-07 03:32:13.591769+00	password	2750ad47-dbed-4842-b1f2-1981849a0783
5231d6de-9266-4dca-b421-c7bc1fc3343b	2026-05-07 04:22:13.012911+00	2026-05-07 04:22:13.012911+00	password	0f9f14c8-6431-455c-8c7e-c18bbdd9b1ff
c50a15ab-4492-4581-bcde-1688c05ffe9b	2026-05-07 05:27:48.561893+00	2026-05-07 05:27:48.561893+00	password	c59c4761-b147-4435-ab85-c1931c2d1607
283eee76-180d-444b-8d01-f9d01b30dd1f	2026-05-07 07:37:23.039944+00	2026-05-07 07:37:23.039944+00	password	8f9dec0c-f8b7-43d0-9a8f-4924100a422d
985a6fb5-dd71-4f3c-9f23-342ffef72660	2026-05-07 07:52:10.089449+00	2026-05-07 07:52:10.089449+00	password	d4e8bd26-a119-4d21-a547-1d6a9d40a5f6
ca4c863a-9a15-4c49-8eb3-ecbf6f441425	2026-05-07 17:39:08.523183+00	2026-05-07 17:39:08.523183+00	password	2a803fa5-0a03-4f87-af16-0169108cbce4
2e2b56bf-045f-48dd-9217-26512e6cd3c8	2026-05-08 13:45:35.790587+00	2026-05-08 13:45:35.790587+00	password	45a42a05-4493-4ecb-8382-45c43983f1f6
53fda4c7-6e61-4c7d-bdc8-6b933c1c7883	2026-05-09 03:51:09.779597+00	2026-05-09 03:51:09.779597+00	password	4a6c8da9-2a33-4e42-b775-af01ef635d85
c26f1670-380b-4135-8454-b6308cfe83ae	2026-05-09 03:51:10.040397+00	2026-05-09 03:51:10.040397+00	password	dd0f0240-a52a-4817-8f51-089637d82c6e
f8cfedfc-bbd8-4fec-9837-cffb780237bc	2026-05-09 03:55:37.937329+00	2026-05-09 03:55:37.937329+00	password	c456644f-7147-49a7-afc8-3ad565babb18
411dd013-b3ae-49d4-afec-bb2318f2c810	2026-05-09 08:56:48.468745+00	2026-05-09 08:56:48.468745+00	password	6c113800-ee76-41a9-b6d0-55b992cc3b9e
d2aeb278-0666-4fce-97f4-b67f59b819a3	2026-05-09 08:57:05.495972+00	2026-05-09 08:57:05.495972+00	password	ed4f3960-9df6-44d2-849d-c3ae9dfecb34
39e8b758-f1db-4777-9160-edc23a7a3fdc	2026-05-10 00:27:00.73288+00	2026-05-10 00:27:00.73288+00	password	442992b5-3e5c-4688-ac37-1b3a79d9acb6
7c515e71-0f87-4ab3-adad-8905fc80ee8f	2026-05-10 01:38:27.892784+00	2026-05-10 01:38:27.892784+00	password	b8960e38-726f-4288-9158-0aaf18e87534
aa8653a4-f2fa-4bf1-8eee-33f2d4962055	2026-05-10 01:42:49.212776+00	2026-05-10 01:42:49.212776+00	password	013a04d7-ebf3-46b0-8e44-51796d59ec2e
dca37899-79e9-4128-9868-d2919b25d223	2026-05-10 02:11:13.374923+00	2026-05-10 02:11:13.374923+00	password	b9d65a73-8ce8-4a8c-887b-3da7b0f2e90c
f1f20aee-43c5-4368-99ac-921f6f91d405	2026-05-10 02:22:30.862538+00	2026-05-10 02:22:30.862538+00	password	6d13e567-1745-49d6-99cf-982d68b904b7
5a6c9ea6-1188-4c21-93a6-b3efb87a6a62	2026-05-10 09:56:26.867948+00	2026-05-10 09:56:26.867948+00	password	f277e111-af05-4d9e-a45b-8c1d6988cb3f
c68b23b6-4a30-480f-b672-e86dc4a40424	2026-05-12 03:33:37.147011+00	2026-05-12 03:33:37.147011+00	password	c0e50524-05a5-4ff2-b6f5-aa29306357e5
f6621222-744f-4704-aa28-e79af2f5cdc9	2026-05-12 03:33:37.41382+00	2026-05-12 03:33:37.41382+00	password	59895795-0795-4bdb-980c-eb21169537c3
2ebb6473-f134-4ccc-9d89-8bb556761f15	2026-05-12 03:55:40.226215+00	2026-05-12 03:55:40.226215+00	password	a6f4bdc1-31f2-4009-a3c0-d7344d989ebe
77216d52-e035-4932-ba7e-95dc667cb37d	2026-05-12 03:59:29.147217+00	2026-05-12 03:59:29.147217+00	password	4f55b6a8-9b42-42f6-86c8-3e070fdd3d99
d1773aa4-e2cf-4f16-9cc7-d8011cef7d4d	2026-05-12 04:06:24.260464+00	2026-05-12 04:06:24.260464+00	password	49db65d1-6925-4d9e-844a-d6337cd2fb01
b52db1d5-6c8c-4995-b853-f397880ae4f9	2026-05-12 04:12:25.474409+00	2026-05-12 04:12:25.474409+00	password	92d1d4ef-bdfa-4586-80de-7ae5b3a8faf1
5a8cf411-baf1-4b30-b544-3c2e7fa015ba	2026-05-12 04:12:28.48356+00	2026-05-12 04:12:28.48356+00	password	22c922bc-e62b-444f-aef1-df79e0e8dbcc
77fb3af8-c054-4368-9646-76975b99daab	2026-05-12 04:28:07.481197+00	2026-05-12 04:28:07.481197+00	password	8affa100-9381-46ce-9176-ac8102982536
951306fa-76e5-4cd6-8af4-a03b3d32a7d4	2026-05-12 04:30:02.753504+00	2026-05-12 04:30:02.753504+00	password	3638b624-6c45-4c8b-98eb-0e37116f0d46
7239565e-2a02-4ae8-a885-79423fc264b5	2026-05-12 06:41:10.82593+00	2026-05-12 06:41:10.82593+00	password	5488594d-57ab-4f14-9622-0d513cf7d0b6
22ea508e-6367-466a-827c-20bb8d5a49b0	2026-05-12 08:17:34.691043+00	2026-05-12 08:17:34.691043+00	password	94324f09-1e61-4936-aad6-37f443c93cac
1e05550b-a835-47de-b6c4-89c3becb4d3d	2026-05-12 08:39:50.508962+00	2026-05-12 08:39:50.508962+00	password	7a42d261-9f8f-433f-b316-a39ff871dd02
d60afcd7-b32f-48b5-bae3-dca6ea401fa5	2026-05-12 08:51:23.357453+00	2026-05-12 08:51:23.357453+00	password	268bdaf3-d99c-4d5d-8fa9-4e3be5701aa9
1f914aeb-48e0-42f8-b2c1-97655312f96b	2026-05-12 09:10:19.626836+00	2026-05-12 09:10:19.626836+00	password	5322783b-ae27-4de7-a7d4-6fd65b0e6018
4d00bd00-001c-441c-8adb-3f1cc803f68e	2026-05-12 09:12:02.797545+00	2026-05-12 09:12:02.797545+00	password	b717c85f-fb19-4fa3-96aa-cb7da9453435
5b87f05b-cae5-422d-9b90-7b064bfa0c0a	2026-05-12 13:21:08.887362+00	2026-05-12 13:21:08.887362+00	password	700e018f-2062-4983-b935-ca6e753b1594
df9d2a92-9a6c-4462-92b9-c735af849ff0	2026-05-12 14:02:32.985368+00	2026-05-12 14:02:32.985368+00	password	db0bb739-312e-4588-a263-8d587debe98c
2777a7c1-042f-4dca-8f0c-45dbd379f32d	2026-05-12 23:34:48.855633+00	2026-05-12 23:34:48.855633+00	password	bdaa37c6-003c-41bc-b3fb-7bd425432d89
1e168b2c-11d4-4092-b676-4c8e788f8538	2026-05-12 23:34:49.148271+00	2026-05-12 23:34:49.148271+00	password	9d1464f3-964d-4e8e-8a5b-596aeedd13a7
ba596001-f01e-4933-975e-9dda2a467689	2026-05-14 03:23:34.453296+00	2026-05-14 03:23:34.453296+00	password	da4d63a1-affd-4c8f-8180-20e7ee599758
c19eba59-c4b0-4aea-830f-e4f19f8b6b57	2026-05-14 03:23:51.679384+00	2026-05-14 03:23:51.679384+00	password	72627d27-1ce8-48a5-8dfd-5c8aa4358c0a
56a07ac3-04d7-4170-a60c-677df48ce0c2	2026-05-15 08:02:54.658634+00	2026-05-15 08:02:54.658634+00	password	3120af93-cad0-4d6a-af6b-4693230d8cf7
2c0ce936-6eed-428e-82b8-3ac1f2b20896	2026-05-15 08:03:27.118743+00	2026-05-15 08:03:27.118743+00	password	d165d3c5-e813-4c92-8475-05363b876526
ac1a3931-538e-47e3-acd7-0d8bc8aeab11	2026-05-15 09:43:06.284618+00	2026-05-15 09:43:06.284618+00	password	51d77814-722e-431b-a75f-d137d0c9060d
8b41447d-9c32-4326-88e3-110c74428913	2026-05-15 10:23:21.385821+00	2026-05-15 10:23:21.385821+00	password	928ead15-e098-4564-944e-4cbf876ed42a
3ba82bd1-8321-4ca5-ac96-1fae1ec0181c	2026-05-18 04:08:36.576523+00	2026-05-18 04:08:36.576523+00	password	57df91ab-4b35-42a7-bc9c-f4de84de1a8d
2267c369-25de-4d41-ac5e-a2a6c1db726d	2026-05-18 06:12:26.447932+00	2026-05-18 06:12:26.447932+00	password	51750870-428f-436e-9364-4c67110a9c34
d34e0fae-d491-403a-86f4-8ac23bdb5b21	2026-05-18 06:15:28.957271+00	2026-05-18 06:15:28.957271+00	password	4254eb03-95cd-492a-b4fd-cff7e474314c
3d9d94be-a801-4d2c-8d9d-ac009eed2490	2026-05-18 08:14:28.451006+00	2026-05-18 08:14:28.451006+00	password	348728a9-0c13-4d09-8a4c-617992ad1953
b3db0ff5-e566-4e01-9e71-8d96ca73f793	2026-05-18 08:14:28.752578+00	2026-05-18 08:14:28.752578+00	password	2832d96e-0803-4527-9b12-d877cf59e124
301ea009-f107-459d-a047-89550e1a5fa1	2026-05-18 08:31:26.307877+00	2026-05-18 08:31:26.307877+00	password	62dc61fa-2b71-42c4-8af0-9eaaf7311e49
b0bfa512-f3f1-4e1b-a670-6b2ec0ca061e	2026-05-18 09:54:09.220298+00	2026-05-18 09:54:09.220298+00	password	2b59138f-9455-4533-b709-9bf35216805e
ff7b77e1-d0da-4e7d-a9fe-66e66212fbd0	2026-05-18 09:54:24.282761+00	2026-05-18 09:54:24.282761+00	password	c88a6188-e5d5-4dce-bd45-e2c65684809c
ac829951-5a35-41ec-a5f4-89d73a923a5b	2026-05-18 10:08:14.81343+00	2026-05-18 10:08:14.81343+00	password	7c1eede7-cf0f-47ab-ae2b-0cbd51ebb6d9
ba5f6d5c-056c-495c-8ee8-40c28dd0c413	2026-05-18 10:09:30.453207+00	2026-05-18 10:09:30.453207+00	password	c7a6b7ca-9df1-45c9-b913-ab4c06b0e4df
a408d35f-c1a0-49af-866e-3daa69f6a218	2026-05-18 10:10:43.328423+00	2026-05-18 10:10:43.328423+00	password	eb200bb3-bcb0-4a21-abf6-9924b3998f66
4d66d408-82ab-46de-a7b6-934f9e7eeaaa	2026-05-18 10:23:46.249735+00	2026-05-18 10:23:46.249735+00	password	115de22c-213c-4659-9963-670d450a4a5b
2c24d48f-886c-48c1-8033-d4c3baa33181	2026-05-18 10:28:58.665936+00	2026-05-18 10:28:58.665936+00	password	8982b1db-d2cb-49df-9398-12a8ca67525e
93d9de5e-25f0-4ac9-a89d-0e181191a7cd	2026-05-18 11:05:27.787919+00	2026-05-18 11:05:27.787919+00	password	403f4411-1c24-47f2-884e-2b162329c354
6d57fa82-abff-4e10-8999-0e08f39bec07	2026-05-18 11:05:48.822039+00	2026-05-18 11:05:48.822039+00	password	f9261dfd-fbb1-4c74-ae1d-a213256f7f9e
178edd41-53bd-41f6-aa72-5682326ecd16	2026-05-18 11:05:49.093951+00	2026-05-18 11:05:49.093951+00	password	81c24a26-6191-4c65-bc4f-295af60a74a0
281b0af4-4387-42c9-b740-75e26f4a86ea	2026-05-18 12:37:54.506591+00	2026-05-18 12:37:54.506591+00	password	dbb66e8c-9020-4ff9-a2b0-db44f9a26030
173bdbdc-9ed8-431e-a70b-005c30c9b18c	2026-05-18 13:02:00.990517+00	2026-05-18 13:02:00.990517+00	password	9e9b211c-cb61-4d18-b2e2-fe9ff2e04994
1812dafd-f0c3-46e3-87f1-47e582dba5c6	2026-05-18 13:02:01.214834+00	2026-05-18 13:02:01.214834+00	password	a8d83b9a-7c98-4877-b64d-106afbfe02f7
56a558f9-91d8-4314-9657-fe5ab0b3fe39	2026-05-18 13:02:04.202959+00	2026-05-18 13:02:04.202959+00	password	ec2636e0-7655-4d5a-b576-c058c27adfd8
787f349d-0811-4b90-899c-a78659a6e9e4	2026-05-18 13:02:08.907367+00	2026-05-18 13:02:08.907367+00	password	8838cc10-8028-492f-b382-70882c866647
a273fcc9-ee59-4450-9cb6-df0c9da8f5d0	2026-05-18 13:02:14.602227+00	2026-05-18 13:02:14.602227+00	password	ae337ba4-c99c-41eb-89b3-c5b551af50e7
5aaaac41-8517-4c2a-8032-3d4558b4cdad	2026-05-18 13:02:18.551428+00	2026-05-18 13:02:18.551428+00	password	ee26799a-3f1d-468e-9231-c0d755f250af
7610f4c3-8829-444e-b095-a1053a3ebf4e	2026-05-18 13:02:22.056322+00	2026-05-18 13:02:22.056322+00	password	1d5d8cb9-36c2-48c8-bc06-77712540c2d7
077d4037-bff8-44e0-b512-41064312a15a	2026-05-18 13:02:31.769417+00	2026-05-18 13:02:31.769417+00	password	eeef0434-621d-40bd-b135-5a1f84f095de
7157f531-a0a6-4885-a1e5-5bbfa26eef79	2026-05-18 13:02:36.405816+00	2026-05-18 13:02:36.405816+00	password	973e6dcb-7fcc-4d67-be34-7472c9698b7f
dc834374-9cbe-409c-8415-890821d4a1cf	2026-05-18 13:03:40.204807+00	2026-05-18 13:03:40.204807+00	password	705aada6-5d19-40c3-89f4-556ccf4df64b
6f43e9ca-0450-4a4c-8046-53528ca63fb2	2026-05-18 13:03:46.305027+00	2026-05-18 13:03:46.305027+00	password	cf5586c8-d995-4653-a106-ac38407391a5
6bd75a30-b7e0-4c78-b691-1f95c4578c91	2026-05-18 13:03:52.826456+00	2026-05-18 13:03:52.826456+00	password	3d8d52fd-c3e3-42e2-b9ba-574979c3cc8d
fc9a9266-354d-42c0-bf31-88f379ddf804	2026-05-18 13:04:55.000425+00	2026-05-18 13:04:55.000425+00	password	6c90e336-3f4c-4dce-9b8c-27f98be6fa6b
0145cc85-5691-435d-ad55-8eab30cc0984	2026-05-18 13:05:08.84724+00	2026-05-18 13:05:08.84724+00	password	965da258-26f5-4409-aa09-5b618434a1db
298fcc0c-55c4-4360-b565-f10207a39720	2026-05-18 13:06:01.414411+00	2026-05-18 13:06:01.414411+00	password	89b00337-f9fe-412d-a5ab-e0289007636c
eedcda3d-ddca-4dcd-9963-76557e88415e	2026-05-18 13:06:31.88836+00	2026-05-18 13:06:31.88836+00	password	21c4b1cb-1352-411e-87c0-6ac82b05b756
9e53e2ef-f449-4f60-a723-f5d36105a677	2026-05-18 13:06:34.700848+00	2026-05-18 13:06:34.700848+00	password	16fdb291-e028-4de4-9954-66fc89743e2b
45a78244-e0b5-4800-a0a6-6d4b8d77b1d9	2026-05-19 00:10:26.255767+00	2026-05-19 00:10:26.255767+00	password	8bd3992b-b55c-493b-8319-9648d561d63a
403f4ce5-7ae0-47bb-8c39-5bbe942ed4f9	2026-05-20 09:26:11.539712+00	2026-05-20 09:26:11.539712+00	password	40b28aa8-2ff4-43a3-a5da-ad74cb1e5f7f
fa339652-cd72-40ea-ba85-1a74a7ac69aa	2026-05-20 09:29:29.517867+00	2026-05-20 09:29:29.517867+00	password	21f3318c-07c3-4616-bec4-bbdcdf31b28c
9650b067-00cf-4467-9bab-26c6971b506d	2026-05-20 10:16:05.115586+00	2026-05-20 10:16:05.115586+00	password	d71d79e2-527f-41d5-86dc-3c8a7ea123a2
b55abdfb-eee2-4d74-ba51-db2efd6bd37f	2026-05-20 10:16:57.385923+00	2026-05-20 10:16:57.385923+00	password	b9848226-bcd7-4702-8df6-cb96fb4d4061
718b35c6-8d24-4290-b73a-b23ef6886f7c	2026-05-20 10:31:04.263948+00	2026-05-20 10:31:04.263948+00	password	9bfc3080-60e1-48b1-8601-a6e5b5fbcb85
f5d23264-269e-441f-a54a-98cc655586c6	2026-05-20 10:31:31.481716+00	2026-05-20 10:31:31.481716+00	password	bc7b6493-1692-4fc9-9f4b-8299907c5fc3
9f13e170-8b46-4398-9311-fbeb9e4df81e	2026-05-20 10:32:05.809295+00	2026-05-20 10:32:05.809295+00	password	e7e1072e-0430-493d-9c7f-b5a771b7aede
99c5a4a8-3ae9-4d40-b307-c2c733aa45c0	2026-05-20 10:33:21.916071+00	2026-05-20 10:33:21.916071+00	password	068a2b65-f1aa-473f-87aa-80648acfcb7a
3e540e7a-1663-46b1-993d-4fc552d9ee71	2026-05-20 11:11:02.257294+00	2026-05-20 11:11:02.257294+00	password	fc6bcf19-e0b5-40b1-8664-e4613e4a7520
23fa685a-8a86-4bd6-9ace-e59d31ef4934	2026-05-20 11:13:45.06951+00	2026-05-20 11:13:45.06951+00	password	9c181f90-2c89-4a35-9d87-e228b8f39592
c961e55c-311d-4fff-9aaa-53c8bae47578	2026-05-21 06:37:58.867867+00	2026-05-21 06:37:58.867867+00	password	c1943f94-c22b-4773-b6ba-47fb60612af7
48d65a47-d38a-41ae-ac93-f86e647ffcb0	2026-05-21 06:38:37.50173+00	2026-05-21 06:38:37.50173+00	password	66d2e259-d430-428a-a0eb-f061e89818a9
e79dd47d-76bd-4f67-9ed9-f7bedbd770a3	2026-05-21 07:06:41.434543+00	2026-05-21 07:06:41.434543+00	password	1e5734fb-3dde-4921-a7ce-811c1aa9fd96
e5c5d073-5be8-4eb3-a6fd-923c101e1af1	2026-05-21 07:20:33.691921+00	2026-05-21 07:20:33.691921+00	password	3ffeabd7-52c2-4fc1-885c-575fe13317f2
ea8dad74-f70d-438c-8526-cc46490b27b2	2026-05-21 07:25:53.246918+00	2026-05-21 07:25:53.246918+00	password	5362d583-fce7-43f0-954e-ad6456805621
22db4a20-9d90-4d8f-9238-2fc87d44ca8b	2026-05-21 07:27:31.713956+00	2026-05-21 07:27:31.713956+00	password	035a3d1f-19e7-4595-b80b-6c58c2857d0e
eddca24c-cb63-455b-9d60-83fb02e06ba0	2026-05-21 07:27:53.990637+00	2026-05-21 07:27:53.990637+00	password	e02a9536-66df-40b1-8304-0677edfc57ce
b0bd8c31-6419-4c4e-b99a-315327dc19d1	2026-05-21 07:28:09.148494+00	2026-05-21 07:28:09.148494+00	password	473f3a6d-09ee-4b48-9460-476f6c3435aa
b5726f4e-5818-495a-9ae6-64502b093101	2026-05-21 07:44:24.599995+00	2026-05-21 07:44:24.599995+00	password	b2d93858-f493-46b7-ace0-f266498bb700
9cc68a49-4bd7-450a-9bac-2170d2bb9986	2026-05-21 08:30:48.923172+00	2026-05-21 08:30:48.923172+00	password	da4aca4a-c5c5-405e-a673-a134a7cd5599
de9475b5-d803-4ebe-b3b9-374ddbfecb34	2026-05-21 08:42:28.500588+00	2026-05-21 08:42:28.500588+00	password	afe6c9aa-bc44-44a9-ae94-c53d2840ec0d
fa513c6d-6a2e-4da8-9f86-8fd529a87df6	2026-05-21 08:45:05.241772+00	2026-05-21 08:45:05.241772+00	password	0b82ef71-5f9c-4212-9757-c078839e2046
784300a9-8a3e-4390-aa42-3065063e4d07	2026-05-21 08:45:41.216654+00	2026-05-21 08:45:41.216654+00	password	3e39929d-2fc9-41be-9315-3e65fa3b63bd
d63f1d54-62c1-4c78-9cd4-7e8ffaa6ae7d	2026-05-21 08:47:08.181003+00	2026-05-21 08:47:08.181003+00	password	dc8f12fa-16a4-42ff-95f7-2787c9129da8
46dfae19-78ed-4b2b-af7c-63986cbd74aa	2026-05-21 13:31:13.406507+00	2026-05-21 13:31:13.406507+00	password	cbc5740f-58e0-481b-858c-c94c88165548
283c23e1-cc38-4c9b-85dd-3ecd554b09ae	2026-05-21 13:39:07.611477+00	2026-05-21 13:39:07.611477+00	password	561dc0d0-939f-4214-8e40-659214375723
c4b8a017-9ec0-404c-922b-3faf9d1d0801	2026-05-21 13:39:49.503049+00	2026-05-21 13:39:49.503049+00	password	92041351-70d0-43c5-a0d6-89414a22869e
b36e0ec7-3f50-4b01-9df8-dd3c4fa0c1ab	2026-05-21 14:01:12.629134+00	2026-05-21 14:01:12.629134+00	password	e75dc46e-a7e9-4e40-ab98-1ef9a469e773
96d35821-a260-4954-8329-7649210b0214	2026-05-21 22:22:49.412448+00	2026-05-21 22:22:49.412448+00	password	24c04206-52dc-443c-90b0-e8ecdea05fae
77dafdca-349c-456e-85b7-448b181ce5eb	2026-05-22 02:12:01.672711+00	2026-05-22 02:12:01.672711+00	password	a30fa00e-fa16-46a1-8ff6-5968e8920b6f
457666af-61bc-4bcb-b890-deab4753d655	2026-05-22 02:15:29.207083+00	2026-05-22 02:15:29.207083+00	password	e9b4f81c-eb53-4a84-bfcd-c88fdfb99ba2
1cf5af7a-4330-4772-9dc7-f1217403bee6	2026-05-22 02:18:01.814741+00	2026-05-22 02:18:01.814741+00	password	75df0f32-3d46-47ba-a637-19cfa459f3eb
bb9f3c3d-b297-4c32-98c8-f3cf3c4cc484	2026-05-22 07:50:45.477758+00	2026-05-22 07:50:45.477758+00	password	05c046bb-28f9-47df-90dd-1aa779573a98
8238c927-83c9-4054-9a12-53acc1d66929	2026-05-22 15:06:51.501824+00	2026-05-22 15:06:51.501824+00	password	20681a7a-4a49-435b-b8d0-a386ac36e97b
02bc7fff-98c3-43ad-86ab-28925e678009	2026-05-22 15:56:39.1476+00	2026-05-22 15:56:39.1476+00	password	224e082b-35f4-406a-b79d-4da0a431bb98
975c401c-8e8d-4a1a-9879-c69722702e0d	2026-05-23 10:47:48.414194+00	2026-05-23 10:47:48.414194+00	password	12525469-8ac7-4f33-bb63-52b25bd29018
52f853d9-9eab-4876-b6b0-43b6e1c7880e	2026-05-23 11:11:22.675625+00	2026-05-23 11:11:22.675625+00	password	c005a418-decf-4008-be3f-cae7dde271a4
fd8f66da-70d6-4b14-8746-c4341d602dca	2026-05-23 11:11:53.854694+00	2026-05-23 11:11:53.854694+00	password	39fe33c8-e2ef-4842-9efb-aa0192009d55
f3fa874b-4e67-4a59-bf93-a8894c56dc21	2026-05-23 11:13:20.571239+00	2026-05-23 11:13:20.571239+00	password	c152383e-c4da-4d13-a318-093a8a79b017
e71b1cde-0aa7-49dc-98f1-d3aac63eec8e	2026-05-23 12:38:36.087693+00	2026-05-23 12:38:36.087693+00	password	dfc29b32-8ad6-43c8-851d-9d5d13d9c379
9131093e-a99e-44fe-a072-0894450b6fbc	2026-05-24 08:14:17.156368+00	2026-05-24 08:14:17.156368+00	password	3aee4158-aa9a-4f3b-a2d3-dcf1bf284168
a15943b5-992b-4578-8ee9-e1e2c7ee156e	2026-05-24 08:36:52.609421+00	2026-05-24 08:36:52.609421+00	password	2451b5f0-28fe-43b9-b29e-db4f728f12bb
8bab0b44-e764-4f42-b2d5-e318725f1734	2026-05-24 08:48:14.831865+00	2026-05-24 08:48:14.831865+00	password	27833b0d-d3b2-4c74-90db-a4e58f0e5e4c
931f3634-9901-4777-b724-c3df2dd671bc	2026-05-24 09:06:33.54744+00	2026-05-24 09:06:33.54744+00	password	e55532bf-5867-437e-98d3-132a58884d3d
48d564af-f6fe-4061-81c9-c6a61ad16e01	2026-05-24 09:08:39.662346+00	2026-05-24 09:08:39.662346+00	password	3c56ce3c-704e-47a3-9228-3681488690ed
b74e8776-ad72-49c7-aa44-18dacaedf981	2026-05-24 09:57:07.184905+00	2026-05-24 09:57:07.184905+00	password	e5777fed-7bd4-4614-a158-bf14b84ebbe4
8b4d20e2-3163-4cfd-a003-cdb5ce4f1338	2026-05-27 08:37:28.997344+00	2026-05-27 08:37:28.997344+00	password	0496846b-1f63-4ca6-a539-67a04b1a0111
c835c00e-cb33-4e73-9bc0-fe568684a28f	2026-05-30 09:11:27.851334+00	2026-05-30 09:11:27.851334+00	password	4021425b-b137-4cf5-b30d-75e785e4c764
0a7cd3f3-b5ff-477c-8c9e-99708168fcec	2026-06-02 08:26:11.781176+00	2026-06-02 08:26:11.781176+00	password	d44bb3fd-fcb1-4e42-91b0-c02d85073fc0
c2695ce5-1b4d-4470-9385-09bb30729934	2026-06-03 11:16:32.458815+00	2026-06-03 11:16:32.458815+00	password	6880ef9f-8b05-4d9d-8034-5b59ab20ae3f
1657630c-a6b6-4d4b-aa47-068334954bd4	2026-06-03 14:07:25.70696+00	2026-06-03 14:07:25.70696+00	password	bb366cbe-6a4d-449f-8232-3d723539f002
3a3565fe-10d8-422b-8952-cde21c275df5	2026-06-06 01:59:04.776435+00	2026-06-06 01:59:04.776435+00	password	1638a8b7-2064-4ef9-b4fb-c2288317c980
cd501d74-ce02-4630-8f9d-1b95177b998b	2026-06-16 10:18:23.724011+00	2026-06-16 10:18:23.724011+00	password	726201c4-2bdf-42ba-b6bd-d1208f689ed8
7a740360-2e6d-42ad-b659-ca3312d3684d	2026-06-19 03:03:05.666083+00	2026-06-19 03:03:05.666083+00	password	a721d6a5-d5b9-4249-b9f8-16bbd8ac53f2
3c2db4f4-ed7d-430b-9274-ef08068b5efe	2026-06-21 09:33:29.556534+00	2026-06-21 09:33:29.556534+00	password	e781c043-acaa-4fb5-be5b-f0ce4ee2586d
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
00000000-0000-0000-0000-000000000000	1	jogdhgxxrv4j	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 04:21:33.211117+00	2026-05-02 04:21:33.211117+00	\N	33b7d1ab-6afa-4e78-8054-9f10d6785317
00000000-0000-0000-0000-000000000000	2	uc75bqjxmirk	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 04:21:33.467532+00	2026-05-02 04:21:33.467532+00	\N	fe48fec9-e8ab-45bf-9784-95306b918f50
00000000-0000-0000-0000-000000000000	3	33342ifkywdc	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 04:21:46.069081+00	2026-05-02 04:21:46.069081+00	\N	d80eeef9-7f60-430e-aa92-7338c610945f
00000000-0000-0000-0000-000000000000	461	ogn7ovjmd4xe	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-13 00:33:19.260045+00	2026-05-13 00:33:19.260045+00	malc262arcvp	1e168b2c-11d4-4092-b676-4c8e788f8538
00000000-0000-0000-0000-000000000000	5	q2qfupctxjay	964af5e8-7c20-40b1-b6ff-3a448dfc265a	f	2026-05-02 04:23:38.024154+00	2026-05-02 04:23:38.024154+00	\N	45754a10-35ca-4df9-b875-d663f5bd909c
00000000-0000-0000-0000-000000000000	6	xkipfz4hfmic	964af5e8-7c20-40b1-b6ff-3a448dfc265a	f	2026-05-02 04:23:38.139767+00	2026-05-02 04:23:38.139767+00	\N	57a1e782-c07e-4939-8c69-91b13f802291
00000000-0000-0000-0000-000000000000	7	jdmx747s34km	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 04:24:03.427063+00	2026-05-02 04:24:03.427063+00	\N	b3307f87-98fe-4dad-89ce-8601e272788a
00000000-0000-0000-0000-000000000000	8	5iafelwzczb5	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-02 04:28:31.283755+00	2026-05-02 04:28:31.283755+00	\N	804d6c6c-ca99-41d3-990d-6bfd4ffad049
00000000-0000-0000-0000-000000000000	9	ntkkpyvtneqw	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-02 04:28:31.488199+00	2026-05-02 04:28:31.488199+00	\N	cf9830e4-6181-47ea-81e9-d5a240f1b268
00000000-0000-0000-0000-000000000000	12	4jhpplkbiejx	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 04:40:47.135403+00	2026-05-02 04:40:47.135403+00	\N	a92d68db-1b89-4e69-aa57-ba5bf6fc7f31
00000000-0000-0000-0000-000000000000	13	xofqhwpoll23	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 04:40:51.343709+00	2026-05-02 04:40:51.343709+00	\N	96eeb8b7-fcc0-4f65-9a07-c3faef5de35a
00000000-0000-0000-0000-000000000000	14	j2md2b3p7rus	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 04:40:55.815723+00	2026-05-02 04:40:55.815723+00	\N	e1580ec9-13cb-4eba-824d-3309cd46673f
00000000-0000-0000-0000-000000000000	15	nil3ppdmmxhr	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 04:40:59.172391+00	2026-05-02 04:40:59.172391+00	\N	06ac7d91-24e8-432a-8035-9dbc6b58eea2
00000000-0000-0000-0000-000000000000	16	6fkum4x4yszy	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 04:41:02.425354+00	2026-05-02 04:41:02.425354+00	\N	b67d3dd7-de96-4d3e-ac0d-0dd2f7719857
00000000-0000-0000-0000-000000000000	17	c2dqwmqynauh	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 04:41:05.931897+00	2026-05-02 04:41:05.931897+00	\N	392d861d-3204-432f-bb0e-2056b90df667
00000000-0000-0000-0000-000000000000	18	wfzbexo5kknq	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 04:41:13.936876+00	2026-05-02 04:41:13.936876+00	\N	026083a6-1d23-410b-96d4-8597b44e1b61
00000000-0000-0000-0000-000000000000	21	lys6oq4ntkbn	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 04:58:20.19619+00	2026-05-02 04:58:20.19619+00	\N	88de18de-51fc-44d8-b4be-589d24024016
00000000-0000-0000-0000-000000000000	11	vszsumfyhpta	f38b5572-029f-4d74-ac31-3d5e278df151	t	2026-05-02 04:34:40.324146+00	2026-05-02 05:53:40.500103+00	\N	821e4a8e-f196-4463-8955-3143be845fa2
00000000-0000-0000-0000-000000000000	23	payl23itow6b	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-02 05:53:40.50489+00	2026-05-02 05:53:40.50489+00	vszsumfyhpta	821e4a8e-f196-4463-8955-3143be845fa2
00000000-0000-0000-0000-000000000000	24	5ncja53lg7e7	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-02 05:53:44.320398+00	2026-05-02 05:53:44.320398+00	\N	06f81853-71c5-41a3-a9ef-fd26babaee86
00000000-0000-0000-0000-000000000000	25	z3ilvp4fiii3	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-02 05:53:49.879003+00	2026-05-02 05:53:49.879003+00	\N	cc270bd5-e464-4abf-ad82-45f365a5ce65
00000000-0000-0000-0000-000000000000	19	72za2xybrdkk	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-02 04:42:27.591191+00	2026-05-02 05:54:41.787314+00	\N	b6bb26ff-1681-4569-9860-b60c2bb4cd1b
00000000-0000-0000-0000-000000000000	26	m2vigsdvuabz	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 05:54:41.798595+00	2026-05-02 05:54:41.798595+00	72za2xybrdkk	b6bb26ff-1681-4569-9860-b60c2bb4cd1b
00000000-0000-0000-0000-000000000000	27	sqbx7fq32m6j	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 05:55:01.477101+00	2026-05-02 05:55:01.477101+00	\N	dc79cde6-2e0f-469f-8b84-34a0d28f9b31
00000000-0000-0000-0000-000000000000	28	ww4yyzu4tqa5	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 05:55:09.530118+00	2026-05-02 05:55:09.530118+00	\N	754e992e-fa7b-408d-897a-282c738fa033
00000000-0000-0000-0000-000000000000	29	vpfz62c2wfa7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 05:55:26.016545+00	2026-05-02 05:55:26.016545+00	\N	c49a3657-35a0-4a1c-909b-4d96ed90d760
00000000-0000-0000-0000-000000000000	30	2a7dcbj3fa44	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 05:57:21.771487+00	2026-05-02 05:57:21.771487+00	\N	96a31004-fc0c-4089-9b23-5157395e0ada
00000000-0000-0000-0000-000000000000	31	guk67jt2bbj2	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 05:57:23.589075+00	2026-05-02 05:57:23.589075+00	\N	705862d9-316f-44cd-9b78-894aeb5849e8
00000000-0000-0000-0000-000000000000	32	4g26goojrzsa	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 05:57:26.427495+00	2026-05-02 05:57:26.427495+00	\N	e5e90106-5c37-4cac-b92e-04f516686b91
00000000-0000-0000-0000-000000000000	33	vys6ukl2uiwz	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 05:57:39.373059+00	2026-05-02 05:57:39.373059+00	\N	53e3d7bf-bb34-4163-ba07-88c033a433eb
00000000-0000-0000-0000-000000000000	34	hzyuh7yz7263	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 05:58:15.008913+00	2026-05-02 05:58:15.008913+00	\N	5e277aad-a35f-4e3e-9e48-4c6a22e87211
00000000-0000-0000-0000-000000000000	35	ud4rp754zlie	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 06:00:03.490811+00	2026-05-02 06:00:03.490811+00	\N	3c15d471-3d8f-44a1-aa25-1ed0df78014d
00000000-0000-0000-0000-000000000000	36	mbnpv7zizwla	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-02 06:37:21.80999+00	2026-05-02 06:37:21.80999+00	\N	bd699fce-89d6-4ece-8206-8d0014a68d35
00000000-0000-0000-0000-000000000000	37	c5zzx32fw4m5	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-02 06:37:24.183547+00	2026-05-02 06:37:24.183547+00	\N	f78530e3-fde5-41ae-9447-d7ad678cfe6d
00000000-0000-0000-0000-000000000000	38	iz4xefo63zr6	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-02 06:37:26.413447+00	2026-05-02 06:37:26.413447+00	\N	ad8c3800-408e-4cef-a792-6f7e52d6c934
00000000-0000-0000-0000-000000000000	39	6ivndny5fdv3	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-02 06:37:59.629813+00	2026-05-02 06:37:59.629813+00	\N	d6eb78ec-5c35-4d7e-88e4-2263e73d778f
00000000-0000-0000-0000-000000000000	40	kli5tmbj2wlo	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-02 06:38:02.017658+00	2026-05-02 06:38:02.017658+00	\N	c3153f94-b511-4422-8b04-8dcb9af1a41e
00000000-0000-0000-0000-000000000000	41	kl5q52a7cwxj	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-02 06:38:05.474909+00	2026-05-02 06:38:05.474909+00	\N	e2d9a855-e6be-4c0d-8288-639a122b6f3e
00000000-0000-0000-0000-000000000000	4	kprndvqkmvkt	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-02 04:23:29.594753+00	2026-05-02 06:38:11.343031+00	\N	466e6a53-e33d-48f9-95ae-f09fb3b3115a
00000000-0000-0000-0000-000000000000	42	tnojtnlriy7y	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 06:38:11.344582+00	2026-05-02 06:38:11.344582+00	kprndvqkmvkt	466e6a53-e33d-48f9-95ae-f09fb3b3115a
00000000-0000-0000-0000-000000000000	43	32s53xsaduzx	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 06:38:14.414917+00	2026-05-02 06:38:14.414917+00	\N	bdc32057-66ff-41a6-93a9-940be1bc0d09
00000000-0000-0000-0000-000000000000	44	pnxwt6oyigqo	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 06:39:16.050193+00	2026-05-02 06:39:16.050193+00	\N	514591f8-e3de-4fa7-9d7f-eb7aca8583af
00000000-0000-0000-0000-000000000000	20	s6l56ux2kiaa	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-02 04:45:45.473882+00	2026-05-02 06:55:12.469245+00	\N	7677b361-1287-4171-838b-fcaeef3064fc
00000000-0000-0000-0000-000000000000	45	hpfyp55ugueu	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 06:55:12.476243+00	2026-05-02 06:55:12.476243+00	s6l56ux2kiaa	7677b361-1287-4171-838b-fcaeef3064fc
00000000-0000-0000-0000-000000000000	46	jniwh65yizic	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 06:55:13.584104+00	2026-05-02 06:55:13.584104+00	\N	e6f1f035-a515-4098-be59-6d15e041e217
00000000-0000-0000-0000-000000000000	47	qnnibzs5opxf	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-02 06:56:18.865425+00	2026-05-02 08:52:49.709047+00	\N	d0894bda-d535-449f-bf40-8de4aaddbf1c
00000000-0000-0000-0000-000000000000	48	ainsi22f3phb	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 08:52:49.721935+00	2026-05-02 08:52:49.721935+00	qnnibzs5opxf	d0894bda-d535-449f-bf40-8de4aaddbf1c
00000000-0000-0000-0000-000000000000	49	k7vwxpwyhxbr	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 08:52:50.771017+00	2026-05-02 08:52:50.771017+00	\N	a84a833c-a2b5-44f4-8c2a-a399a379d936
00000000-0000-0000-0000-000000000000	50	o4hyr33eq4lk	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 08:53:44.266759+00	2026-05-02 08:53:44.266759+00	\N	2e9522de-c53c-4553-9fb4-83d3b84dee12
00000000-0000-0000-0000-000000000000	51	pgkc5bw3bx43	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 09:00:08.833482+00	2026-05-02 09:00:08.833482+00	\N	650b000f-04ff-4b36-b79f-b3132ea261e6
00000000-0000-0000-0000-000000000000	52	sewt4pdyyd6n	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 09:00:20.090916+00	2026-05-02 09:00:20.090916+00	\N	c4c78cf4-2454-4f6b-9521-a25cdb1a6372
00000000-0000-0000-0000-000000000000	53	hlk6rz6vddre	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 09:02:29.697795+00	2026-05-02 09:02:29.697795+00	\N	0aec5984-ed0b-43ca-a858-b799ae654320
00000000-0000-0000-0000-000000000000	22	osuerpvlezug	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-02 04:58:38.548624+00	2026-05-04 09:37:40.739619+00	\N	1c8aaf7a-e986-442a-a4f1-cd23f00965e7
00000000-0000-0000-0000-000000000000	10	vz2yoy65jd7m	f38b5572-029f-4d74-ac31-3d5e278df151	t	2026-05-02 04:33:51.186786+00	2026-05-05 09:39:52.707222+00	\N	28a05a6c-f93c-4ae7-a2fe-515a017b22b2
00000000-0000-0000-0000-000000000000	462	qiirv6tzcnik	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-14 03:23:34.396646+00	2026-05-14 03:23:34.396646+00	\N	ba596001-f01e-4933-975e-9dda2a467689
00000000-0000-0000-0000-000000000000	55	mfxhg4ulsqyn	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 12:19:36.20841+00	2026-05-02 12:19:36.20841+00	\N	88064374-0038-4f87-9c89-33b03b2c6ebb
00000000-0000-0000-0000-000000000000	56	flsqcx6m55mb	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 12:19:37.125047+00	2026-05-02 12:19:37.125047+00	\N	56f40644-a46e-4b9d-bc70-9aaaeccdb16d
00000000-0000-0000-0000-000000000000	57	5bxcczlmlyek	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 12:20:41.533345+00	2026-05-02 12:20:41.533345+00	\N	21c543e6-45e1-421c-a020-9452576cc618
00000000-0000-0000-0000-000000000000	54	4pb4e75kus4h	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-02 09:03:06.113654+00	2026-05-02 15:16:12.987594+00	\N	382e79a5-86cc-48ce-9330-bb3af3120d37
00000000-0000-0000-0000-000000000000	59	ujkltcm2q7s7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-02 15:16:13.002446+00	2026-05-02 15:16:13.002446+00	4pb4e75kus4h	382e79a5-86cc-48ce-9330-bb3af3120d37
00000000-0000-0000-0000-000000000000	60	nixzvzoxwjfd	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-02 15:16:13.90275+00	2026-05-03 01:56:29.743819+00	\N	0d3579c1-e372-4e2b-bb02-69db33b9bc26
00000000-0000-0000-0000-000000000000	62	3ayzkmjdtfy4	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 01:56:29.764295+00	2026-05-03 01:56:29.764295+00	nixzvzoxwjfd	0d3579c1-e372-4e2b-bb02-69db33b9bc26
00000000-0000-0000-0000-000000000000	63	hcwbfjq5zntq	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 01:56:30.814016+00	2026-05-03 01:56:30.814016+00	\N	9ff2d49a-0569-4ccd-8a2a-07613b12a4cc
00000000-0000-0000-0000-000000000000	64	xixiih7zbbtf	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 02:47:02.861248+00	2026-05-03 02:47:02.861248+00	\N	d78cba54-dfa1-45d7-9b3c-93bed98faf41
00000000-0000-0000-0000-000000000000	65	fo6hcthh6uez	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 02:47:14.196321+00	2026-05-03 04:01:20.679556+00	\N	3f72b81d-e0bf-4670-a270-a11e881e5a4b
00000000-0000-0000-0000-000000000000	66	dnzwvrl6r3y2	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 04:01:20.689997+00	2026-05-03 04:01:20.689997+00	fo6hcthh6uez	3f72b81d-e0bf-4670-a270-a11e881e5a4b
00000000-0000-0000-0000-000000000000	61	pkhzdtwrwxvk	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-02 18:44:40.746735+00	2026-05-03 04:39:12.42748+00	\N	23b7c766-3cb4-4a2c-9f25-dc5b8fd3e2a7
00000000-0000-0000-0000-000000000000	68	y44goet5j2vd	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 04:39:12.432128+00	2026-05-03 04:39:12.432128+00	pkhzdtwrwxvk	23b7c766-3cb4-4a2c-9f25-dc5b8fd3e2a7
00000000-0000-0000-0000-000000000000	67	khfcuxlz25u2	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 04:01:21.817735+00	2026-05-03 05:23:37.509358+00	\N	6a7349b7-75e7-4c97-83fd-9d17fbb07ffc
00000000-0000-0000-0000-000000000000	70	2zmndmyx3rc3	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 05:23:37.521833+00	2026-05-03 05:23:37.521833+00	khfcuxlz25u2	6a7349b7-75e7-4c97-83fd-9d17fbb07ffc
00000000-0000-0000-0000-000000000000	71	su5rtvcci26x	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 05:23:38.376151+00	2026-05-03 05:23:38.376151+00	\N	a52311de-cdd2-4a89-84ae-8eedf990bbda
00000000-0000-0000-0000-000000000000	72	twtf64gnokce	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 05:23:52.015479+00	2026-05-03 05:23:52.015479+00	\N	ad9840ec-a4da-4fa8-a435-76bbecd7797f
00000000-0000-0000-0000-000000000000	73	574zljyxwjsf	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 05:24:06.513666+00	2026-05-03 05:24:06.513666+00	\N	b9321a65-c87f-4f04-b85a-dff2e11a17f0
00000000-0000-0000-0000-000000000000	75	vbvv255tkqeu	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 07:29:39.179094+00	2026-05-03 07:29:39.179094+00	\N	d4805735-6eb4-4564-8cd3-83a83d78161f
00000000-0000-0000-0000-000000000000	76	pifapbptquhb	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 07:29:57.271414+00	2026-05-03 07:29:57.271414+00	\N	9ee81a2d-a12f-4aed-a93b-1f433fcefa1e
00000000-0000-0000-0000-000000000000	77	7cmhjdi32yh7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 07:31:22.222974+00	2026-05-03 07:31:22.222974+00	\N	c0090a18-ab2b-4241-8232-6b35d64d2331
00000000-0000-0000-0000-000000000000	78	m3xv52v2mpuh	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 07:31:45.514127+00	2026-05-03 07:31:45.514127+00	\N	768d1a95-0656-47b9-a287-de7cf7527a9f
00000000-0000-0000-0000-000000000000	79	6xrpshyveriw	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 07:56:39.259288+00	2026-05-03 07:56:39.259288+00	\N	b3768cfd-d804-4614-8e89-3f8706254c0c
00000000-0000-0000-0000-000000000000	80	hjuhsiwp6etc	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 07:58:57.602811+00	2026-05-03 07:58:57.602811+00	\N	56526efc-a07a-478d-8d21-c8b6daf81614
00000000-0000-0000-0000-000000000000	81	kbhrjwowzdtj	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 07:59:40.71569+00	2026-05-03 07:59:40.71569+00	\N	247d96af-6468-451c-a0f4-bb7f60f1602c
00000000-0000-0000-0000-000000000000	74	drfcthw4acb5	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 05:32:28.525868+00	2026-05-03 10:27:07.076216+00	\N	b715b6bc-65aa-4eae-8152-45c4662c8810
00000000-0000-0000-0000-000000000000	84	poq2um5tf2le	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 10:27:07.082575+00	2026-05-03 10:27:07.082575+00	drfcthw4acb5	b715b6bc-65aa-4eae-8152-45c4662c8810
00000000-0000-0000-0000-000000000000	86	vtlw2rkwcl6l	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 11:13:58.79903+00	2026-05-03 11:13:58.79903+00	\N	7a277f46-870b-4b87-b4e4-f675fa56ee59
00000000-0000-0000-0000-000000000000	87	jrnoyiyjpwl5	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 11:52:38.367185+00	2026-05-03 11:52:38.367185+00	\N	4cae1f82-8a7b-47d8-b29c-5c5b2c8ed74b
00000000-0000-0000-0000-000000000000	88	cokxf2oitjtm	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 11:54:34.34538+00	2026-05-03 11:54:34.34538+00	\N	561e4790-29c5-4a5d-80a8-120e433316d9
00000000-0000-0000-0000-000000000000	90	fxgq4kx5zym6	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 13:13:34.625997+00	2026-05-03 13:13:34.625997+00	\N	2cce2503-5db3-4118-8a57-57002c6c48f5
00000000-0000-0000-0000-000000000000	85	6ahqe24hqqkw	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 10:27:08.236133+00	2026-05-03 13:16:25.923395+00	\N	ebf24002-4d07-43ad-b133-359f38413558
00000000-0000-0000-0000-000000000000	91	lnbc3jbiicxt	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 13:16:25.929458+00	2026-05-03 13:16:25.929458+00	6ahqe24hqqkw	ebf24002-4d07-43ad-b133-359f38413558
00000000-0000-0000-0000-000000000000	92	zfj7faeknt5v	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 13:16:26.628135+00	2026-05-03 13:16:26.628135+00	\N	e85d209a-b9ad-48b1-872b-99f0bca62010
00000000-0000-0000-0000-000000000000	69	yezqidzgqqlv	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 04:39:13.240204+00	2026-05-03 13:22:17.551464+00	\N	d74905c3-fec3-4820-b20d-e1349512c6ed
00000000-0000-0000-0000-000000000000	94	e5rnyeer2b6k	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 13:22:17.557932+00	2026-05-03 13:22:17.557932+00	yezqidzgqqlv	d74905c3-fec3-4820-b20d-e1349512c6ed
00000000-0000-0000-0000-000000000000	97	wxcmjsblmf4n	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 14:36:10.279861+00	2026-05-03 14:36:10.279861+00	\N	7fa38bed-e54f-4e21-8cce-170b243f8176
00000000-0000-0000-0000-000000000000	98	lwwqmx4cjwfn	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 14:41:01.570218+00	2026-05-03 14:41:01.570218+00	\N	736b82b5-2088-4768-9db5-1d8eda930207
00000000-0000-0000-0000-000000000000	58	7m72vqgrbtge	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-02 12:23:13.641482+00	2026-05-03 15:59:16.400589+00	\N	ddfa30f6-58ea-4e9d-a093-67527e6ff780
00000000-0000-0000-0000-000000000000	99	igldytqaa26a	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 15:59:16.410375+00	2026-05-03 15:59:16.410375+00	7m72vqgrbtge	ddfa30f6-58ea-4e9d-a093-67527e6ff780
00000000-0000-0000-0000-000000000000	101	svfk5c54yevq	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 21:59:26.399859+00	2026-05-03 21:59:26.399859+00	\N	022cd7fd-2ec7-4ac3-a757-19426e25751f
00000000-0000-0000-0000-000000000000	102	pmpsqi5tux5m	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 21:59:26.612338+00	2026-05-03 21:59:26.612338+00	\N	b41fdbac-f7bd-4f02-bdc8-1ed1b3618154
00000000-0000-0000-0000-000000000000	103	t7vjrt7vvbdf	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 21:59:44.619352+00	2026-05-03 21:59:44.619352+00	\N	780646ad-33f4-4a25-a2a9-a031228410b1
00000000-0000-0000-0000-000000000000	104	ctzcnumkmrwj	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:00:19.36879+00	2026-05-03 22:00:19.36879+00	\N	6d3855ed-1ae2-4518-b7ee-094074e817d8
00000000-0000-0000-0000-000000000000	82	ldcjaxom4byd	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 09:10:46.721004+00	2026-05-03 22:00:58.263049+00	\N	6034532e-5aaa-4e9e-aadd-41781795e7f3
00000000-0000-0000-0000-000000000000	105	tldcm65wrdca	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 22:00:58.26433+00	2026-05-03 22:00:58.26433+00	ldcjaxom4byd	6034532e-5aaa-4e9e-aadd-41781795e7f3
00000000-0000-0000-0000-000000000000	93	nrre7t2stbzp	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 13:16:31.509138+00	2026-05-03 23:02:41.003458+00	\N	1f96eb1f-911d-4904-ae06-1fe125ec6767
00000000-0000-0000-0000-000000000000	100	n73ce557kchr	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 15:59:17.309123+00	2026-05-04 00:56:00.800893+00	\N	742aefac-0409-46bd-b62b-86b1c289997e
00000000-0000-0000-0000-000000000000	106	2xqvp5erynrp	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 22:00:58.740409+00	2026-05-04 01:27:18.641946+00	\N	d2f43092-dd37-45cd-8216-e3b3d4c54888
00000000-0000-0000-0000-000000000000	95	6zrgksjakc5q	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 13:22:18.814181+00	2026-05-04 11:36:28.944565+00	\N	537ddd17-cb00-4948-a643-c30f4e51befb
00000000-0000-0000-0000-000000000000	96	lwukwf6zlkgp	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 14:26:26.970221+00	2026-05-04 12:08:39.404198+00	\N	5ce13903-ac1b-47fb-aab1-028b1e8ca7c5
00000000-0000-0000-0000-000000000000	89	4zih2fxbqnni	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 11:56:01.739157+00	2026-05-04 22:59:08.776552+00	\N	ccc9e3bb-b175-465c-97a5-99bd17654f8f
00000000-0000-0000-0000-000000000000	83	4cffr6xwc2az	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 09:59:10.180821+00	2026-05-06 11:54:46.074524+00	\N	36386704-5e12-48a3-b786-724e0cc4af2c
00000000-0000-0000-0000-000000000000	107	dcio634je2z4	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:01:46.294717+00	2026-05-03 22:01:46.294717+00	\N	792ee504-7c04-4eb4-82c7-21b0e9a203fd
00000000-0000-0000-0000-000000000000	108	4rxqlrr2onz6	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:02:23.768389+00	2026-05-03 22:02:23.768389+00	\N	f8286ee6-c5ce-4d82-b3f9-29a0be4001fb
00000000-0000-0000-0000-000000000000	109	gcv7w7b5jsbn	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:02:28.530627+00	2026-05-03 22:02:28.530627+00	\N	b78e2a4c-3b59-4244-94d3-cc3e2b06c5d4
00000000-0000-0000-0000-000000000000	110	dh6asxjkzfci	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:02:33.412795+00	2026-05-03 22:02:33.412795+00	\N	1cd4ba68-d656-43e6-9e30-2239b47592ee
00000000-0000-0000-0000-000000000000	111	k4tic2u36f5h	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:02:49.44205+00	2026-05-03 22:02:49.44205+00	\N	08814b95-d98f-4cf5-9a81-a315ff7e8bd5
00000000-0000-0000-0000-000000000000	112	32mf3vzfz7xu	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:03:26.682224+00	2026-05-03 22:03:26.682224+00	\N	626a55b8-0ca2-4e39-b766-d07386f7b714
00000000-0000-0000-0000-000000000000	113	aarxgqo44cm4	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:03:31.430012+00	2026-05-03 22:03:31.430012+00	\N	9ac05af9-ad69-4376-bb18-dbead4e76184
00000000-0000-0000-0000-000000000000	114	xfz3jx7ff522	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:04:11.863562+00	2026-05-03 22:04:11.863562+00	\N	bb2bf0d4-cc91-4375-b5af-26bcd39c3379
00000000-0000-0000-0000-000000000000	115	bhoezp362vlw	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:07:20.039399+00	2026-05-03 22:07:20.039399+00	\N	923e429d-a30b-4418-87d6-9098640cb4cc
00000000-0000-0000-0000-000000000000	116	gmbzkoi47ago	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:07:37.30645+00	2026-05-03 22:07:37.30645+00	\N	5ead0212-844b-4856-adb6-4cc0958c5ff1
00000000-0000-0000-0000-000000000000	117	p6m4khv6c2xx	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:07:56.054624+00	2026-05-03 22:07:56.054624+00	\N	9b1cb33b-bf9e-4668-9bff-8d67256854d0
00000000-0000-0000-0000-000000000000	118	sp4d3uivtjft	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:08:12.694385+00	2026-05-03 22:08:12.694385+00	\N	1af02e38-a092-4598-94d8-524b3f66d341
00000000-0000-0000-0000-000000000000	119	2ipbty375kjd	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:08:25.399702+00	2026-05-03 22:08:25.399702+00	\N	cb73a2ef-d2c6-48fb-aad5-48b8400fe70e
00000000-0000-0000-0000-000000000000	120	kzqg6sjlpe4r	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:08:34.998794+00	2026-05-03 22:08:34.998794+00	\N	b203a927-4a6a-4278-aaf9-98ab8a5d6a5c
00000000-0000-0000-0000-000000000000	121	ierncwh4butl	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:09:00.463378+00	2026-05-03 22:09:00.463378+00	\N	c2b0cead-50e1-40b2-aeca-b1a29ed75868
00000000-0000-0000-0000-000000000000	122	impymfzridck	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:12:19.070008+00	2026-05-03 22:12:19.070008+00	\N	5b2678ca-9731-4ebc-aadf-45023ecb4158
00000000-0000-0000-0000-000000000000	123	65dirfcypn7t	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:12:40.526204+00	2026-05-03 22:12:40.526204+00	\N	47576508-f0b5-4200-9159-4cb5ca7a2d0e
00000000-0000-0000-0000-000000000000	124	6cxcoee7vqgb	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:13:04.866043+00	2026-05-03 22:13:04.866043+00	\N	4229f572-9f64-4c02-88f0-f44489af96a7
00000000-0000-0000-0000-000000000000	125	u2kvi2a5xgun	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:13:11.95741+00	2026-05-03 22:13:11.95741+00	\N	0fd134a3-c414-4f98-98d4-46bb2f36961c
00000000-0000-0000-0000-000000000000	126	hflcjlohhqrf	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:13:17.16818+00	2026-05-03 22:13:17.16818+00	\N	7df728e3-6131-4355-9671-2393c55818ea
00000000-0000-0000-0000-000000000000	127	lfo2xdrezi6g	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:13:20.287361+00	2026-05-03 22:13:20.287361+00	\N	c13af329-b9a5-469d-b414-e30846f97a76
00000000-0000-0000-0000-000000000000	128	26fd5zig3xyz	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:13:24.097985+00	2026-05-03 22:13:24.097985+00	\N	379fa945-8e84-41fd-9538-e1b44f180a44
00000000-0000-0000-0000-000000000000	129	p5wjct4dwpdm	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:16:01.856514+00	2026-05-03 22:16:01.856514+00	\N	3de0434e-c832-4ecb-b6ff-d61acd0fd8c0
00000000-0000-0000-0000-000000000000	130	mhtgscbw4aq2	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:16:50.848383+00	2026-05-03 22:16:50.848383+00	\N	8f7cef5c-cde4-4648-a32d-acb6abe3df5d
00000000-0000-0000-0000-000000000000	463	536qnxprxnh7	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-14 03:23:51.67001+00	2026-05-14 03:23:51.67001+00	\N	c19eba59-c4b0-4aea-830f-e4f19f8b6b57
00000000-0000-0000-0000-000000000000	132	egjf2wv4lzw6	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 22:55:34.222641+00	2026-05-03 22:55:34.222641+00	\N	fcc8d616-9e96-4cd5-bd27-13e38b0a4022
00000000-0000-0000-0000-000000000000	135	qiqkww3mkp5i	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 23:00:28.822604+00	2026-05-03 23:00:28.822604+00	\N	0cebdc4f-0f13-4a4a-9c63-428e8eec2907
00000000-0000-0000-0000-000000000000	136	nmrdw76okg2p	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 23:01:22.050343+00	2026-05-03 23:01:22.050343+00	\N	bc10560b-e57f-4ac5-a305-c182f7a9a115
00000000-0000-0000-0000-000000000000	137	v6gs7zukbdn3	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 23:01:29.588254+00	2026-05-03 23:01:29.588254+00	\N	e633cdf3-eb03-4599-8582-ab3392b66e94
00000000-0000-0000-0000-000000000000	138	vfoqocufg56q	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-03 23:02:41.006461+00	2026-05-03 23:02:41.006461+00	nrre7t2stbzp	1f96eb1f-911d-4904-ae06-1fe125ec6767
00000000-0000-0000-0000-000000000000	140	x6sgzhu57e77	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-03 23:59:59.637357+00	2026-05-03 23:59:59.637357+00	\N	8d7355e6-a022-4420-8e3e-8eb16655824e
00000000-0000-0000-0000-000000000000	141	crbuh4fke5wk	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 00:00:06.308972+00	2026-05-04 00:00:06.308972+00	\N	831ade6e-9235-4b82-ace7-3131601855e8
00000000-0000-0000-0000-000000000000	139	dkdzvk3c7ac4	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-03 23:02:49.284754+00	2026-05-04 00:05:58.557248+00	\N	b79c7b8e-ebf8-477f-9caf-1270504e7c2a
00000000-0000-0000-0000-000000000000	144	4ujbdek5z5l4	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 00:05:58.563385+00	2026-05-04 00:05:58.563385+00	dkdzvk3c7ac4	b79c7b8e-ebf8-477f-9caf-1270504e7c2a
00000000-0000-0000-0000-000000000000	146	7bxisa6ic5tj	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 00:17:57.264669+00	2026-05-04 00:17:57.264669+00	\N	2fcf52d4-0cb8-47dd-b03b-cb2220f8fb37
00000000-0000-0000-0000-000000000000	131	mtox3t35vvof	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-03 22:23:25.296234+00	2026-05-04 00:52:14.702591+00	\N	41a740ad-869b-41d1-9f3e-357c7b2781cc
00000000-0000-0000-0000-000000000000	147	f6d4piefe7ak	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-04 00:52:14.707592+00	2026-05-04 00:52:14.707592+00	mtox3t35vvof	41a740ad-869b-41d1-9f3e-357c7b2781cc
00000000-0000-0000-0000-000000000000	148	bkvybgk5derg	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 00:56:00.806315+00	2026-05-04 00:56:00.806315+00	n73ce557kchr	742aefac-0409-46bd-b62b-86b1c289997e
00000000-0000-0000-0000-000000000000	149	ywmh2utqzmdd	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 00:56:02.003591+00	2026-05-04 00:56:02.003591+00	\N	23d59a86-9247-4898-8047-3804c31c1e05
00000000-0000-0000-0000-000000000000	153	lbwk5sww74f7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 01:27:18.647797+00	2026-05-04 01:27:18.647797+00	2xqvp5erynrp	d2f43092-dd37-45cd-8216-e3b3d4c54888
00000000-0000-0000-0000-000000000000	155	vdlmidb4uzju	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 02:07:03.785112+00	2026-05-04 02:07:03.785112+00	\N	ab0bb280-ecc9-419f-803b-d805c78081fa
00000000-0000-0000-0000-000000000000	151	lben75e3dax7	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 01:03:46.290589+00	2026-05-04 02:07:19.754715+00	\N	29317481-fe82-4e3c-8ee9-6f715d883ef3
00000000-0000-0000-0000-000000000000	152	q6wn63yxx7ez	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-04 01:20:39.010101+00	2026-05-04 02:22:54.230291+00	\N	5e135e1a-3a5a-4cbe-895a-b1a0eb391547
00000000-0000-0000-0000-000000000000	159	3i32k53i3sje	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 02:32:25.72239+00	2026-05-04 02:32:25.72239+00	\N	cd941f5c-3252-48a7-988a-0a3146fd740b
00000000-0000-0000-0000-000000000000	158	ra2d5olrfi4c	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-04 02:22:54.238474+00	2026-05-04 03:39:45.903549+00	q6wn63yxx7ez	5e135e1a-3a5a-4cbe-895a-b1a0eb391547
00000000-0000-0000-0000-000000000000	156	tmds7zjgfkeo	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 02:07:19.756649+00	2026-05-04 04:59:29.384076+00	lben75e3dax7	29317481-fe82-4e3c-8ee9-6f715d883ef3
00000000-0000-0000-0000-000000000000	154	cok7xl6yw7pn	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 01:27:22.530303+00	2026-05-04 09:42:31.322684+00	\N	c8c88c22-cce2-4579-a097-b2304a209b9e
00000000-0000-0000-0000-000000000000	150	vckopvn5buke	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 01:03:33.085498+00	2026-05-04 17:21:17.999435+00	\N	e852b441-c39d-4f92-b90c-9a8a107022a6
00000000-0000-0000-0000-000000000000	143	uahyp6yzb7h3	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 00:04:32.001814+00	2026-05-04 23:53:26.696777+00	\N	bb66c957-0f8b-4e6c-a415-d2dcc5834d44
00000000-0000-0000-0000-000000000000	145	6kp55i5iivms	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 00:05:59.373535+00	2026-05-05 09:52:05.061+00	\N	10cb3316-ab6d-4fc6-b596-e9613d3a6d46
00000000-0000-0000-0000-000000000000	142	vqffdqch5cpa	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-04 00:00:12.762842+00	2026-05-05 11:16:50.70709+00	\N	c4a790ae-b218-4496-9d77-a507dc6cb04c
00000000-0000-0000-0000-000000000000	157	5wda6xwmn2s5	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 02:08:05.492938+00	2026-05-06 11:04:40.267236+00	\N	b5855e91-6a0b-4ac5-a5f7-2ef3e8c74a68
00000000-0000-0000-0000-000000000000	133	h75nz43nlnvl	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-03 22:59:40.1152+00	2026-05-06 13:53:48.772334+00	\N	e22c7e96-caf6-4617-bad4-d8cd3f0f6afa
00000000-0000-0000-0000-000000000000	134	ohebn2dxf6pl	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-03 23:00:15.851075+00	2026-05-07 04:22:11.540414+00	\N	b01a92b3-3e87-4abf-b47a-33ab1e635878
00000000-0000-0000-0000-000000000000	160	z56b7yedmk5c	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 02:40:01.929166+00	2026-05-04 02:40:01.929166+00	\N	f12cb778-ad5b-4be4-a29e-b85813586f7a
00000000-0000-0000-0000-000000000000	161	iv5ebzqplzjf	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 03:39:05.382158+00	2026-05-04 03:39:05.382158+00	\N	8fef52f0-97ea-46ec-905e-2c973b458cec
00000000-0000-0000-0000-000000000000	162	l3cnhydact2g	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-04 03:39:45.905335+00	2026-05-04 07:02:21.245946+00	ra2d5olrfi4c	5e135e1a-3a5a-4cbe-895a-b1a0eb391547
00000000-0000-0000-0000-000000000000	164	tvkrqa3jk647	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-04 07:02:21.259755+00	2026-05-04 07:02:21.259755+00	l3cnhydact2g	5e135e1a-3a5a-4cbe-895a-b1a0eb391547
00000000-0000-0000-0000-000000000000	165	5hxdaj64xotx	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-04 07:31:44.439578+00	2026-05-04 08:36:26.230073+00	\N	c42ba9ff-32f4-4266-bc13-fa88c4c0615b
00000000-0000-0000-0000-000000000000	167	6xdxgdg4pkbd	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 07:52:28.213+00	2026-05-04 08:50:51.346302+00	\N	6eebc915-64ad-4ae5-846c-16c522ca6700
00000000-0000-0000-0000-000000000000	171	t4qemvcqv2zh	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 09:37:40.744985+00	2026-05-04 09:37:40.744985+00	osuerpvlezug	1c8aaf7a-e986-442a-a4f1-cd23f00965e7
00000000-0000-0000-0000-000000000000	172	boxcrkyemdax	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 09:37:41.721616+00	2026-05-04 09:37:41.721616+00	\N	84cf9fcb-bd20-460e-bbb7-3d892d0c3a1c
00000000-0000-0000-0000-000000000000	173	mbq2dodfowva	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 09:42:31.327716+00	2026-05-04 09:42:31.327716+00	cok7xl6yw7pn	c8c88c22-cce2-4579-a097-b2304a209b9e
00000000-0000-0000-0000-000000000000	168	u3a2jnequieb	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-04 08:36:26.240432+00	2026-05-04 09:42:33.070097+00	5hxdaj64xotx	c42ba9ff-32f4-4266-bc13-fa88c4c0615b
00000000-0000-0000-0000-000000000000	175	kkosmxy64ivv	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-04 09:42:33.070516+00	2026-05-04 09:42:33.070516+00	u3a2jnequieb	c42ba9ff-32f4-4266-bc13-fa88c4c0615b
00000000-0000-0000-0000-000000000000	176	hvu7uatbhqh5	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 11:36:28.959315+00	2026-05-04 11:36:28.959315+00	6zrgksjakc5q	537ddd17-cb00-4948-a643-c30f4e51befb
00000000-0000-0000-0000-000000000000	177	t3tlrgyafivk	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 12:08:39.410523+00	2026-05-04 12:08:39.410523+00	lwukwf6zlkgp	5ce13903-ac1b-47fb-aab1-028b1e8ca7c5
00000000-0000-0000-0000-000000000000	179	h7ssuszvzmqi	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 14:16:09.67513+00	2026-05-04 14:16:09.67513+00	\N	b10743eb-1bbd-4db7-9987-582a0a1ffa6d
00000000-0000-0000-0000-000000000000	180	xi5fwhy3xqg7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 14:18:03.996068+00	2026-05-04 14:18:03.996068+00	\N	36c71719-a2bb-4990-98a6-16242d2c5d7c
00000000-0000-0000-0000-000000000000	181	bam2b3gldxdr	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 15:23:17.102956+00	2026-05-04 15:23:17.102956+00	\N	dc2f16f9-42d7-4dfb-9ea2-1357b661d5f2
00000000-0000-0000-0000-000000000000	182	ovb6bzakljr2	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 16:10:21.370328+00	2026-05-04 16:10:21.370328+00	\N	d9aafebd-ec9a-4ad9-9a8d-5a953fe27aed
00000000-0000-0000-0000-000000000000	170	rse3ttfrg2sn	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 09:21:46.197297+00	2026-05-04 16:44:48.547518+00	\N	3e3cf196-c0b0-4aa0-92d6-005722817aa4
00000000-0000-0000-0000-000000000000	183	qoa2xcuybec4	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 16:44:48.56209+00	2026-05-04 16:44:48.56209+00	rse3ttfrg2sn	3e3cf196-c0b0-4aa0-92d6-005722817aa4
00000000-0000-0000-0000-000000000000	185	5747m5yoyzri	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 17:21:18.006478+00	2026-05-04 17:21:18.006478+00	vckopvn5buke	e852b441-c39d-4f92-b90c-9a8a107022a6
00000000-0000-0000-0000-000000000000	186	zwwd3wwbw57l	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 17:21:18.911461+00	2026-05-04 17:21:18.911461+00	\N	83afb629-f15b-4b1b-b504-61faa740f181
00000000-0000-0000-0000-000000000000	163	jg7ekphfvavz	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 04:59:29.398638+00	2026-05-04 17:21:27.305612+00	tmds7zjgfkeo	29317481-fe82-4e3c-8ee9-6f715d883ef3
00000000-0000-0000-0000-000000000000	187	7rrnpopxzkqk	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 17:21:27.305977+00	2026-05-04 17:21:27.305977+00	jg7ekphfvavz	29317481-fe82-4e3c-8ee9-6f715d883ef3
00000000-0000-0000-0000-000000000000	189	kexju4g2c4wf	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 17:36:45.98258+00	2026-05-04 17:36:45.98258+00	\N	32b21aee-7494-4636-99ab-3ba93cf6d61a
00000000-0000-0000-0000-000000000000	190	zopgm34eemrs	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 17:37:24.079117+00	2026-05-04 17:37:24.079117+00	\N	f2c660b3-218f-4580-b4cc-ab3f3575bfba
00000000-0000-0000-0000-000000000000	191	scutdyvyg44a	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 17:38:23.54051+00	2026-05-04 17:38:23.54051+00	\N	60e843bf-f5e1-440d-aca1-f57505a5ca87
00000000-0000-0000-0000-000000000000	192	oqcz3knblejq	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 17:38:31.124445+00	2026-05-04 17:38:31.124445+00	\N	56f174b4-b753-4e53-aa4b-dc66466ecd85
00000000-0000-0000-0000-000000000000	193	dtv4zf2svce3	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 17:38:56.002674+00	2026-05-04 17:38:56.002674+00	\N	702ee476-a304-466a-b2d4-167e25ca8e1f
00000000-0000-0000-0000-000000000000	194	tcsgcjoagrbb	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 17:39:16.527235+00	2026-05-04 17:39:16.527235+00	\N	db460c34-8d43-4b40-b7e3-c1fa1155843b
00000000-0000-0000-0000-000000000000	195	5xho566q6yr7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 17:40:04.26163+00	2026-05-04 17:40:04.26163+00	\N	2fd61c0c-8b07-4014-820d-d7461997775c
00000000-0000-0000-0000-000000000000	196	5qr6y65vnf7y	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 17:40:58.726985+00	2026-05-04 17:40:58.726985+00	\N	b829fbc2-ac7f-4400-b2e0-7fafa8d8a23a
00000000-0000-0000-0000-000000000000	197	dms2ffhvim6i	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 18:22:16.250362+00	2026-05-04 18:22:16.250362+00	\N	0b624b14-677c-4b59-af68-9ae7eacab824
00000000-0000-0000-0000-000000000000	198	m2lb6ihtu37u	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 22:59:08.798379+00	2026-05-04 22:59:08.798379+00	4zih2fxbqnni	ccc9e3bb-b175-465c-97a5-99bd17654f8f
00000000-0000-0000-0000-000000000000	199	mveqa7xz7hne	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 22:59:10.012564+00	2026-05-04 22:59:10.012564+00	\N	9ab5e877-1c1f-45e9-95bc-299c35df278e
00000000-0000-0000-0000-000000000000	200	b7ipvq673jkg	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 23:53:26.715307+00	2026-05-04 23:53:26.715307+00	uahyp6yzb7h3	bb66c957-0f8b-4e6c-a415-d2dcc5834d44
00000000-0000-0000-0000-000000000000	201	5oz2ewukjkur	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 23:53:27.471966+00	2026-05-04 23:53:27.471966+00	\N	1d883c9e-7522-4fef-962d-14d2b6ba2c06
00000000-0000-0000-0000-000000000000	202	4pfaece53pu5	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 23:53:57.499452+00	2026-05-04 23:53:57.499452+00	\N	f0b124f4-0361-46da-9f5f-aeb9ae5c0485
00000000-0000-0000-0000-000000000000	203	s3bdxljckgjf	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 23:54:45.407754+00	2026-05-04 23:54:45.407754+00	\N	7d2e53f6-aa50-4511-b01b-1cee76b254f5
00000000-0000-0000-0000-000000000000	204	ydw2mk2idybk	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-04 23:57:35.641014+00	2026-05-04 23:57:35.641014+00	\N	90b90c10-6111-42ec-9389-9b40a939a336
00000000-0000-0000-0000-000000000000	188	xgckbftb2f46	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 17:21:27.782589+00	2026-05-05 00:09:19.147266+00	\N	cfb77a1f-d3f3-4097-8d6d-bf41d217d032
00000000-0000-0000-0000-000000000000	205	gojyu6kmmu2e	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 00:09:19.152045+00	2026-05-05 00:09:19.152045+00	xgckbftb2f46	cfb77a1f-d3f3-4097-8d6d-bf41d217d032
00000000-0000-0000-0000-000000000000	206	5sanifk6qxzw	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 00:09:20.196345+00	2026-05-05 00:09:20.196345+00	\N	4328172b-7786-419d-af8a-594897d67a2b
00000000-0000-0000-0000-000000000000	178	c56uynsl5qgj	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 12:08:40.362849+00	2026-05-05 00:13:37.925782+00	\N	809f7948-cf83-433e-9729-73562edcfd7d
00000000-0000-0000-0000-000000000000	207	uiol26nuadi4	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 00:13:37.933109+00	2026-05-05 00:13:37.933109+00	c56uynsl5qgj	809f7948-cf83-433e-9729-73562edcfd7d
00000000-0000-0000-0000-000000000000	210	pzztzt7yx7lr	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-05 00:44:25.239888+00	2026-05-05 00:44:25.239888+00	\N	4f222a82-6691-45a2-8183-1b5b10c08068
00000000-0000-0000-0000-000000000000	169	4ju77pktqasn	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 08:50:51.354479+00	2026-05-05 01:12:28.28295+00	6xdxgdg4pkbd	6eebc915-64ad-4ae5-846c-16c522ca6700
00000000-0000-0000-0000-000000000000	211	xvtavvebgalv	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 01:12:28.2875+00	2026-05-05 01:12:28.2875+00	4ju77pktqasn	6eebc915-64ad-4ae5-846c-16c522ca6700
00000000-0000-0000-0000-000000000000	208	xlxgo7b72lyb	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 00:13:39.172118+00	2026-05-05 05:07:57.982447+00	\N	e8b716fd-1ada-449c-ab5f-63881e9b5da8
00000000-0000-0000-0000-000000000000	166	6x6o4r7255jo	f38b5572-029f-4d74-ac31-3d5e278df151	t	2026-05-04 07:32:54.828069+00	2026-05-05 05:29:51.166387+00	\N	18c7adf2-4889-44d9-a8ac-78ac6e4b2814
00000000-0000-0000-0000-000000000000	174	kifplyiqcofy	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 09:42:32.103845+00	2026-05-05 05:30:13.767883+00	\N	d5b5d670-e6bc-4109-b80d-5ab30aa44c62
00000000-0000-0000-0000-000000000000	184	kdg5djjebhps	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-04 16:44:49.964709+00	2026-05-05 10:03:59.194752+00	\N	437a42a6-bbfb-4520-ba9b-a3144a745219
00000000-0000-0000-0000-000000000000	209	35chubgbthbx	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 00:18:48.765115+00	2026-05-05 14:03:19.650497+00	\N	b0d4b141-d279-4131-8612-399170fb322c
00000000-0000-0000-0000-000000000000	212	cxovquamnadm	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 01:12:29.019455+00	2026-05-05 01:12:29.019455+00	\N	96062ea5-a33c-4f49-9d84-a49de190e469
00000000-0000-0000-0000-000000000000	213	nlcqmejrj3yy	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-05 01:13:28.266905+00	2026-05-05 01:13:28.266905+00	\N	f9134f67-ae73-4392-918c-ab90ead4c86c
00000000-0000-0000-0000-000000000000	214	vlapuzw2cmk2	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 01:14:41.00499+00	2026-05-05 01:14:41.00499+00	\N	97d7fa3a-1847-4e68-8e17-b84597eda1fc
00000000-0000-0000-0000-000000000000	215	rgjutszox635	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 01:14:44.821376+00	2026-05-05 01:14:44.821376+00	\N	714a10fb-95bf-4df0-9823-b91bf611988d
00000000-0000-0000-0000-000000000000	216	ugvmmhztzqc4	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 01:15:07.156276+00	2026-05-05 01:15:07.156276+00	\N	bc1d548e-88d2-41cb-8b94-7a4ee7a2f968
00000000-0000-0000-0000-000000000000	217	koevwuddz7fq	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 01:15:32.548776+00	2026-05-05 01:15:32.548776+00	\N	bb92ab88-d663-4927-8185-f9832e5f4ff0
00000000-0000-0000-0000-000000000000	218	c5tsggw2c6ig	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 01:20:04.816853+00	2026-05-05 01:20:04.816853+00	\N	4e01c41a-75a9-4761-acb4-d7f0b502b177
00000000-0000-0000-0000-000000000000	465	y47uijpbzbie	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-15 08:03:27.111376+00	2026-05-15 08:03:27.111376+00	\N	2c0ce936-6eed-428e-82b8-3ac1f2b20896
00000000-0000-0000-0000-000000000000	219	77gqjec3cqrl	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 01:38:58.93794+00	2026-05-05 03:00:58.810843+00	\N	c4629844-c5b0-4f4a-b675-9e79aa8079fc
00000000-0000-0000-0000-000000000000	221	jalijydvnrcw	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 04:14:37.635652+00	2026-05-05 04:14:37.635652+00	\N	451979bd-fcab-4e8e-9cec-dc5fafa65aa0
00000000-0000-0000-0000-000000000000	223	lrwqabilezg7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 05:07:57.990847+00	2026-05-05 05:07:57.990847+00	xlxgo7b72lyb	e8b716fd-1ada-449c-ab5f-63881e9b5da8
00000000-0000-0000-0000-000000000000	471	v6ylodfokg6n	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-18 06:12:26.438656+00	2026-05-18 08:09:24.057018+00	\N	2267c369-25de-4d41-ac5e-a2a6c1db726d
00000000-0000-0000-0000-000000000000	225	vbmgg7omrtpe	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 05:29:51.171254+00	2026-05-05 05:29:51.171254+00	6x6o4r7255jo	18c7adf2-4889-44d9-a8ac-78ac6e4b2814
00000000-0000-0000-0000-000000000000	474	f7aouu62yjzx	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	f	2026-05-18 08:14:28.446864+00	2026-05-18 08:14:28.446864+00	\N	3d9d94be-a801-4d2c-8d9d-ac009eed2490
00000000-0000-0000-0000-000000000000	227	prsl7zg2yhhq	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 05:30:13.768269+00	2026-05-05 05:30:13.768269+00	kifplyiqcofy	d5b5d670-e6bc-4109-b80d-5ab30aa44c62
00000000-0000-0000-0000-000000000000	468	zqjbjnhx4kiz	46283390-81d3-4324-9d77-9cfd33c224bc	t	2026-05-15 10:23:21.377696+00	2026-05-18 11:04:50.214959+00	\N	8b41447d-9c32-4326-88e3-110c74428913
00000000-0000-0000-0000-000000000000	228	frzw2b7lgsom	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 05:30:14.427017+00	2026-05-05 06:43:19.163502+00	\N	17eebc96-a8e4-40b8-a4f4-8cf185e8d585
00000000-0000-0000-0000-000000000000	229	2ziphnk6fzlm	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 06:43:19.172642+00	2026-05-05 06:43:19.172642+00	frzw2b7lgsom	17eebc96-a8e4-40b8-a4f4-8cf185e8d585
00000000-0000-0000-0000-000000000000	220	ruzo4emwj53u	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 03:00:58.82479+00	2026-05-05 06:58:02.189292+00	77gqjec3cqrl	c4629844-c5b0-4f4a-b675-9e79aa8079fc
00000000-0000-0000-0000-000000000000	231	h7yo2leszbat	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 06:58:02.203001+00	2026-05-05 06:58:02.203001+00	ruzo4emwj53u	c4629844-c5b0-4f4a-b675-9e79aa8079fc
00000000-0000-0000-0000-000000000000	226	vfll25xmlhf5	f38b5572-029f-4d74-ac31-3d5e278df151	t	2026-05-05 05:29:52.067156+00	2026-05-05 07:31:05.133069+00	\N	0252ff6a-4f5d-419e-bada-5db881b3f557
00000000-0000-0000-0000-000000000000	232	ae2rvtbhkmeh	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 07:31:05.143252+00	2026-05-05 07:31:05.143252+00	vfll25xmlhf5	0252ff6a-4f5d-419e-bada-5db881b3f557
00000000-0000-0000-0000-000000000000	233	oerqumubrfw2	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 07:31:06.064865+00	2026-05-05 07:31:06.064865+00	\N	746ac5b7-ba5d-4437-99a1-1b7b2b98af3c
00000000-0000-0000-0000-000000000000	234	lch2mtehsqvg	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 07:48:22.031442+00	2026-05-05 07:48:22.031442+00	\N	bdc600f7-ab51-420b-bd57-886abc293f1c
00000000-0000-0000-0000-000000000000	235	mwh5e5hlpm6x	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 07:48:26.33181+00	2026-05-05 07:48:26.33181+00	\N	ddfb7882-9b63-4979-aa59-280bcbd46f83
00000000-0000-0000-0000-000000000000	236	7a5ds4tlr2th	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 07:48:32.390428+00	2026-05-05 07:48:32.390428+00	\N	76ef158e-2723-424e-88a7-e33cee110365
00000000-0000-0000-0000-000000000000	237	6st3lln5d2fm	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 07:49:04.976023+00	2026-05-05 07:49:04.976023+00	\N	66c61761-aad9-4b27-99e0-2b1a3aedeea1
00000000-0000-0000-0000-000000000000	238	ecithmijygyp	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 07:49:09.26679+00	2026-05-05 07:49:09.26679+00	\N	7226c412-1d6a-4b0a-8e7a-91509f076113
00000000-0000-0000-0000-000000000000	239	ajxz3wrlfppf	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 08:45:35.933964+00	2026-05-05 08:45:35.933964+00	\N	a4898a5c-7896-4a83-9e90-e9f68f802f27
00000000-0000-0000-0000-000000000000	240	se27rihu3thf	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 08:45:59.408449+00	2026-05-05 08:45:59.408449+00	\N	55ba7369-bbaf-49f5-8f5e-eee95ba064d4
00000000-0000-0000-0000-000000000000	230	uwjewsx55hey	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 06:43:20.149826+00	2026-05-05 08:47:10.806644+00	\N	e3768ef2-e43a-4d91-9192-0635f30bba15
00000000-0000-0000-0000-000000000000	241	zmlflh7tzn2d	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:47:10.81171+00	2026-05-05 08:47:10.81171+00	uwjewsx55hey	e3768ef2-e43a-4d91-9192-0635f30bba15
00000000-0000-0000-0000-000000000000	242	wh3h5an2stwq	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:47:11.776351+00	2026-05-05 08:47:11.776351+00	\N	f9d66a5c-41d0-44b0-837f-216b42c285f5
00000000-0000-0000-0000-000000000000	243	5pov6lhd2c6t	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:48:25.152271+00	2026-05-05 08:48:25.152271+00	\N	23d9aa11-b4fd-4b88-a669-115f51f985db
00000000-0000-0000-0000-000000000000	244	7x2iakxoc34s	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:48:30.908684+00	2026-05-05 08:48:30.908684+00	\N	0b5f07f0-84b0-4989-b852-a4a2b3c30d4e
00000000-0000-0000-0000-000000000000	245	czk55p2vu3g7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:49:01.519554+00	2026-05-05 08:49:01.519554+00	\N	35a91ad8-6b74-4eff-b707-d1afc380544b
00000000-0000-0000-0000-000000000000	246	g6oxsjlrlnkt	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:51:18.401005+00	2026-05-05 08:51:18.401005+00	\N	9b5bc7a9-258f-442d-ae44-48e725494b93
00000000-0000-0000-0000-000000000000	247	54teut44risk	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:51:25.522984+00	2026-05-05 08:51:25.522984+00	\N	565d57e9-fa45-4c55-b129-fa5bb637ecc7
00000000-0000-0000-0000-000000000000	248	szig7acrodrj	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:51:33.086642+00	2026-05-05 08:51:33.086642+00	\N	cf928da7-81eb-4794-b216-c72f55f4a71e
00000000-0000-0000-0000-000000000000	249	bf7fniekijzy	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:52:17.364046+00	2026-05-05 08:52:17.364046+00	\N	3e54b0ef-5541-4cd6-9512-b209c912c316
00000000-0000-0000-0000-000000000000	250	ifvvz3iewzlr	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:52:22.370125+00	2026-05-05 08:52:22.370125+00	\N	bbbe0ad9-7faf-46df-bee3-932207d777c0
00000000-0000-0000-0000-000000000000	251	4ynzsdgi2etz	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:52:30.480712+00	2026-05-05 08:52:30.480712+00	\N	ed9c373b-f361-4d5c-92b6-e33984a3a641
00000000-0000-0000-0000-000000000000	252	2wyojizp2and	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:52:35.347318+00	2026-05-05 08:52:35.347318+00	\N	d4b17260-a81f-4b65-b30b-ac1f0999dbcc
00000000-0000-0000-0000-000000000000	253	6uih4flldkhc	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:52:50.626127+00	2026-05-05 08:52:50.626127+00	\N	287b93fc-d59f-4367-8299-7f5f0b7b3614
00000000-0000-0000-0000-000000000000	254	724bjvpoursm	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:52:55.679655+00	2026-05-05 08:52:55.679655+00	\N	52409d80-f00d-4a3b-9058-7c6c9e0f1f22
00000000-0000-0000-0000-000000000000	255	e3txdgtqypzd	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 08:53:16.410475+00	2026-05-05 08:53:16.410475+00	\N	ce95d173-00c9-4acd-a35d-5f3e7715b72c
00000000-0000-0000-0000-000000000000	256	cqlg43bpvr2r	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-05 08:56:05.826196+00	2026-05-05 08:56:05.826196+00	\N	177749b0-dfdb-4a9c-9af1-a7c841ae36ab
00000000-0000-0000-0000-000000000000	257	ufnv5brqjd3a	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-05 08:56:42.180254+00	2026-05-05 08:56:42.180254+00	\N	ae763eb9-2669-4978-80a0-d0d6986f2644
00000000-0000-0000-0000-000000000000	258	jfmda3wx27wv	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:04:51.169403+00	2026-05-05 09:04:51.169403+00	\N	81d36529-2bb9-40f8-ba59-8664a2b95ba8
00000000-0000-0000-0000-000000000000	259	6w7uilr5jv74	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:05:00.161874+00	2026-05-05 09:05:00.161874+00	\N	36c21b72-c61d-4396-a6ae-33fdc6229e5f
00000000-0000-0000-0000-000000000000	260	dx4olcpdzv7f	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:05:04.316228+00	2026-05-05 09:05:04.316228+00	\N	65377ec6-9c52-4c5c-9004-2480cc30ef2d
00000000-0000-0000-0000-000000000000	224	kosoxr6vcuam	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 05:07:58.936371+00	2026-05-05 11:20:48.105648+00	\N	e9edff2f-72e3-4119-8742-d18f83784b8e
00000000-0000-0000-0000-000000000000	222	3xlg4lohxw7k	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 04:14:59.520594+00	2026-05-05 13:18:43.214123+00	\N	19fa2897-d1e9-4457-aa6b-634c3358732c
00000000-0000-0000-0000-000000000000	261	c3ukxj7sjrqn	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:05:06.402549+00	2026-05-05 09:05:06.402549+00	\N	b595635b-14cc-49aa-8083-a6101cc26f30
00000000-0000-0000-0000-000000000000	262	wt6vblhnsnon	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:05:07.66923+00	2026-05-05 09:05:07.66923+00	\N	8c44043c-b0e9-43cb-a6a3-15800a3b3dc7
00000000-0000-0000-0000-000000000000	263	7l3n4pcdirn7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:05:10.256572+00	2026-05-05 09:05:10.256572+00	\N	ef39d3aa-435e-4897-9f6e-dd3d3502525b
00000000-0000-0000-0000-000000000000	264	5m5w3cckjl76	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:05:13.14131+00	2026-05-05 09:05:13.14131+00	\N	8977b9fc-f710-4aad-9a7e-a75d814e3af2
00000000-0000-0000-0000-000000000000	265	ie6bngs2ezo7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:05:16.128494+00	2026-05-05 09:05:16.128494+00	\N	b3cb45ed-5a14-4f7c-a5c4-248b9a629f5a
00000000-0000-0000-0000-000000000000	266	4lzt7bbkanpv	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:05:19.324495+00	2026-05-05 09:05:19.324495+00	\N	46d0eeab-9af3-4b0c-9087-f94bb88b00f3
00000000-0000-0000-0000-000000000000	267	p2scwnd5y77e	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:05:31.451022+00	2026-05-05 09:05:31.451022+00	\N	e001f007-5fa5-4dea-8be0-f4fc21e1c910
00000000-0000-0000-0000-000000000000	268	leyoehv4p6mb	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:05:37.733812+00	2026-05-05 09:05:37.733812+00	\N	00e11523-c130-4426-9cc2-3b3e25e2df5b
00000000-0000-0000-0000-000000000000	269	e5xzsje7rffw	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:06:05.618473+00	2026-05-05 09:06:05.618473+00	\N	4683efc8-ceab-4973-845c-958e1c86b6a1
00000000-0000-0000-0000-000000000000	270	exncscf7ewxx	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:06:43.114993+00	2026-05-05 09:06:43.114993+00	\N	2c037710-a3bc-4d20-8c2c-1a82e824d15c
00000000-0000-0000-0000-000000000000	271	sh6di56bdozh	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:10:41.034386+00	2026-05-05 09:10:41.034386+00	\N	46ca7411-881f-41d6-8c7b-e9c47735c1c0
00000000-0000-0000-0000-000000000000	272	g5ek23n3pt7c	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:11:35.742227+00	2026-05-05 09:11:35.742227+00	\N	b4a45a6f-f318-4044-a329-1bb5a47b4e77
00000000-0000-0000-0000-000000000000	273	wlpn6qdkqhxb	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:11:39.599755+00	2026-05-05 09:11:39.599755+00	\N	ff560c57-9b1a-486b-9827-c9f1fa6a654d
00000000-0000-0000-0000-000000000000	274	7xqbyk3yoapm	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:11:44.2228+00	2026-05-05 09:11:44.2228+00	\N	b80661e0-77c3-41b0-80c0-543588924842
00000000-0000-0000-0000-000000000000	275	4poifhbjlwvv	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:11:52.906655+00	2026-05-05 09:11:52.906655+00	\N	4e118ef6-0f15-41f2-8a65-8ec1c8efeb91
00000000-0000-0000-0000-000000000000	276	2mn5qor7h4es	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:11:58.731198+00	2026-05-05 09:11:58.731198+00	\N	0b729218-9ab7-48c8-b1d9-f0b394264d21
00000000-0000-0000-0000-000000000000	277	543ydyq52nk5	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:19:49.554294+00	2026-05-05 09:19:49.554294+00	\N	fb0964c0-18e1-4f09-b14f-ca6e79636db6
00000000-0000-0000-0000-000000000000	278	oamurd5estyp	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:19:53.724698+00	2026-05-05 09:19:53.724698+00	\N	3edd612f-ebe1-4e68-ad26-ee80767bf38c
00000000-0000-0000-0000-000000000000	279	6hy5nuy4hdud	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:19:57.487458+00	2026-05-05 09:19:57.487458+00	\N	69dc4520-f8ca-4afc-9dca-31ab6e2f89ea
00000000-0000-0000-0000-000000000000	280	3tjtep6sckkh	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:20:00.429575+00	2026-05-05 09:20:00.429575+00	\N	287b9f54-27ef-442f-bfff-69f8809e55c2
00000000-0000-0000-0000-000000000000	281	pujizzescuek	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:20:07.948297+00	2026-05-05 09:20:07.948297+00	\N	cff2cf55-bbb3-421a-8a2d-c483a48677b4
00000000-0000-0000-0000-000000000000	282	2sw62uq225um	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:20:10.57803+00	2026-05-05 09:20:10.57803+00	\N	198a0c13-e000-4910-93a9-1f047793fa96
00000000-0000-0000-0000-000000000000	283	ws5uvsoqmevu	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:20:13.240802+00	2026-05-05 09:20:13.240802+00	\N	f425b5a9-6712-4bec-894b-0684b4920443
00000000-0000-0000-0000-000000000000	284	474ryi2znkw4	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:20:37.400797+00	2026-05-05 09:20:37.400797+00	\N	7146453c-0da3-4d01-8fe3-597aba3e7f76
00000000-0000-0000-0000-000000000000	285	72n6egfaatzk	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:20:43.026017+00	2026-05-05 09:20:43.026017+00	\N	5794d0fb-3de4-4a21-ad88-30608322e40d
00000000-0000-0000-0000-000000000000	286	u2qggz7huksk	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:20:46.171612+00	2026-05-05 09:20:46.171612+00	\N	56ba64c8-0127-42fe-8c08-22d48bf593c0
00000000-0000-0000-0000-000000000000	287	wzd4xwe5mbxv	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:20:48.917097+00	2026-05-05 09:20:48.917097+00	\N	9e79887b-ebb7-41a3-b557-f086a8bbe84e
00000000-0000-0000-0000-000000000000	288	uajfebsi6gan	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:20:51.681187+00	2026-05-05 09:20:51.681187+00	\N	2904744f-6e4b-42eb-b5f7-2cb01aba1201
00000000-0000-0000-0000-000000000000	289	cc2xh7fnhqvk	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 09:36:00.274474+00	2026-05-05 09:36:00.274474+00	\N	d8530133-e9f3-403f-9671-9f97a29031fc
00000000-0000-0000-0000-000000000000	290	hwpy44lyjws5	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 09:36:35.01325+00	2026-05-05 09:36:35.01325+00	\N	dec25eb0-01a7-4a53-9713-f05ec9688102
00000000-0000-0000-0000-000000000000	291	zhfhonkraxjp	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:39:01.73615+00	2026-05-05 09:39:01.73615+00	\N	065a6a8a-307c-4549-ab89-f7b2d3fa6071
00000000-0000-0000-0000-000000000000	292	do3r43rfbtq7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:39:05.590097+00	2026-05-05 09:39:05.590097+00	\N	266ab7ad-fee4-4060-b714-0df6ae56f7ef
00000000-0000-0000-0000-000000000000	293	yi6236wpey2f	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:39:10.520833+00	2026-05-05 09:39:10.520833+00	\N	f66a48a1-8e28-4f9b-9060-24e981e39b13
00000000-0000-0000-0000-000000000000	294	cmgl25gohiyy	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:39:22.299883+00	2026-05-05 09:39:22.299883+00	\N	6f5185ee-9a32-495e-acd8-a237e0906983
00000000-0000-0000-0000-000000000000	296	vwjqzzo6qybu	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 09:39:52.70866+00	2026-05-05 09:39:52.70866+00	vz2yoy65jd7m	28a05a6c-f93c-4ae7-a2fe-515a017b22b2
00000000-0000-0000-0000-000000000000	297	3mak3msr7bff	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 09:39:53.291743+00	2026-05-05 09:39:53.291743+00	\N	66d1ad24-ea77-448c-ba47-b9253b785162
00000000-0000-0000-0000-000000000000	298	itjjhjehq4kk	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 09:40:04.114309+00	2026-05-05 09:40:04.114309+00	\N	b2fd433f-56d3-42f3-83e7-5f310c97989b
00000000-0000-0000-0000-000000000000	299	7aminatskkuj	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-05 09:40:07.736761+00	2026-05-05 09:40:07.736761+00	\N	170e25f2-52c2-4794-98ba-1607557e84e3
00000000-0000-0000-0000-000000000000	300	u6pmmqpjxu6j	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:40:45.294116+00	2026-05-05 09:40:45.294116+00	\N	5bb6dec3-adb6-4c26-bbd0-732eebcc49cd
00000000-0000-0000-0000-000000000000	302	cfi5zmudiesf	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:52:05.067856+00	2026-05-05 09:52:05.067856+00	6kp55i5iivms	10cb3316-ab6d-4fc6-b596-e9613d3a6d46
00000000-0000-0000-0000-000000000000	303	gaardk73kh4h	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:52:06.169066+00	2026-05-05 09:52:06.169066+00	\N	416aa2ba-63fa-4b96-aacb-fc0886a05708
00000000-0000-0000-0000-000000000000	304	l6j75le3odxs	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:52:45.69074+00	2026-05-05 09:52:45.69074+00	\N	c57cfdf1-6c5b-434f-8c6d-973a38aedb0a
00000000-0000-0000-0000-000000000000	305	6ilqhb4jku5r	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:52:51.086083+00	2026-05-05 09:52:51.086083+00	\N	2bb14976-f280-4aa1-979c-c185709ef86e
00000000-0000-0000-0000-000000000000	306	u2jlc3doa627	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:52:54.08118+00	2026-05-05 09:52:54.08118+00	\N	9676c8c5-b532-41d3-869b-3940abe754e9
00000000-0000-0000-0000-000000000000	307	sud275otfmmg	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:52:57.714938+00	2026-05-05 09:52:57.714938+00	\N	9cc2c579-cbb7-4420-9edd-6459c8824156
00000000-0000-0000-0000-000000000000	308	3x2dbmzvnd2b	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:53:00.971665+00	2026-05-05 09:53:00.971665+00	\N	c72404dc-1467-4c5d-a894-ae5b39e36053
00000000-0000-0000-0000-000000000000	309	qhufg44muz52	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:53:03.965129+00	2026-05-05 09:53:03.965129+00	\N	b7b68fe3-ca3a-4cd2-a60f-75772440c0d9
00000000-0000-0000-0000-000000000000	310	iwftnecszesc	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:53:13.573841+00	2026-05-05 09:53:13.573841+00	\N	37620b72-37c5-4ae6-9372-cc9b5914e607
00000000-0000-0000-0000-000000000000	311	nvkayv6bbxsd	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 09:53:52.293072+00	2026-05-05 09:53:52.293072+00	\N	fa708d2b-9f81-4ad4-bd43-479b2f2af26f
00000000-0000-0000-0000-000000000000	312	ozrdtv6ij25f	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 10:01:37.931824+00	2026-05-05 10:01:37.931824+00	\N	75028800-d27a-4e77-877e-028fa64bca10
00000000-0000-0000-0000-000000000000	313	q7xpfzbiekrl	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 10:01:48.633731+00	2026-05-05 10:01:48.633731+00	\N	5603fb42-13c5-4cb2-912a-003124de62e4
00000000-0000-0000-0000-000000000000	314	ch4xlyadffhz	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 10:02:12.445754+00	2026-05-05 10:02:12.445754+00	\N	783ccce5-9ec5-43f9-a305-06e7f4b2c23c
00000000-0000-0000-0000-000000000000	315	aghfe2fmpooz	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 10:02:19.676028+00	2026-05-05 10:02:19.676028+00	\N	031c3e37-a433-403f-838e-08c403e13ee8
00000000-0000-0000-0000-000000000000	295	5ujv6mxupnl7	f38b5572-029f-4d74-ac31-3d5e278df151	t	2026-05-05 09:39:36.408641+00	2026-05-06 09:34:22.631485+00	\N	ee259390-b741-418f-a143-07dadf976d40
00000000-0000-0000-0000-000000000000	316	bie7mqfzbljm	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 10:03:59.200672+00	2026-05-05 10:03:59.200672+00	kdg5djjebhps	437a42a6-bbfb-4520-ba9b-a3144a745219
00000000-0000-0000-0000-000000000000	464	jtyr4gchqtnt	46283390-81d3-4324-9d77-9cfd33c224bc	t	2026-05-15 08:02:54.626493+00	2026-05-15 09:22:34.555196+00	\N	56a07ac3-04d7-4170-a60c-677df48ce0c2
00000000-0000-0000-0000-000000000000	319	uzq6qsvil2w6	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 10:14:01.929859+00	2026-05-05 10:14:01.929859+00	\N	532a2e5e-b419-4c51-95ee-3d31ae7bc179
00000000-0000-0000-0000-000000000000	320	q6ilwe5ostz6	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 10:14:14.38094+00	2026-05-05 10:14:14.38094+00	\N	a9d35b7d-c90a-4e56-8d70-28ece2cdd63e
00000000-0000-0000-0000-000000000000	321	2chwg66hj3eh	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 10:23:59.6236+00	2026-05-05 10:23:59.6236+00	\N	188540b9-3fc4-410a-ba05-91e0d39416bf
00000000-0000-0000-0000-000000000000	322	lw67szw5oqhl	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 10:29:47.674594+00	2026-05-05 10:29:47.674594+00	\N	fdd1f54c-7b4a-4a3e-9ad4-fe69cb23377f
00000000-0000-0000-0000-000000000000	323	uorvcm2fgqyr	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 10:40:02.401486+00	2026-05-05 10:40:02.401486+00	\N	4005f373-5f9d-486e-b912-8a0e4f8386d1
00000000-0000-0000-0000-000000000000	324	4znu3e4enhrq	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 11:16:33.219221+00	2026-05-05 11:16:33.219221+00	\N	5920c8c1-8ed5-4a6c-b7f5-cf52005b5df9
00000000-0000-0000-0000-000000000000	325	s5e4xhbv5zxd	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-05 11:16:50.708558+00	2026-05-05 11:16:50.708558+00	vqffdqch5cpa	c4a790ae-b218-4496-9d77-a507dc6cb04c
00000000-0000-0000-0000-000000000000	327	i3xbrhoal3ri	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 11:20:48.111725+00	2026-05-05 11:20:48.111725+00	kosoxr6vcuam	e9edff2f-72e3-4119-8742-d18f83784b8e
00000000-0000-0000-0000-000000000000	329	qxnlj7dfhejc	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 11:25:37.435611+00	2026-05-05 11:25:37.435611+00	\N	ccda3d9e-6f2e-437a-a296-e31f80a264aa
00000000-0000-0000-0000-000000000000	330	zef52lns4ulx	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 11:25:40.148281+00	2026-05-05 11:25:40.148281+00	\N	62604bc2-0044-4523-9d70-226c132e60b9
00000000-0000-0000-0000-000000000000	331	2u4dlxdwipp7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 11:25:42.067802+00	2026-05-05 11:25:42.067802+00	\N	c3fb64f6-59ca-4d6b-a1ca-efacdd08b485
00000000-0000-0000-0000-000000000000	332	t6bniptw6tw7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 11:25:44.072672+00	2026-05-05 11:25:44.072672+00	\N	cd004805-a941-4a3c-8165-63081c3947a5
00000000-0000-0000-0000-000000000000	333	bw54s2zfiacu	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 11:25:45.954621+00	2026-05-05 11:25:45.954621+00	\N	d4306924-41ef-4da4-9f0a-805505044a54
00000000-0000-0000-0000-000000000000	334	f4ajbcil6nbt	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 11:25:49.135969+00	2026-05-05 11:25:49.135969+00	\N	520f80a6-4a95-4538-af31-c36d708826d1
00000000-0000-0000-0000-000000000000	335	fyw3dtkjqzyk	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 11:25:51.034131+00	2026-05-05 11:25:51.034131+00	\N	29b67951-dd20-4cfb-a3d4-9dbdfa17ba40
00000000-0000-0000-0000-000000000000	336	jy6q3dgnfm6r	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 11:25:53.017282+00	2026-05-05 11:25:53.017282+00	\N	01df7d0c-48ba-4179-9b9c-f031f6a6c797
00000000-0000-0000-0000-000000000000	337	ym7v4gihnsu7	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 11:25:55.714079+00	2026-05-05 11:25:55.714079+00	\N	70b3669a-dea5-4f1f-846f-a70c85148727
00000000-0000-0000-0000-000000000000	338	f2d4ktdnamjb	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 11:26:01.672878+00	2026-05-05 11:26:01.672878+00	\N	1d65b308-36d6-4962-bbe1-eaee021b88ea
00000000-0000-0000-0000-000000000000	340	ngvuneax4kys	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 13:18:43.238335+00	2026-05-05 13:18:43.238335+00	3xlg4lohxw7k	19fa2897-d1e9-4457-aa6b-634c3358732c
00000000-0000-0000-0000-000000000000	318	tkihthledw3p	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 10:09:33.912453+00	2026-05-05 13:28:14.039782+00	\N	41bd728f-cd6d-4f75-b567-dda95e0017a2
00000000-0000-0000-0000-000000000000	341	pdrjlk4eowbm	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 13:28:14.046306+00	2026-05-05 13:28:14.046306+00	tkihthledw3p	41bd728f-cd6d-4f75-b567-dda95e0017a2
00000000-0000-0000-0000-000000000000	339	grho5byssrna	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 11:26:04.082772+00	2026-05-05 14:21:48.936343+00	\N	70ed0cf8-9b7c-4ad0-accc-c6034e7de1c9
00000000-0000-0000-0000-000000000000	326	5vseyjusshzh	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-05 11:16:51.239503+00	2026-05-05 14:22:54.769367+00	\N	60432168-ba3d-4b59-ae8b-7dc310046b03
00000000-0000-0000-0000-000000000000	328	orwnbbt4muor	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 11:20:48.760249+00	2026-05-05 14:56:44.719851+00	\N	f698b2cd-bbd1-48df-8711-abc037c2f86a
00000000-0000-0000-0000-000000000000	346	nnds6iemnh3u	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 14:56:44.727274+00	2026-05-05 14:56:44.727274+00	orwnbbt4muor	f698b2cd-bbd1-48df-8711-abc037c2f86a
00000000-0000-0000-0000-000000000000	343	g5pm7xierzhb	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 14:03:19.656727+00	2026-05-05 16:48:42.069893+00	35chubgbthbx	b0d4b141-d279-4131-8612-399170fb322c
00000000-0000-0000-0000-000000000000	348	7a5yl56zjucr	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-05 16:48:42.077079+00	2026-05-05 16:48:42.077079+00	g5pm7xierzhb	b0d4b141-d279-4131-8612-399170fb322c
00000000-0000-0000-0000-000000000000	344	ff5l6g7o4b3q	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 14:21:48.943864+00	2026-05-05 23:08:35.038172+00	grho5byssrna	70ed0cf8-9b7c-4ad0-accc-c6034e7de1c9
00000000-0000-0000-0000-000000000000	301	y7czfkcr4rit	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 09:41:02.044183+00	2026-05-06 01:46:48.26328+00	\N	f56b1375-f128-47ed-ba05-dda6cfd4c37d
00000000-0000-0000-0000-000000000000	342	ep5tzq3rvvi7	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 13:28:14.579045+00	2026-05-06 06:53:58.183741+00	\N	d37d81b0-8e0f-454e-b267-2dedb65d530e
00000000-0000-0000-0000-000000000000	351	4uea5a5jd5lb	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-06 06:53:58.198405+00	2026-05-06 06:53:58.198405+00	ep5tzq3rvvi7	d37d81b0-8e0f-454e-b267-2dedb65d530e
00000000-0000-0000-0000-000000000000	350	rm4iveugzs7v	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-06 01:46:48.286226+00	2026-05-06 09:31:40.979565+00	y7czfkcr4rit	f56b1375-f128-47ed-ba05-dda6cfd4c37d
00000000-0000-0000-0000-000000000000	352	bs2xercjs5ik	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-06 09:31:40.992109+00	2026-05-06 09:31:40.992109+00	rm4iveugzs7v	f56b1375-f128-47ed-ba05-dda6cfd4c37d
00000000-0000-0000-0000-000000000000	354	k44gzay36axy	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-06 11:04:40.276781+00	2026-05-06 11:04:40.276781+00	5wda6xwmn2s5	b5855e91-6a0b-4ac5-a5f7-2ef3e8c74a68
00000000-0000-0000-0000-000000000000	349	nxwordacr3d2	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 23:08:35.051585+00	2026-05-06 11:12:12.054896+00	ff5l6g7o4b3q	70ed0cf8-9b7c-4ad0-accc-c6034e7de1c9
00000000-0000-0000-0000-000000000000	356	sk7ufhjirmr2	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-06 11:54:46.082332+00	2026-05-06 11:54:46.082332+00	4cffr6xwc2az	36386704-5e12-48a3-b786-724e0cc4af2c
00000000-0000-0000-0000-000000000000	355	3r7t5qyulqpy	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-06 11:12:12.065099+00	2026-05-06 12:51:04.481501+00	nxwordacr3d2	70ed0cf8-9b7c-4ad0-accc-c6034e7de1c9
00000000-0000-0000-0000-000000000000	357	5hglrrfqajcc	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-06 12:51:04.491284+00	2026-05-06 12:51:04.491284+00	3r7t5qyulqpy	70ed0cf8-9b7c-4ad0-accc-c6034e7de1c9
00000000-0000-0000-0000-000000000000	353	t6v7k6yepkc6	f38b5572-029f-4d74-ac31-3d5e278df151	t	2026-05-06 09:34:22.636812+00	2026-05-06 12:55:46.386054+00	5ujv6mxupnl7	ee259390-b741-418f-a143-07dadf976d40
00000000-0000-0000-0000-000000000000	358	d7bfcbucqbur	f38b5572-029f-4d74-ac31-3d5e278df151	f	2026-05-06 12:55:46.391134+00	2026-05-06 12:55:46.391134+00	t6v7k6yepkc6	ee259390-b741-418f-a143-07dadf976d40
00000000-0000-0000-0000-000000000000	359	gngmz6k7gus5	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-06 13:53:48.786964+00	2026-05-06 13:53:48.786964+00	h75nz43nlnvl	e22c7e96-caf6-4617-bad4-d8cd3f0f6afa
00000000-0000-0000-0000-000000000000	345	eaaisvt6szbh	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-05 14:22:54.770666+00	2026-05-07 01:30:42.623624+00	5vseyjusshzh	60432168-ba3d-4b59-ae8b-7dc310046b03
00000000-0000-0000-0000-000000000000	361	o7udau3rwm5z	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-07 01:30:42.65007+00	2026-05-07 01:30:42.65007+00	eaaisvt6szbh	60432168-ba3d-4b59-ae8b-7dc310046b03
00000000-0000-0000-0000-000000000000	360	l7l4kjdl4ziw	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-06 13:53:49.799705+00	2026-05-07 03:32:12.541867+00	\N	242199f4-395a-454d-83e0-67cfa7222f97
00000000-0000-0000-0000-000000000000	363	jjdtaue2xeev	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-07 03:32:12.556379+00	2026-05-07 03:32:12.556379+00	l7l4kjdl4ziw	242199f4-395a-454d-83e0-67cfa7222f97
00000000-0000-0000-0000-000000000000	364	qsugbt7wwvzo	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-07 03:32:13.585841+00	2026-05-07 03:32:13.585841+00	\N	60ba9e8b-0479-4868-97bf-ef70c2bb3266
00000000-0000-0000-0000-000000000000	365	r4mzsqzoswii	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-07 04:22:11.546593+00	2026-05-07 04:22:11.546593+00	ohebn2dxf6pl	b01a92b3-3e87-4abf-b47a-33ab1e635878
00000000-0000-0000-0000-000000000000	366	o3qfebgyllck	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-07 04:22:13.010469+00	2026-05-07 04:22:13.010469+00	\N	5231d6de-9266-4dca-b421-c7bc1fc3343b
00000000-0000-0000-0000-000000000000	362	43z5yneirozp	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-07 01:30:43.642585+00	2026-05-07 04:50:56.175606+00	\N	79ec4ab0-5548-45ec-800d-94b0d3f11ceb
00000000-0000-0000-0000-000000000000	317	d6xwewqu2cjc	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 10:04:00.043444+00	2026-05-07 05:27:47.503108+00	\N	f5b8ecfe-4e0f-4947-87d0-b89d590c13ee
00000000-0000-0000-0000-000000000000	347	heie6d6dzqgm	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-05 15:25:21.106465+00	2026-05-07 17:39:07.153782+00	\N	c25d9809-45d9-4a72-b6a6-bc6ec95f4969
00000000-0000-0000-0000-000000000000	466	7xyjxzbi5ndq	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-15 09:22:34.570473+00	2026-05-15 09:22:34.570473+00	jtyr4gchqtnt	56a07ac3-04d7-4170-a60c-677df48ce0c2
00000000-0000-0000-0000-000000000000	368	vjm6yp32bc2b	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-07 05:27:47.509564+00	2026-05-07 05:27:47.509564+00	d6xwewqu2cjc	f5b8ecfe-4e0f-4947-87d0-b89d590c13ee
00000000-0000-0000-0000-000000000000	369	kuqipkqnqocg	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-07 05:27:48.55948+00	2026-05-07 07:37:21.656416+00	\N	c50a15ab-4492-4581-bcde-1688c05ffe9b
00000000-0000-0000-0000-000000000000	370	vvnlbz5ntkkg	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-07 07:37:21.665848+00	2026-05-07 07:37:21.665848+00	kuqipkqnqocg	c50a15ab-4492-4581-bcde-1688c05ffe9b
00000000-0000-0000-0000-000000000000	469	3yae6qsinxza	46283390-81d3-4324-9d77-9cfd33c224bc	t	2026-05-18 04:08:36.536705+00	2026-05-18 05:30:18.367586+00	\N	3ba82bd1-8321-4ca5-ac96-1fae1ec0181c
00000000-0000-0000-0000-000000000000	367	nhoolv7kslai	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	t	2026-05-07 04:50:56.184485+00	2026-05-07 07:52:09.178068+00	43z5yneirozp	79ec4ab0-5548-45ec-800d-94b0d3f11ceb
00000000-0000-0000-0000-000000000000	372	2j525xccxizm	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-07 07:52:09.183908+00	2026-05-07 07:52:09.183908+00	nhoolv7kslai	79ec4ab0-5548-45ec-800d-94b0d3f11ceb
00000000-0000-0000-0000-000000000000	373	jpsnz2vmxfrf	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	f	2026-05-07 07:52:10.087406+00	2026-05-07 07:52:10.087406+00	\N	985a6fb5-dd71-4f3c-9f23-342ffef72660
00000000-0000-0000-0000-000000000000	374	o72wcywdzmve	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-07 17:39:07.169447+00	2026-05-07 17:39:07.169447+00	heie6d6dzqgm	c25d9809-45d9-4a72-b6a6-bc6ec95f4969
00000000-0000-0000-0000-000000000000	371	w5m3qtvkxqmh	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-07 07:37:23.031335+00	2026-05-08 13:45:35.123789+00	\N	283eee76-180d-444b-8d01-f9d01b30dd1f
00000000-0000-0000-0000-000000000000	376	6muts6orumqc	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-08 13:45:35.139634+00	2026-05-08 13:45:35.139634+00	w5m3qtvkxqmh	283eee76-180d-444b-8d01-f9d01b30dd1f
00000000-0000-0000-0000-000000000000	475	h6dcbwvb4oo6	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	f	2026-05-18 08:14:28.751173+00	2026-05-18 08:14:28.751173+00	\N	b3db0ff5-e566-4e01-9e71-8d96ca73f793
00000000-0000-0000-0000-000000000000	378	mvv3qffktgos	815c5ba4-df3e-470b-a277-f6e9b9c1941e	f	2026-05-09 03:51:09.761462+00	2026-05-09 03:51:09.761462+00	\N	53fda4c7-6e61-4c7d-bdc8-6b933c1c7883
00000000-0000-0000-0000-000000000000	472	h36owqpimjuy	46283390-81d3-4324-9d77-9cfd33c224bc	t	2026-05-18 06:15:28.950772+00	2026-05-18 08:16:07.720944+00	\N	d34e0fae-d491-403a-86f4-8ac23bdb5b21
00000000-0000-0000-0000-000000000000	380	y335sddgpd3j	815c5ba4-df3e-470b-a277-f6e9b9c1941e	f	2026-05-09 03:55:37.930344+00	2026-05-09 03:55:37.930344+00	\N	f8cfedfc-bbd8-4fec-9837-cffb780237bc
00000000-0000-0000-0000-000000000000	382	jyqdeazhevmi	815c5ba4-df3e-470b-a277-f6e9b9c1941e	f	2026-05-09 08:57:05.492334+00	2026-05-09 08:57:05.492334+00	\N	d2aeb278-0666-4fce-97f4-b67f59b819a3
00000000-0000-0000-0000-000000000000	381	lujq4vhlkago	815c5ba4-df3e-470b-a277-f6e9b9c1941e	t	2026-05-09 08:56:48.423942+00	2026-05-09 10:00:21.766236+00	\N	411dd013-b3ae-49d4-afec-bb2318f2c810
00000000-0000-0000-0000-000000000000	477	aor435alzpia	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	t	2026-05-18 08:31:26.304009+00	2026-05-18 09:53:45.45551+00	\N	301ea009-f107-459d-a047-89550e1a5fa1
00000000-0000-0000-0000-000000000000	383	b3m3q5ijbk3h	815c5ba4-df3e-470b-a277-f6e9b9c1941e	t	2026-05-09 10:00:21.778628+00	2026-05-09 22:37:16.870966+00	lujq4vhlkago	411dd013-b3ae-49d4-afec-bb2318f2c810
00000000-0000-0000-0000-000000000000	384	q54pvx67pihd	815c5ba4-df3e-470b-a277-f6e9b9c1941e	f	2026-05-09 22:37:16.878776+00	2026-05-09 22:37:16.878776+00	b3m3q5ijbk3h	411dd013-b3ae-49d4-afec-bb2318f2c810
00000000-0000-0000-0000-000000000000	482	3z4lkisj3kta	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	f	2026-05-18 10:08:14.810379+00	2026-05-18 10:08:14.810379+00	\N	ac829951-5a35-41ec-a5f4-89d73a923a5b
00000000-0000-0000-0000-000000000000	375	p6ugq4dspj7t	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-07 17:39:08.519006+00	2026-05-10 01:38:26.983976+00	\N	ca4c863a-9a15-4c49-8eb3-ecbf6f441425
00000000-0000-0000-0000-000000000000	386	yiaafw4mao7k	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-10 01:38:26.993395+00	2026-05-10 01:38:26.993395+00	p6ugq4dspj7t	ca4c863a-9a15-4c49-8eb3-ecbf6f441425
00000000-0000-0000-0000-000000000000	387	kghjsv55yuwk	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-10 01:38:27.889583+00	2026-05-10 01:38:27.889583+00	\N	7c515e71-0f87-4ab3-adad-8905fc80ee8f
00000000-0000-0000-0000-000000000000	388	wvwre7vjryso	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-10 01:42:49.208623+00	2026-05-10 01:42:49.208623+00	\N	aa8653a4-f2fa-4bf1-8eee-33f2d4962055
00000000-0000-0000-0000-000000000000	385	ppsmjn7xbl3t	815c5ba4-df3e-470b-a277-f6e9b9c1941e	t	2026-05-10 00:27:00.711147+00	2026-05-10 01:51:43.334251+00	\N	39e8b758-f1db-4777-9160-edc23a7a3fdc
00000000-0000-0000-0000-000000000000	389	tumfhyeabhxl	815c5ba4-df3e-470b-a277-f6e9b9c1941e	f	2026-05-10 01:51:43.340325+00	2026-05-10 01:51:43.340325+00	ppsmjn7xbl3t	39e8b758-f1db-4777-9160-edc23a7a3fdc
00000000-0000-0000-0000-000000000000	379	pc53nyvg3djv	815c5ba4-df3e-470b-a277-f6e9b9c1941e	t	2026-05-09 03:51:10.038099+00	2026-05-10 02:11:12.835696+00	\N	c26f1670-380b-4135-8454-b6308cfe83ae
00000000-0000-0000-0000-000000000000	390	svowys46j6an	815c5ba4-df3e-470b-a277-f6e9b9c1941e	f	2026-05-10 02:11:12.8416+00	2026-05-10 02:11:12.8416+00	pc53nyvg3djv	c26f1670-380b-4135-8454-b6308cfe83ae
00000000-0000-0000-0000-000000000000	484	pgb5swttudiz	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	f	2026-05-18 10:10:43.32605+00	2026-05-18 10:10:43.32605+00	\N	a408d35f-c1a0-49af-866e-3daa69f6a218
00000000-0000-0000-0000-000000000000	392	dc2xn7tukxrh	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-10 02:22:30.857333+00	2026-05-10 02:22:30.857333+00	\N	f1f20aee-43c5-4368-99ac-921f6f91d405
00000000-0000-0000-0000-000000000000	391	l7ekc2d7glb3	815c5ba4-df3e-470b-a277-f6e9b9c1941e	t	2026-05-10 02:11:13.372064+00	2026-05-10 03:19:23.721754+00	\N	dca37899-79e9-4128-9868-d2919b25d223
00000000-0000-0000-0000-000000000000	485	4zu7ugxg5lxj	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-18 10:10:57.824857+00	2026-05-18 10:10:57.824857+00	dxssn27s67qu	d34e0fae-d491-403a-86f4-8ac23bdb5b21
00000000-0000-0000-0000-000000000000	393	y4elxj2q4zob	815c5ba4-df3e-470b-a277-f6e9b9c1941e	t	2026-05-10 03:19:23.737042+00	2026-05-10 05:16:19.643377+00	l7ekc2d7glb3	dca37899-79e9-4128-9868-d2919b25d223
00000000-0000-0000-0000-000000000000	487	i477fj6uw5y6	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	f	2026-05-18 10:28:58.660639+00	2026-05-18 10:28:58.660639+00	\N	2c24d48f-886c-48c1-8033-d4c3baa33181
00000000-0000-0000-0000-000000000000	394	6qdtvchyhe7u	815c5ba4-df3e-470b-a277-f6e9b9c1941e	t	2026-05-10 05:16:19.656139+00	2026-05-10 09:10:01.207622+00	y4elxj2q4zob	dca37899-79e9-4128-9868-d2919b25d223
00000000-0000-0000-0000-000000000000	395	3xil676utlfr	815c5ba4-df3e-470b-a277-f6e9b9c1941e	f	2026-05-10 09:10:01.232678+00	2026-05-10 09:10:01.232678+00	6qdtvchyhe7u	dca37899-79e9-4128-9868-d2919b25d223
00000000-0000-0000-0000-000000000000	377	tgwbbgvbwtkn	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-08 13:45:35.785397+00	2026-05-10 09:56:26.301878+00	\N	2e2b56bf-045f-48dd-9217-26512e6cd3c8
00000000-0000-0000-0000-000000000000	396	syqh5vz3tf4c	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-10 09:56:26.31533+00	2026-05-10 09:56:26.31533+00	tgwbbgvbwtkn	2e2b56bf-045f-48dd-9217-26512e6cd3c8
00000000-0000-0000-0000-000000000000	398	zk4zeqsjntng	adea62ce-52d6-489d-82e7-362203d85c01	f	2026-05-12 03:33:37.121951+00	2026-05-12 03:33:37.121951+00	\N	c68b23b6-4a30-480f-b672-e86dc4a40424
00000000-0000-0000-0000-000000000000	400	yg4llg6vtw5y	4528c17c-395c-4e97-981c-17dbe2bc8181	f	2026-05-12 03:55:40.222175+00	2026-05-12 03:55:40.222175+00	\N	2ebb6473-f134-4ccc-9d89-8bb556761f15
00000000-0000-0000-0000-000000000000	401	4ag25cislrt7	4528c17c-395c-4e97-981c-17dbe2bc8181	f	2026-05-12 03:59:29.142556+00	2026-05-12 03:59:29.142556+00	\N	77216d52-e035-4932-ba7e-95dc667cb37d
00000000-0000-0000-0000-000000000000	402	nhwbc5fbdypc	4528c17c-395c-4e97-981c-17dbe2bc8181	f	2026-05-12 04:06:24.255814+00	2026-05-12 04:06:24.255814+00	\N	d1773aa4-e2cf-4f16-9cc7-d8011cef7d4d
00000000-0000-0000-0000-000000000000	403	hxcmp6gepnsq	adea62ce-52d6-489d-82e7-362203d85c01	f	2026-05-12 04:12:25.470476+00	2026-05-12 04:12:25.470476+00	\N	b52db1d5-6c8c-4995-b853-f397880ae4f9
00000000-0000-0000-0000-000000000000	404	uog6lkygvgbn	4528c17c-395c-4e97-981c-17dbe2bc8181	f	2026-05-12 04:12:28.481885+00	2026-05-12 04:12:28.481885+00	\N	5a8cf411-baf1-4b30-b544-3c2e7fa015ba
00000000-0000-0000-0000-000000000000	405	3pq7vj2rbuyh	4528c17c-395c-4e97-981c-17dbe2bc8181	f	2026-05-12 04:28:07.478048+00	2026-05-12 04:28:07.478048+00	\N	77fb3af8-c054-4368-9646-76975b99daab
00000000-0000-0000-0000-000000000000	406	mhrypekjn33r	4528c17c-395c-4e97-981c-17dbe2bc8181	f	2026-05-12 04:30:02.7505+00	2026-05-12 04:30:02.7505+00	\N	951306fa-76e5-4cd6-8af4-a03b3d32a7d4
00000000-0000-0000-0000-000000000000	399	feo6wiyxdljy	adea62ce-52d6-489d-82e7-362203d85c01	t	2026-05-12 03:33:37.410731+00	2026-05-12 04:32:23.820816+00	\N	f6621222-744f-4704-aa28-e79af2f5cdc9
00000000-0000-0000-0000-000000000000	407	llidlvtje3xg	adea62ce-52d6-489d-82e7-362203d85c01	t	2026-05-12 04:32:23.828421+00	2026-05-12 05:51:57.813207+00	feo6wiyxdljy	f6621222-744f-4704-aa28-e79af2f5cdc9
00000000-0000-0000-0000-000000000000	408	lidwpruu7ogj	adea62ce-52d6-489d-82e7-362203d85c01	t	2026-05-12 05:51:57.827989+00	2026-05-12 07:06:54.035178+00	llidlvtje3xg	f6621222-744f-4704-aa28-e79af2f5cdc9
00000000-0000-0000-0000-000000000000	418	f5ufxsea3iru	adea62ce-52d6-489d-82e7-362203d85c01	t	2026-05-12 06:41:10.824341+00	2026-05-12 07:47:50.286165+00	\N	7239565e-2a02-4ae8-a885-79423fc264b5
00000000-0000-0000-0000-000000000000	422	vytm77b5gciq	adea62ce-52d6-489d-82e7-362203d85c01	t	2026-05-12 07:06:54.040816+00	2026-05-12 08:17:33.955721+00	lidwpruu7ogj	f6621222-744f-4704-aa28-e79af2f5cdc9
00000000-0000-0000-0000-000000000000	397	piywgtd6ez2d	4ab940a0-686b-4685-ac38-9d5e566db113	t	2026-05-10 09:56:26.859524+00	2026-05-12 14:02:32.191251+00	\N	5a6c9ea6-1188-4c21-93a6-b3efb87a6a62
00000000-0000-0000-0000-000000000000	460	malc262arcvp	46283390-81d3-4324-9d77-9cfd33c224bc	t	2026-05-12 23:34:49.14408+00	2026-05-13 00:33:19.253493+00	\N	1e168b2c-11d4-4092-b676-4c8e788f8538
00000000-0000-0000-0000-000000000000	470	wgnuro5lpmxj	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-18 05:30:18.382666+00	2026-05-18 05:30:18.382666+00	3yae6qsinxza	3ba82bd1-8321-4ca5-ac96-1fae1ec0181c
00000000-0000-0000-0000-000000000000	428	jwc73tczi3lp	adea62ce-52d6-489d-82e7-362203d85c01	f	2026-05-12 07:47:50.290622+00	2026-05-12 07:47:50.290622+00	f5ufxsea3iru	7239565e-2a02-4ae8-a885-79423fc264b5
00000000-0000-0000-0000-000000000000	473	szhq4v3lkmqu	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-18 08:09:24.072857+00	2026-05-18 09:53:26.607771+00	v6ylodfokg6n	2267c369-25de-4d41-ac5e-a2a6c1db726d
00000000-0000-0000-0000-000000000000	479	aoyjdpsubp6i	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	f	2026-05-18 09:53:45.455905+00	2026-05-18 09:53:45.455905+00	aor435alzpia	301ea009-f107-459d-a047-89550e1a5fa1
00000000-0000-0000-0000-000000000000	480	yuvm2i4awytj	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	f	2026-05-18 09:54:09.211947+00	2026-05-18 09:54:09.211947+00	\N	b0bfa512-f3f1-4e1b-a670-6b2ec0ca061e
00000000-0000-0000-0000-000000000000	435	tdq6ifjnzia6	adea62ce-52d6-489d-82e7-362203d85c01	f	2026-05-12 08:17:33.977404+00	2026-05-12 08:17:33.977404+00	vytm77b5gciq	f6621222-744f-4704-aa28-e79af2f5cdc9
00000000-0000-0000-0000-000000000000	481	3a5spbzen7sh	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	f	2026-05-18 09:54:24.28048+00	2026-05-18 09:54:24.28048+00	\N	ff7b77e1-d0da-4e7d-a9fe-66e66212fbd0
00000000-0000-0000-0000-000000000000	483	w4fg3tlxuzi6	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	f	2026-05-18 10:09:30.449934+00	2026-05-18 10:09:30.449934+00	\N	ba5f6d5c-056c-495c-8ee8-40c28dd0c413
00000000-0000-0000-0000-000000000000	476	dxssn27s67qu	46283390-81d3-4324-9d77-9cfd33c224bc	t	2026-05-18 08:16:07.725849+00	2026-05-18 10:10:57.823041+00	h36owqpimjuy	d34e0fae-d491-403a-86f4-8ac23bdb5b21
00000000-0000-0000-0000-000000000000	486	uino3kz3hp37	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	f	2026-05-18 10:23:46.244529+00	2026-05-18 10:23:46.244529+00	\N	4d66d408-82ab-46de-a7b6-934f9e7eeaaa
00000000-0000-0000-0000-000000000000	467	ph7exeqvfzjr	46283390-81d3-4324-9d77-9cfd33c224bc	t	2026-05-15 09:43:06.267039+00	2026-05-18 11:04:28.830484+00	\N	ac1a3931-538e-47e3-acd7-0d8bc8aeab11
00000000-0000-0000-0000-000000000000	488	smzof5wmuzdg	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-18 11:04:28.839662+00	2026-05-18 11:04:28.839662+00	ph7exeqvfzjr	ac1a3931-538e-47e3-acd7-0d8bc8aeab11
00000000-0000-0000-0000-000000000000	489	uwgrtyy5c7yu	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-18 11:04:50.215506+00	2026-05-18 11:04:50.215506+00	zqjbjnhx4kiz	8b41447d-9c32-4326-88e3-110c74428913
00000000-0000-0000-0000-000000000000	490	n5l3pghpcg7v	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-18 11:05:27.785336+00	2026-05-18 11:05:27.785336+00	\N	93d9de5e-25f0-4ac9-a89d-0e181191a7cd
00000000-0000-0000-0000-000000000000	444	7jez5xnhqpog	99321c1d-2254-4bbe-a5df-d14e52829a39	f	2026-05-12 08:51:23.349973+00	2026-05-12 08:51:23.349973+00	\N	d60afcd7-b32f-48b5-bae3-dca6ea401fa5
00000000-0000-0000-0000-000000000000	445	fuskmsujrrex	99321c1d-2254-4bbe-a5df-d14e52829a39	f	2026-05-12 09:10:19.609622+00	2026-05-12 09:10:19.609622+00	\N	1f914aeb-48e0-42f8-b2c1-97655312f96b
00000000-0000-0000-0000-000000000000	491	rk4pehyr6zd4	722d8397-103b-4234-8e9d-e329674e79f2	f	2026-05-18 11:05:48.819935+00	2026-05-18 11:05:48.819935+00	\N	6d57fa82-abff-4e10-8999-0e08f39bec07
00000000-0000-0000-0000-000000000000	436	dkwkmwq6feuy	adea62ce-52d6-489d-82e7-362203d85c01	t	2026-05-12 08:17:34.688034+00	2026-05-12 09:19:00.372748+00	\N	22ea508e-6367-466a-827c-20bb8d5a49b0
00000000-0000-0000-0000-000000000000	443	j4owobvbjim5	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-12 08:39:50.507529+00	2026-05-12 09:39:26.225085+00	\N	1e05550b-a835-47de-b6c4-89c3becb4d3d
00000000-0000-0000-0000-000000000000	478	rrjp2hb2kshh	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-18 09:53:26.625658+00	2026-05-18 12:16:33.526416+00	szhq4v3lkmqu	2267c369-25de-4d41-ac5e-a2a6c1db726d
00000000-0000-0000-0000-000000000000	446	djxwauwbmfmp	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-12 09:12:02.791476+00	2026-05-12 10:11:29.880924+00	\N	4d00bd00-001c-441c-8adb-3f1cc803f68e
00000000-0000-0000-0000-000000000000	449	hkzt5xvlmvsv	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-12 10:11:29.886724+00	2026-05-12 12:55:10.767395+00	djxwauwbmfmp	4d00bd00-001c-441c-8adb-3f1cc803f68e
00000000-0000-0000-0000-000000000000	447	iavqpr3blzv7	adea62ce-52d6-489d-82e7-362203d85c01	t	2026-05-12 09:19:00.381916+00	2026-05-12 13:21:01.268722+00	dkwkmwq6feuy	22ea508e-6367-466a-827c-20bb8d5a49b0
00000000-0000-0000-0000-000000000000	451	7xuvwkqli5wt	adea62ce-52d6-489d-82e7-362203d85c01	f	2026-05-12 13:21:01.275451+00	2026-05-12 13:21:01.275451+00	iavqpr3blzv7	22ea508e-6367-466a-827c-20bb8d5a49b0
00000000-0000-0000-0000-000000000000	495	za6kiwphzhej	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:02:00.981284+00	2026-05-18 13:02:00.981284+00	\N	173bdbdc-9ed8-431e-a70b-005c30c9b18c
00000000-0000-0000-0000-000000000000	448	olmyuvpqen5l	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-12 09:39:26.229679+00	2026-05-12 13:21:32.334684+00	j4owobvbjim5	1e05550b-a835-47de-b6c4-89c3becb4d3d
00000000-0000-0000-0000-000000000000	496	gsi4v2zamghw	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:02:01.211872+00	2026-05-18 13:02:01.211872+00	\N	1812dafd-f0c3-46e3-87f1-47e582dba5c6
00000000-0000-0000-0000-000000000000	450	dx6c7s4zuyav	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-12 12:55:10.789835+00	2026-05-12 13:55:40.11413+00	hkzt5xvlmvsv	4d00bd00-001c-441c-8adb-3f1cc803f68e
00000000-0000-0000-0000-000000000000	454	fogkismz4z3x	99321c1d-2254-4bbe-a5df-d14e52829a39	f	2026-05-12 13:55:40.120885+00	2026-05-12 13:55:40.120885+00	dx6c7s4zuyav	4d00bd00-001c-441c-8adb-3f1cc803f68e
00000000-0000-0000-0000-000000000000	455	xtjhbckyska6	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-12 14:02:32.202242+00	2026-05-12 14:02:32.202242+00	piywgtd6ez2d	5a6c9ea6-1188-4c21-93a6-b3efb87a6a62
00000000-0000-0000-0000-000000000000	456	lzo2pndmd7cg	4ab940a0-686b-4685-ac38-9d5e566db113	f	2026-05-12 14:02:32.979307+00	2026-05-12 14:02:32.979307+00	\N	df9d2a92-9a6c-4462-92b9-c735af849ff0
00000000-0000-0000-0000-000000000000	452	gkherwtwngkm	adea62ce-52d6-489d-82e7-362203d85c01	t	2026-05-12 13:21:08.877145+00	2026-05-12 14:21:48.671829+00	\N	5b87f05b-cae5-422d-9b90-7b064bfa0c0a
00000000-0000-0000-0000-000000000000	457	2xo2sw6aougd	adea62ce-52d6-489d-82e7-362203d85c01	f	2026-05-12 14:21:48.679456+00	2026-05-12 14:21:48.679456+00	gkherwtwngkm	5b87f05b-cae5-422d-9b90-7b064bfa0c0a
00000000-0000-0000-0000-000000000000	453	bwumpknht6ty	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-12 13:21:32.342191+00	2026-05-12 23:33:55.966223+00	olmyuvpqen5l	1e05550b-a835-47de-b6c4-89c3becb4d3d
00000000-0000-0000-0000-000000000000	458	v7mr3co3bjmq	99321c1d-2254-4bbe-a5df-d14e52829a39	f	2026-05-12 23:33:55.995437+00	2026-05-12 23:33:55.995437+00	bwumpknht6ty	1e05550b-a835-47de-b6c4-89c3becb4d3d
00000000-0000-0000-0000-000000000000	459	rch73jycteeb	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-12 23:34:48.852693+00	2026-05-12 23:34:48.852693+00	\N	2777a7c1-042f-4dca-8f0c-45dbd379f32d
00000000-0000-0000-0000-000000000000	497	mzatxufpkzfp	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:02:04.200884+00	2026-05-18 13:02:04.200884+00	\N	56a558f9-91d8-4314-9657-fe5ab0b3fe39
00000000-0000-0000-0000-000000000000	498	bv6ujsuupx3m	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:02:08.90454+00	2026-05-18 13:02:08.90454+00	\N	787f349d-0811-4b90-899c-a78659a6e9e4
00000000-0000-0000-0000-000000000000	499	vbrfyprmtc5z	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:02:14.600781+00	2026-05-18 13:02:14.600781+00	\N	a273fcc9-ee59-4450-9cb6-df0c9da8f5d0
00000000-0000-0000-0000-000000000000	500	favjakh53shx	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:02:18.54992+00	2026-05-18 13:02:18.54992+00	\N	5aaaac41-8517-4c2a-8032-3d4558b4cdad
00000000-0000-0000-0000-000000000000	501	2qtwp64s5ev4	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:02:22.054952+00	2026-05-18 13:02:22.054952+00	\N	7610f4c3-8829-444e-b095-a1053a3ebf4e
00000000-0000-0000-0000-000000000000	502	nwqqrkywq3xo	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:02:31.768117+00	2026-05-18 13:02:31.768117+00	\N	077d4037-bff8-44e0-b512-41064312a15a
00000000-0000-0000-0000-000000000000	503	q7hqlsrhjsk6	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:02:36.404474+00	2026-05-18 13:02:36.404474+00	\N	7157f531-a0a6-4885-a1e5-5bbfa26eef79
00000000-0000-0000-0000-000000000000	504	6xy5mnk62xc3	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:03:40.201231+00	2026-05-18 13:03:40.201231+00	\N	dc834374-9cbe-409c-8415-890821d4a1cf
00000000-0000-0000-0000-000000000000	494	ubdyr7fwqrup	46283390-81d3-4324-9d77-9cfd33c224bc	t	2026-05-18 12:37:54.485868+00	2026-05-19 00:10:25.126712+00	\N	281b0af4-4387-42c9-b740-75e26f4a86ea
00000000-0000-0000-0000-000000000000	492	ctk4pjdnivlf	722d8397-103b-4234-8e9d-e329674e79f2	t	2026-05-18 11:05:49.091961+00	2026-05-19 14:54:58.054793+00	\N	178edd41-53bd-41f6-aa72-5682326ecd16
00000000-0000-0000-0000-000000000000	493	f6h26qbjy6rd	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-18 12:16:33.534558+00	2026-05-20 09:39:24.909938+00	rrjp2hb2kshh	2267c369-25de-4d41-ac5e-a2a6c1db726d
00000000-0000-0000-0000-000000000000	505	fl6tteb6gi2p	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:03:46.303101+00	2026-05-18 13:03:46.303101+00	\N	6f43e9ca-0450-4a4c-8046-53528ca63fb2
00000000-0000-0000-0000-000000000000	506	grmiba3pm5lh	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:03:52.825071+00	2026-05-18 13:03:52.825071+00	\N	6bd75a30-b7e0-4c78-b691-1f95c4578c91
00000000-0000-0000-0000-000000000000	507	wzzwa4g2242c	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:04:54.996631+00	2026-05-18 13:04:54.996631+00	\N	fc9a9266-354d-42c0-bf31-88f379ddf804
00000000-0000-0000-0000-000000000000	508	wgmi35hmqr4w	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:05:08.845801+00	2026-05-18 13:05:08.845801+00	\N	0145cc85-5691-435d-ad55-8eab30cc0984
00000000-0000-0000-0000-000000000000	509	obkiizkzzn4h	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:06:01.41085+00	2026-05-18 13:06:01.41085+00	\N	298fcc0c-55c4-4360-b565-f10207a39720
00000000-0000-0000-0000-000000000000	510	jcgmavhx6bpd	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:06:31.886868+00	2026-05-18 13:06:31.886868+00	\N	eedcda3d-ddca-4dcd-9963-76557e88415e
00000000-0000-0000-0000-000000000000	511	mhaa44bfz2z7	a24e2881-8767-4f08-9552-fc3376516585	f	2026-05-18 13:06:34.69945+00	2026-05-18 13:06:34.69945+00	\N	9e53e2ef-f449-4f60-a723-f5d36105a677
00000000-0000-0000-0000-000000000000	512	5gmxmuzwecox	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-19 00:10:25.140301+00	2026-05-19 00:10:25.140301+00	ubdyr7fwqrup	281b0af4-4387-42c9-b740-75e26f4a86ea
00000000-0000-0000-0000-000000000000	513	346fspnupvlr	46283390-81d3-4324-9d77-9cfd33c224bc	f	2026-05-19 00:10:26.246528+00	2026-05-19 00:10:26.246528+00	\N	45a78244-e0b5-4800-a0a6-6d4b8d77b1d9
00000000-0000-0000-0000-000000000000	514	hn2a7sv22bhi	722d8397-103b-4234-8e9d-e329674e79f2	f	2026-05-19 14:54:58.081042+00	2026-05-19 14:54:58.081042+00	ctk4pjdnivlf	178edd41-53bd-41f6-aa72-5682326ecd16
00000000-0000-0000-0000-000000000000	515	rbh5sy435iz3	99321c1d-2254-4bbe-a5df-d14e52829a39	f	2026-05-20 09:26:11.500976+00	2026-05-20 09:26:11.500976+00	\N	403f4ce5-7ae0-47bb-8c39-5bbe942ed4f9
00000000-0000-0000-0000-000000000000	516	ofmvm7nh5knm	99321c1d-2254-4bbe-a5df-d14e52829a39	f	2026-05-20 09:29:29.511331+00	2026-05-20 09:29:29.511331+00	\N	fa339652-cd72-40ea-ba85-1a74a7ac69aa
00000000-0000-0000-0000-000000000000	518	tsobl3ptw3hr	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-20 10:16:05.099955+00	2026-05-20 10:16:05.099955+00	\N	9650b067-00cf-4467-9bab-26c6971b506d
00000000-0000-0000-0000-000000000000	519	5rd6ll457d4c	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-20 10:16:57.383176+00	2026-05-20 10:16:57.383176+00	\N	b55abdfb-eee2-4d74-ba51-db2efd6bd37f
00000000-0000-0000-0000-000000000000	520	m6dafui6qocs	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-20 10:31:04.256192+00	2026-05-20 10:31:04.256192+00	\N	718b35c6-8d24-4290-b73a-b23ef6886f7c
00000000-0000-0000-0000-000000000000	521	d2v3fhgdrwoh	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-20 10:31:31.469823+00	2026-05-20 10:31:31.469823+00	\N	f5d23264-269e-441f-a54a-98cc655586c6
00000000-0000-0000-0000-000000000000	522	bowmikky3rcu	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-20 10:32:05.801434+00	2026-05-20 10:32:05.801434+00	\N	9f13e170-8b46-4398-9311-fbeb9e4df81e
00000000-0000-0000-0000-000000000000	524	flsx2tvtjmdo	0b718cac-6cd9-494a-9076-e924f23783d0	f	2026-05-20 11:11:02.252846+00	2026-05-20 11:11:02.252846+00	\N	3e540e7a-1663-46b1-993d-4fc552d9ee71
00000000-0000-0000-0000-000000000000	523	zxeprroipir6	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	t	2026-05-20 10:33:21.903474+00	2026-05-21 06:24:32.473391+00	\N	99c5a4a8-3ae9-4d40-b307-c2c733aa45c0
00000000-0000-0000-0000-000000000000	527	u2fssvy7ctks	0b718cac-6cd9-494a-9076-e924f23783d0	f	2026-05-21 06:37:58.841717+00	2026-05-21 06:37:58.841717+00	\N	c961e55c-311d-4fff-9aaa-53c8bae47578
00000000-0000-0000-0000-000000000000	528	qmhlrem7dbzu	0b718cac-6cd9-494a-9076-e924f23783d0	f	2026-05-21 06:38:37.499088+00	2026-05-21 06:38:37.499088+00	\N	48d65a47-d38a-41ae-ac93-f86e647ffcb0
00000000-0000-0000-0000-000000000000	530	wh3bvde2anj6	0b718cac-6cd9-494a-9076-e924f23783d0	f	2026-05-21 07:20:33.683208+00	2026-05-21 07:20:33.683208+00	\N	e5c5d073-5be8-4eb3-a6fd-923c101e1af1
00000000-0000-0000-0000-000000000000	526	x5g2bycljlcu	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	t	2026-05-21 06:24:32.492185+00	2026-05-21 07:24:57.715632+00	zxeprroipir6	99c5a4a8-3ae9-4d40-b307-c2c733aa45c0
00000000-0000-0000-0000-000000000000	531	edgolu4kr5sd	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-21 07:24:57.722642+00	2026-05-21 07:24:57.722642+00	x5g2bycljlcu	99c5a4a8-3ae9-4d40-b307-c2c733aa45c0
00000000-0000-0000-0000-000000000000	532	iy5mm2bxdsog	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-21 07:25:53.24415+00	2026-05-21 07:25:53.24415+00	\N	ea8dad74-f70d-438c-8526-cc46490b27b2
00000000-0000-0000-0000-000000000000	533	lfmltlxgijdy	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-21 07:27:31.710008+00	2026-05-21 07:27:31.710008+00	\N	22db4a20-9d90-4d8f-9238-2fc87d44ca8b
00000000-0000-0000-0000-000000000000	534	go4ash22dysn	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-21 07:27:53.989068+00	2026-05-21 07:27:53.989068+00	\N	eddca24c-cb63-455b-9d60-83fb02e06ba0
00000000-0000-0000-0000-000000000000	536	ibzfmjsqdwzt	0b718cac-6cd9-494a-9076-e924f23783d0	f	2026-05-21 07:44:24.586942+00	2026-05-21 07:44:24.586942+00	\N	b5726f4e-5818-495a-9ae6-64502b093101
00000000-0000-0000-0000-000000000000	535	pn5ehcrbagjw	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	t	2026-05-21 07:28:09.147084+00	2026-05-21 08:29:29.689848+00	\N	b0bd8c31-6419-4c4e-b99a-315327dc19d1
00000000-0000-0000-0000-000000000000	537	r37gxkd57lfi	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-21 08:29:29.69798+00	2026-05-21 08:29:29.69798+00	pn5ehcrbagjw	b0bd8c31-6419-4c4e-b99a-315327dc19d1
00000000-0000-0000-0000-000000000000	538	jzrv3l47rtzx	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-21 08:30:48.916537+00	2026-05-21 08:30:48.916537+00	\N	9cc68a49-4bd7-450a-9bac-2170d2bb9986
00000000-0000-0000-0000-000000000000	539	xbm5yka3sual	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-21 08:42:28.4906+00	2026-05-21 08:42:28.4906+00	\N	de9475b5-d803-4ebe-b3b9-374ddbfecb34
00000000-0000-0000-0000-000000000000	540	2seap2wnklam	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-21 08:45:05.236887+00	2026-05-21 08:45:05.236887+00	\N	fa513c6d-6a2e-4da8-9f86-8fd529a87df6
00000000-0000-0000-0000-000000000000	542	b5avkdf6d3xj	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-21 08:47:08.178691+00	2026-05-21 08:47:08.178691+00	\N	d63f1d54-62c1-4c78-9cd4-7e8ffaa6ae7d
00000000-0000-0000-0000-000000000000	529	ri5t6cekcfz2	0b718cac-6cd9-494a-9076-e924f23783d0	t	2026-05-21 07:06:41.419076+00	2026-05-21 09:06:22.773785+00	\N	e79dd47d-76bd-4f67-9ed9-f7bedbd770a3
00000000-0000-0000-0000-000000000000	544	yccguh5b3m3x	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-21 13:31:13.370559+00	2026-05-21 13:31:13.370559+00	\N	46dfae19-78ed-4b2b-af7c-63986cbd74aa
00000000-0000-0000-0000-000000000000	545	rujjvm5hmehm	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-21 13:39:07.607452+00	2026-05-21 13:39:07.607452+00	\N	283c23e1-cc38-4c9b-85dd-3ecd554b09ae
00000000-0000-0000-0000-000000000000	547	3mr4kotycywl	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-21 14:01:12.62474+00	2026-05-21 22:22:29.417921+00	\N	b36e0ec7-3f50-4b01-9df8-dd3c4fa0c1ab
00000000-0000-0000-0000-000000000000	548	5owhxsykixnj	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-21 22:22:29.432888+00	2026-05-21 22:22:29.432888+00	3mr4kotycywl	b36e0ec7-3f50-4b01-9df8-dd3c4fa0c1ab
00000000-0000-0000-0000-000000000000	549	3ny57mwy23xn	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-21 22:22:49.404581+00	2026-05-21 22:22:49.404581+00	\N	96d35821-a260-4954-8329-7649210b0214
00000000-0000-0000-0000-000000000000	546	atlfn4osqyub	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-21 13:39:49.500999+00	2026-05-22 01:46:55.411418+00	\N	c4b8a017-9ec0-404c-922b-3faf9d1d0801
00000000-0000-0000-0000-000000000000	550	b33jwddoriku	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-22 01:46:55.433225+00	2026-05-22 01:46:55.433225+00	atlfn4osqyub	c4b8a017-9ec0-404c-922b-3faf9d1d0801
00000000-0000-0000-0000-000000000000	517	zrxxuewn4ke7	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-20 09:39:24.915289+00	2026-05-22 02:09:05.645097+00	f6h26qbjy6rd	2267c369-25de-4d41-ac5e-a2a6c1db726d
00000000-0000-0000-0000-000000000000	552	mu2q7bvb67f5	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-22 02:12:01.668168+00	2026-05-22 02:12:01.668168+00	\N	77dafdca-349c-456e-85b7-448b181ce5eb
00000000-0000-0000-0000-000000000000	553	wehgpoubmyex	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-22 02:15:29.201117+00	2026-05-22 02:15:29.201117+00	\N	457666af-61bc-4bcb-b890-deab4753d655
00000000-0000-0000-0000-000000000000	554	kvwsoacbqn3b	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-22 02:18:01.81216+00	2026-05-22 06:31:47.13787+00	\N	1cf5af7a-4330-4772-9dc7-f1217403bee6
00000000-0000-0000-0000-000000000000	555	fjwolgx7v7zg	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-22 06:31:47.158286+00	2026-05-22 08:00:08.29137+00	kvwsoacbqn3b	1cf5af7a-4330-4772-9dc7-f1217403bee6
00000000-0000-0000-0000-000000000000	556	ss3ybtr3kvfh	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-22 07:50:45.458808+00	2026-05-22 08:48:47.090438+00	\N	bb9f3c3d-b297-4c32-98c8-f3cf3c4cc484
00000000-0000-0000-0000-000000000000	557	sdzzdrkkjm2m	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-22 08:00:08.300226+00	2026-05-22 08:58:40.170122+00	fjwolgx7v7zg	1cf5af7a-4330-4772-9dc7-f1217403bee6
00000000-0000-0000-0000-000000000000	525	presgxrbiyru	0b718cac-6cd9-494a-9076-e924f23783d0	t	2026-05-20 11:13:45.056134+00	2026-05-23 01:31:23.998329+00	\N	23fa685a-8a86-4bd6-9ace-e59d31ef4934
00000000-0000-0000-0000-000000000000	541	nf6uex2zhbuu	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	t	2026-05-21 08:45:41.215072+00	2026-05-23 08:04:46.918839+00	\N	784300a9-8a3e-4390-aa42-3065063e4d07
00000000-0000-0000-0000-000000000000	551	kf4grk5krjwh	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-22 02:09:05.650652+00	2026-05-23 08:05:29.103254+00	zrxxuewn4ke7	2267c369-25de-4d41-ac5e-a2a6c1db726d
00000000-0000-0000-0000-000000000000	543	izuostspilmj	0b718cac-6cd9-494a-9076-e924f23783d0	t	2026-05-21 09:06:22.782371+00	2026-05-24 08:14:10.2252+00	ri5t6cekcfz2	e79dd47d-76bd-4f67-9ed9-f7bedbd770a3
00000000-0000-0000-0000-000000000000	558	l2tvmbketo4v	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-22 08:48:47.095448+00	2026-05-22 08:48:47.095448+00	ss3ybtr3kvfh	bb9f3c3d-b297-4c32-98c8-f3cf3c4cc484
00000000-0000-0000-0000-000000000000	560	p5agqhiuawip	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-22 15:06:51.475599+00	2026-05-22 15:06:51.475599+00	\N	8238c927-83c9-4054-9a12-53acc1d66929
00000000-0000-0000-0000-000000000000	561	u336c3d6bzwx	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-22 15:56:39.141273+00	2026-05-22 17:04:09.518529+00	\N	02bc7fff-98c3-43ad-86ab-28925e678009
00000000-0000-0000-0000-000000000000	563	jzbg7e4r4obg	0b718cac-6cd9-494a-9076-e924f23783d0	f	2026-05-23 01:31:24.016812+00	2026-05-23 01:31:24.016812+00	presgxrbiyru	23fa685a-8a86-4bd6-9ace-e59d31ef4934
00000000-0000-0000-0000-000000000000	562	4qeidkxtm6gl	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-22 17:04:09.527664+00	2026-05-23 09:00:56.233753+00	u336c3d6bzwx	02bc7fff-98c3-43ad-86ab-28925e678009
00000000-0000-0000-0000-000000000000	566	5volbvef55m6	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-23 09:00:56.239288+00	2026-05-23 09:00:56.239288+00	4qeidkxtm6gl	02bc7fff-98c3-43ad-86ab-28925e678009
00000000-0000-0000-0000-000000000000	564	j4k4yy2gjgxy	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	t	2026-05-23 08:04:46.93291+00	2026-05-23 09:03:02.155705+00	nf6uex2zhbuu	784300a9-8a3e-4390-aa42-3065063e4d07
00000000-0000-0000-0000-000000000000	565	zluy5mcjin5n	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-23 08:05:29.108749+00	2026-05-23 09:19:39.698292+00	kf4grk5krjwh	2267c369-25de-4d41-ac5e-a2a6c1db726d
00000000-0000-0000-0000-000000000000	559	qseap6dnzj6i	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-22 08:58:40.176829+00	2026-05-23 10:08:05.066004+00	sdzzdrkkjm2m	1cf5af7a-4330-4772-9dc7-f1217403bee6
00000000-0000-0000-0000-000000000000	570	o75sgremalca	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-23 10:47:48.405846+00	2026-05-23 10:47:48.405846+00	\N	975c401c-8e8d-4a1a-9879-c69722702e0d
00000000-0000-0000-0000-000000000000	572	xe42vuoc6ay2	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-23 11:11:53.850423+00	2026-05-23 11:11:53.850423+00	\N	fd8f66da-70d6-4b14-8746-c4341d602dca
00000000-0000-0000-0000-000000000000	573	de4kwn3n6ta2	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-23 11:13:20.561873+00	2026-05-23 11:13:20.561873+00	\N	f3fa874b-4e67-4a59-bf93-a8894c56dc21
00000000-0000-0000-0000-000000000000	569	mtcvtmrxeu3j	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-23 10:08:05.072483+00	2026-05-24 05:49:10.392348+00	qseap6dnzj6i	1cf5af7a-4330-4772-9dc7-f1217403bee6
00000000-0000-0000-0000-000000000000	571	vxkogs6ermpx	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-23 11:11:22.67084+00	2026-05-24 06:08:08.691329+00	\N	52f853d9-9eab-4876-b6b0-43b6e1c7880e
00000000-0000-0000-0000-000000000000	578	mpbyszdbpzaq	0b718cac-6cd9-494a-9076-e924f23783d0	f	2026-05-24 08:14:17.150054+00	2026-05-24 08:14:17.150054+00	\N	9131093e-a99e-44fe-a072-0894450b6fbc
00000000-0000-0000-0000-000000000000	579	pksyidbel46e	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-24 08:36:52.6059+00	2026-05-24 08:36:52.6059+00	\N	a15943b5-992b-4578-8ee9-e1e2c7ee156e
00000000-0000-0000-0000-000000000000	568	ygcvqptzaduq	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-23 09:19:39.704216+00	2026-05-24 08:47:05.689488+00	zluy5mcjin5n	2267c369-25de-4d41-ac5e-a2a6c1db726d
00000000-0000-0000-0000-000000000000	582	huq5ehx6woqp	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-24 09:06:33.543134+00	2026-05-24 09:06:33.543134+00	\N	931f3634-9901-4777-b724-c3df2dd671bc
00000000-0000-0000-0000-000000000000	583	llntrhsguqlt	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-24 09:08:39.654945+00	2026-05-24 09:08:39.654945+00	\N	48d564af-f6fe-4061-81c9-c6a61ad16e01
00000000-0000-0000-0000-000000000000	577	tznch2i2f3ha	0b718cac-6cd9-494a-9076-e924f23783d0	t	2026-05-24 08:14:10.24535+00	2026-05-24 09:39:27.316221+00	izuostspilmj	e79dd47d-76bd-4f67-9ed9-f7bedbd770a3
00000000-0000-0000-0000-000000000000	584	uew62may35us	0b718cac-6cd9-494a-9076-e924f23783d0	f	2026-05-24 09:39:27.321845+00	2026-05-24 09:39:27.321845+00	tznch2i2f3ha	e79dd47d-76bd-4f67-9ed9-f7bedbd770a3
00000000-0000-0000-0000-000000000000	585	kyem4unoj3n6	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-05-24 09:57:07.181673+00	2026-05-24 09:57:07.181673+00	\N	b74e8776-ad72-49c7-aa44-18dacaedf981
00000000-0000-0000-0000-000000000000	575	nh7ceuhwafot	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-24 05:49:10.403131+00	2026-05-25 01:30:12.251+00	mtcvtmrxeu3j	1cf5af7a-4330-4772-9dc7-f1217403bee6
00000000-0000-0000-0000-000000000000	586	gzo4srrsgpfz	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-25 01:30:12.27447+00	2026-05-25 03:03:00.432429+00	nh7ceuhwafot	1cf5af7a-4330-4772-9dc7-f1217403bee6
00000000-0000-0000-0000-000000000000	580	xlhdp2bm7aae	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-24 08:47:05.69816+00	2026-05-25 03:46:37.358084+00	ygcvqptzaduq	2267c369-25de-4d41-ac5e-a2a6c1db726d
00000000-0000-0000-0000-000000000000	587	l3voh7di3guo	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-25 03:03:00.439066+00	2026-05-25 12:49:51.325021+00	gzo4srrsgpfz	1cf5af7a-4330-4772-9dc7-f1217403bee6
00000000-0000-0000-0000-000000000000	589	pcbhbsl3dc42	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-25 12:49:51.345022+00	2026-05-25 14:11:13.814599+00	l3voh7di3guo	1cf5af7a-4330-4772-9dc7-f1217403bee6
00000000-0000-0000-0000-000000000000	574	ghkgcnoma3xx	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	t	2026-05-23 12:38:36.066706+00	2026-05-26 03:25:02.942862+00	\N	e71b1cde-0aa7-49dc-98f1-d3aac63eec8e
00000000-0000-0000-0000-000000000000	591	cxvtezyqlpuu	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-26 03:25:02.96794+00	2026-05-26 03:25:02.96794+00	ghkgcnoma3xx	e71b1cde-0aa7-49dc-98f1-d3aac63eec8e
00000000-0000-0000-0000-000000000000	592	btsebgevadbi	99321c1d-2254-4bbe-a5df-d14e52829a39	f	2026-05-27 08:37:28.949518+00	2026-05-27 08:37:28.949518+00	\N	8b4d20e2-3163-4cfd-a003-cdb5ce4f1338
00000000-0000-0000-0000-000000000000	590	ckif55xfgf73	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-25 14:11:13.828581+00	2026-05-28 03:33:06.043758+00	pcbhbsl3dc42	1cf5af7a-4330-4772-9dc7-f1217403bee6
00000000-0000-0000-0000-000000000000	588	n5x5g5q2363p	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-25 03:46:37.364596+00	2026-05-28 03:38:09.217434+00	xlhdp2bm7aae	2267c369-25de-4d41-ac5e-a2a6c1db726d
00000000-0000-0000-0000-000000000000	593	5rsqjyig3dr2	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-28 03:33:06.069289+00	2026-05-29 13:19:15.251406+00	ckif55xfgf73	1cf5af7a-4330-4772-9dc7-f1217403bee6
00000000-0000-0000-0000-000000000000	576	s67zezkmea3m	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-24 06:08:08.698919+00	2026-05-30 01:11:11.841714+00	vxkogs6ermpx	52f853d9-9eab-4876-b6b0-43b6e1c7880e
00000000-0000-0000-0000-000000000000	595	th6rgeee37y3	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-29 13:19:15.26217+00	2026-05-30 09:11:27.439937+00	5rsqjyig3dr2	1cf5af7a-4330-4772-9dc7-f1217403bee6
00000000-0000-0000-0000-000000000000	597	m4qisdkjjwzk	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-30 09:11:27.829279+00	2026-05-30 11:00:20.453751+00	\N	c835c00e-cb33-4e73-9bc0-fe568684a28f
00000000-0000-0000-0000-000000000000	581	2ctsr4q4hcmr	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	t	2026-05-24 08:48:14.828288+00	2026-05-31 00:51:11.282388+00	\N	8bab0b44-e764-4f42-b2d5-e318725f1734
00000000-0000-0000-0000-000000000000	567	mug4kmw36gig	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	t	2026-05-23 09:03:02.166131+00	2026-05-31 09:24:25.480913+00	j4k4yy2gjgxy	784300a9-8a3e-4390-aa42-3065063e4d07
00000000-0000-0000-0000-000000000000	600	ohmakjd2fy2r	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-05-31 09:24:25.498645+00	2026-05-31 09:24:25.498645+00	mug4kmw36gig	784300a9-8a3e-4390-aa42-3065063e4d07
00000000-0000-0000-0000-000000000000	599	c2ekrpoztuac	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	t	2026-05-31 00:51:11.293087+00	2026-05-31 09:49:39.549111+00	2ctsr4q4hcmr	8bab0b44-e764-4f42-b2d5-e318725f1734
00000000-0000-0000-0000-000000000000	598	mbporao2ncbz	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-30 11:00:20.466302+00	2026-05-31 22:17:14.017716+00	m4qisdkjjwzk	c835c00e-cb33-4e73-9bc0-fe568684a28f
00000000-0000-0000-0000-000000000000	603	oph3e6ub7evi	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-06-02 08:26:11.745645+00	2026-06-02 08:26:11.745645+00	\N	0a7cd3f3-b5ff-477c-8c9e-99708168fcec
00000000-0000-0000-0000-000000000000	604	ynuxmhkhup25	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-06-03 11:16:32.422252+00	2026-06-03 12:25:07.72184+00	\N	c2695ce5-1b4d-4470-9385-09bb30729934
00000000-0000-0000-0000-000000000000	606	ayk3l2owtfrl	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-06-03 14:07:25.702011+00	2026-06-04 01:32:06.540676+00	\N	1657630c-a6b6-4d4b-aa47-068334954bd4
00000000-0000-0000-0000-000000000000	607	zmewd26qog42	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-06-04 01:32:06.566174+00	2026-06-04 01:32:06.566174+00	ayk3l2owtfrl	1657630c-a6b6-4d4b-aa47-068334954bd4
00000000-0000-0000-0000-000000000000	605	qxdun6a5dsug	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-06-03 12:25:07.729361+00	2026-06-04 06:19:42.592845+00	ynuxmhkhup25	c2695ce5-1b4d-4470-9385-09bb30729934
00000000-0000-0000-0000-000000000000	608	orcgjot3xrrb	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-06-04 06:19:42.60823+00	2026-06-04 07:42:18.851002+00	qxdun6a5dsug	c2695ce5-1b4d-4470-9385-09bb30729934
00000000-0000-0000-0000-000000000000	602	w3ciaoli576t	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-31 22:17:14.034139+00	2026-06-05 01:35:34.961384+00	mbporao2ncbz	c835c00e-cb33-4e73-9bc0-fe568684a28f
00000000-0000-0000-0000-000000000000	596	ls5bn5llvy47	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-05-30 01:11:11.870917+00	2026-06-14 02:12:05.39146+00	s67zezkmea3m	52f853d9-9eab-4876-b6b0-43b6e1c7880e
00000000-0000-0000-0000-000000000000	601	qma45ycnl2gu	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	t	2026-05-31 09:49:39.554189+00	2026-06-17 14:50:02.279061+00	c2ekrpoztuac	8bab0b44-e764-4f42-b2d5-e318725f1734
00000000-0000-0000-0000-000000000000	594	wx37j37nqyhm	99321c1d-2254-4bbe-a5df-d14e52829a39	t	2026-05-28 03:38:09.224076+00	2026-06-21 09:33:18.915807+00	n5x5g5q2363p	2267c369-25de-4d41-ac5e-a2a6c1db726d
00000000-0000-0000-0000-000000000000	609	tiauhlkvqglx	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-06-04 07:42:18.865016+00	2026-06-04 07:42:18.865016+00	orcgjot3xrrb	c2695ce5-1b4d-4470-9385-09bb30729934
00000000-0000-0000-0000-000000000000	611	hawb5xkylfjv	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-06-06 01:59:04.740024+00	2026-06-06 01:59:04.740024+00	\N	3a3565fe-10d8-422b-8952-cde21c275df5
00000000-0000-0000-0000-000000000000	612	ul6lgyhgimbm	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-06-14 02:12:05.405598+00	2026-06-16 03:03:11.19192+00	ls5bn5llvy47	52f853d9-9eab-4876-b6b0-43b6e1c7880e
00000000-0000-0000-0000-000000000000	613	vonpffpen3ud	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-06-16 03:03:11.21778+00	2026-06-16 03:03:11.21778+00	ul6lgyhgimbm	52f853d9-9eab-4876-b6b0-43b6e1c7880e
00000000-0000-0000-0000-000000000000	615	afgqvvp6wcc7	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	f	2026-06-17 14:50:02.29607+00	2026-06-17 14:50:02.29607+00	qma45ycnl2gu	8bab0b44-e764-4f42-b2d5-e318725f1734
00000000-0000-0000-0000-000000000000	610	taawqvztrovj	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-06-05 01:35:34.974033+00	2026-06-18 03:33:07.847688+00	w3ciaoli576t	c835c00e-cb33-4e73-9bc0-fe568684a28f
00000000-0000-0000-0000-000000000000	616	hc5kqnl65dbb	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-06-18 03:33:07.879831+00	2026-06-18 03:33:07.879831+00	taawqvztrovj	c835c00e-cb33-4e73-9bc0-fe568684a28f
00000000-0000-0000-0000-000000000000	614	p5pqcc5ek2ya	a670a3d7-db76-4536-ad05-13c3ee563069	t	2026-06-16 10:18:23.690549+00	2026-06-18 06:32:55.719421+00	\N	cd501d74-ce02-4630-8f9d-1b95177b998b
00000000-0000-0000-0000-000000000000	617	ckphy52l2i7m	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-06-18 06:32:55.736575+00	2026-06-18 06:32:55.736575+00	p5pqcc5ek2ya	cd501d74-ce02-4630-8f9d-1b95177b998b
00000000-0000-0000-0000-000000000000	618	m3ut7qyo3ton	a670a3d7-db76-4536-ad05-13c3ee563069	f	2026-06-19 03:03:05.616867+00	2026-06-19 03:03:05.616867+00	\N	7a740360-2e6d-42ad-b659-ca3312d3684d
00000000-0000-0000-0000-000000000000	619	qa2ia7ddw62g	99321c1d-2254-4bbe-a5df-d14e52829a39	f	2026-06-21 09:33:29.547608+00	2026-06-21 09:33:29.547608+00	\N	3c2db4f4-ed7d-430b-9274-ef08068b5efe
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."schema_migrations" ("version") FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
33b7d1ab-6afa-4e78-8054-9f10d6785317	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:21:33.201309+00	2026-05-02 04:21:33.201309+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
fe48fec9-e8ab-45bf-9784-95306b918f50	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:21:33.464916+00	2026-05-02 04:21:33.464916+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
d80eeef9-7f60-430e-aa92-7338c610945f	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:21:46.067852+00	2026-05-02 04:21:46.067852+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
45754a10-35ca-4df9-b875-d663f5bd909c	964af5e8-7c20-40b1-b6ff-3a448dfc265a	2026-05-02 04:23:38.023203+00	2026-05-02 04:23:38.023203+00	\N	aal1	\N	\N	node	34.34.254.48	\N	\N	\N	\N	\N
57a1e782-c07e-4939-8c69-91b13f802291	964af5e8-7c20-40b1-b6ff-3a448dfc265a	2026-05-02 04:23:38.13862+00	2026-05-02 04:23:38.13862+00	\N	aal1	\N	\N	node	34.34.254.48	\N	\N	\N	\N	\N
b3307f87-98fe-4dad-89ce-8601e272788a	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:24:03.425858+00	2026-05-02 04:24:03.425858+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
804d6c6c-ca99-41d3-990d-6bfd4ffad049	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-02 04:28:31.282412+00	2026-05-02 04:28:31.282412+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
cf9830e4-6181-47ea-81e9-d5a240f1b268	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-02 04:28:31.485292+00	2026-05-02 04:28:31.485292+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
a92d68db-1b89-4e69-aa57-ba5bf6fc7f31	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:40:47.123696+00	2026-05-02 04:40:47.123696+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
96eeb8b7-fcc0-4f65-9a07-c3faef5de35a	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:40:51.342472+00	2026-05-02 04:40:51.342472+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
e1580ec9-13cb-4eba-824d-3309cd46673f	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:40:55.814596+00	2026-05-02 04:40:55.814596+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
06ac7d91-24e8-432a-8035-9dbc6b58eea2	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:40:59.171304+00	2026-05-02 04:40:59.171304+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
b67d3dd7-de96-4d3e-ac0d-0dd2f7719857	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:41:02.424168+00	2026-05-02 04:41:02.424168+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
392d861d-3204-432f-bb0e-2056b90df667	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:41:05.930705+00	2026-05-02 04:41:05.930705+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
026083a6-1d23-410b-96d4-8597b44e1b61	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:41:13.935768+00	2026-05-02 04:41:13.935768+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
88de18de-51fc-44d8-b4be-589d24024016	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:58:20.180642+00	2026-05-02 04:58:20.180642+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	14.245.49.14	\N	\N	\N	\N	\N
821e4a8e-f196-4463-8955-3143be845fa2	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-02 04:34:40.322731+00	2026-05-02 05:53:40.516246+00	\N	aal1	\N	2026-05-02 05:53:40.516126	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
06f81853-71c5-41a3-a9ef-fd26babaee86	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-02 05:53:44.318038+00	2026-05-02 05:53:44.318038+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
cc270bd5-e464-4abf-ad82-45f365a5ce65	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-02 05:53:49.877904+00	2026-05-02 05:53:49.877904+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
b6bb26ff-1681-4569-9860-b60c2bb4cd1b	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:42:27.589421+00	2026-05-02 05:54:41.811476+00	\N	aal1	\N	2026-05-02 05:54:41.811359	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
dc79cde6-2e0f-469f-8b84-34a0d28f9b31	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 05:55:01.456429+00	2026-05-02 05:55:01.456429+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
754e992e-fa7b-408d-897a-282c738fa033	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 05:55:09.528871+00	2026-05-02 05:55:09.528871+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
c49a3657-35a0-4a1c-909b-4d96ed90d760	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 05:55:26.0154+00	2026-05-02 05:55:26.0154+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
96a31004-fc0c-4089-9b23-5157395e0ada	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 05:57:21.76513+00	2026-05-02 05:57:21.76513+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
705862d9-316f-44cd-9b78-894aeb5849e8	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 05:57:23.587955+00	2026-05-02 05:57:23.587955+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
e5e90106-5c37-4cac-b92e-04f516686b91	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 05:57:26.426279+00	2026-05-02 05:57:26.426279+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
53e3d7bf-bb34-4163-ba07-88c033a433eb	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 05:57:39.371866+00	2026-05-02 05:57:39.371866+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
5e277aad-a35f-4e3e-9e48-4c6a22e87211	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 05:58:15.007441+00	2026-05-02 05:58:15.007441+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36	27.2.201.4	\N	\N	\N	\N	\N
3c15d471-3d8f-44a1-aa25-1ed0df78014d	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 06:00:03.483576+00	2026-05-02 06:00:03.483576+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	113.171.245.7	\N	\N	\N	\N	\N
bd699fce-89d6-4ece-8206-8d0014a68d35	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-02 06:37:21.792592+00	2026-05-02 06:37:21.792592+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
f78530e3-fde5-41ae-9447-d7ad678cfe6d	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-02 06:37:24.182367+00	2026-05-02 06:37:24.182367+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
ad8c3800-408e-4cef-a792-6f7e52d6c934	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-02 06:37:26.412402+00	2026-05-02 06:37:26.412402+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
d6eb78ec-5c35-4d7e-88e4-2263e73d778f	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-02 06:37:59.627985+00	2026-05-02 06:37:59.627985+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
c3153f94-b511-4422-8b04-8dcb9af1a41e	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-02 06:38:02.016577+00	2026-05-02 06:38:02.016577+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
e2d9a855-e6be-4c0d-8288-639a122b6f3e	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-02 06:38:05.473827+00	2026-05-02 06:38:05.473827+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
7677b361-1287-4171-838b-fcaeef3064fc	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:45:45.462828+00	2026-05-02 06:55:12.489092+00	\N	aal1	\N	2026-05-02 06:55:12.488972	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.120.15	\N	\N	\N	\N	\N
1c8aaf7a-e986-442a-a4f1-cd23f00965e7	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:58:38.547477+00	2026-05-04 09:37:40.759131+00	\N	aal1	\N	2026-05-04 09:37:40.759008	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	14.185.217.207	\N	\N	\N	\N	\N
28a05a6c-f93c-4ae7-a2fe-515a017b22b2	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-02 04:33:51.177746+00	2026-05-05 09:39:52.710925+00	\N	aal1	\N	2026-05-05 09:39:52.710837	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
466e6a53-e33d-48f9-95ae-f09fb3b3115a	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 04:23:29.578748+00	2026-05-02 06:38:11.346543+00	\N	aal1	\N	2026-05-02 06:38:11.346459	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
bdc32057-66ff-41a6-93a9-940be1bc0d09	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 06:38:14.413307+00	2026-05-02 06:38:14.413307+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
514591f8-e3de-4fa7-9d7f-eb7aca8583af	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 06:39:16.036548+00	2026-05-02 06:39:16.036548+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
e6f1f035-a515-4098-be59-6d15e041e217	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 06:55:13.582314+00	2026-05-02 06:55:13.582314+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.120.15	\N	\N	\N	\N	\N
d0894bda-d535-449f-bf40-8de4aaddbf1c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 06:56:18.861467+00	2026-05-02 08:52:49.737561+00	\N	aal1	\N	2026-05-02 08:52:49.737444	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.120.15	\N	\N	\N	\N	\N
a84a833c-a2b5-44f4-8c2a-a399a379d936	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 08:52:50.759187+00	2026-05-02 08:52:50.759187+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.120.15	\N	\N	\N	\N	\N
2e9522de-c53c-4553-9fb4-83d3b84dee12	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 08:53:44.262227+00	2026-05-02 08:53:44.262227+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.120.15	\N	\N	\N	\N	\N
650b000f-04ff-4b36-b79f-b3132ea261e6	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 09:00:08.81739+00	2026-05-02 09:00:08.81739+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.120.15	\N	\N	\N	\N	\N
c4c78cf4-2454-4f6b-9521-a25cdb1a6372	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 09:00:20.089795+00	2026-05-02 09:00:20.089795+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.120.15	\N	\N	\N	\N	\N
0aec5984-ed0b-43ca-a858-b799ae654320	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 09:02:29.690493+00	2026-05-02 09:02:29.690493+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.120.15	\N	\N	\N	\N	\N
88064374-0038-4f87-9c89-33b03b2c6ebb	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 12:19:36.190785+00	2026-05-02 12:19:36.190785+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.133.183	\N	\N	\N	\N	\N
56f40644-a46e-4b9d-bc70-9aaaeccdb16d	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 12:19:37.123934+00	2026-05-02 12:19:37.123934+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.133.183	\N	\N	\N	\N	\N
21c543e6-45e1-421c-a020-9452576cc618	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 12:20:41.53154+00	2026-05-02 12:20:41.53154+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 15; 23129RAA4G Build/AQ3A.240829.003;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.111 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/dark ZaloLanguage/vi	171.255.133.183	\N	\N	\N	\N	\N
382e79a5-86cc-48ce-9330-bb3af3120d37	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 09:03:06.086903+00	2026-05-02 15:16:13.01847+00	\N	aal1	\N	2026-05-02 15:16:13.018362	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.176.160	\N	\N	\N	\N	\N
0d3579c1-e372-4e2b-bb02-69db33b9bc26	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 15:16:13.89432+00	2026-05-03 01:56:29.788456+00	\N	aal1	\N	2026-05-03 01:56:29.788336	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.143.131	\N	\N	\N	\N	\N
9ff2d49a-0569-4ccd-8a2a-07613b12a4cc	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 01:56:30.797483+00	2026-05-03 01:56:30.797483+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.143.131	\N	\N	\N	\N	\N
d78cba54-dfa1-45d7-9b3c-93bed98faf41	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 02:47:02.831848+00	2026-05-03 02:47:02.831848+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.143.131	\N	\N	\N	\N	\N
3f72b81d-e0bf-4670-a270-a11e881e5a4b	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 02:47:14.184401+00	2026-05-03 04:01:20.704244+00	\N	aal1	\N	2026-05-03 04:01:20.70411	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.143.131	\N	\N	\N	\N	\N
23b7c766-3cb4-4a2c-9f25-dc5b8fd3e2a7	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 18:44:40.71897+00	2026-05-03 04:39:12.446231+00	\N	aal1	\N	2026-05-03 04:39:12.44609	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.3 Mobile/15E148 Safari/604.1	171.244.212.86	\N	\N	\N	\N	\N
6a7349b7-75e7-4c97-83fd-9d17fbb07ffc	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 04:01:21.809738+00	2026-05-03 05:23:37.538219+00	\N	aal1	\N	2026-05-03 05:23:37.5381	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.143.131	\N	\N	\N	\N	\N
a52311de-cdd2-4a89-84ae-8eedf990bbda	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 05:23:38.370565+00	2026-05-03 05:23:38.370565+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.143.131	\N	\N	\N	\N	\N
ad9840ec-a4da-4fa8-a435-76bbecd7797f	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 05:23:52.013302+00	2026-05-03 05:23:52.013302+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.143.131	\N	\N	\N	\N	\N
b9321a65-c87f-4f04-b85a-dff2e11a17f0	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 05:24:06.512169+00	2026-05-03 05:24:06.512169+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.143.131	\N	\N	\N	\N	\N
d4805735-6eb4-4564-8cd3-83a83d78161f	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 07:29:39.153886+00	2026-05-03 07:29:39.153886+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
9ee81a2d-a12f-4aed-a93b-1f433fcefa1e	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 07:29:57.270207+00	2026-05-03 07:29:57.270207+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36	112.197.12.71	\N	\N	\N	\N	\N
c0090a18-ab2b-4241-8232-6b35d64d2331	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 07:31:22.211675+00	2026-05-03 07:31:22.211675+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
768d1a95-0656-47b9-a287-de7cf7527a9f	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 07:31:45.512888+00	2026-05-03 07:31:45.512888+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.226.108.132	\N	\N	\N	\N	\N
b3768cfd-d804-4614-8e89-3f8706254c0c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 07:56:39.246388+00	2026-05-03 07:56:39.246388+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.4 Mobile/15E148 Safari/604.1	14.185.223.138	\N	\N	\N	\N	\N
56526efc-a07a-478d-8d21-c8b6daf81614	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 07:58:57.587832+00	2026-05-03 07:58:57.587832+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/708 ZaloTheme/light ZaloLanguage/vn	14.185.223.138	\N	\N	\N	\N	\N
247d96af-6468-451c-a0f4-bb7f60f1602c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 07:59:40.712992+00	2026-05-03 07:59:40.712992+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.4 Mobile/15E148 Safari/604.1	14.185.223.138	\N	\N	\N	\N	\N
b715b6bc-65aa-4eae-8152-45c4662c8810	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 05:32:28.52114+00	2026-05-03 10:27:07.097239+00	\N	aal1	\N	2026-05-03 10:27:07.097123	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.143.131	\N	\N	\N	\N	\N
d74905c3-fec3-4820-b20d-e1349512c6ed	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 04:39:13.237946+00	2026-05-03 13:22:17.574118+00	\N	aal1	\N	2026-05-03 13:22:17.573999	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.3 Mobile/15E148 Safari/604.1	113.162.109.202	\N	\N	\N	\N	\N
6034532e-5aaa-4e9e-aadd-41781795e7f3	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 09:10:46.702716+00	2026-05-03 22:00:58.266577+00	\N	aal1	\N	2026-05-03 22:00:58.266487	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
36386704-5e12-48a3-b786-724e0cc4af2c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 09:59:10.169802+00	2026-05-06 11:54:46.092151+00	\N	aal1	\N	2026-05-06 11:54:46.092033	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	171.251.238.116	\N	\N	\N	\N	\N
7a277f46-870b-4b87-b4e4-f675fa56ee59	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 11:13:58.769381+00	2026-05-03 11:13:58.769381+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	171.251.238.98	\N	\N	\N	\N	\N
4cae1f82-8a7b-47d8-b29c-5c5b2c8ed74b	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 11:52:38.357367+00	2026-05-03 11:52:38.357367+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 [FBAN/FBIOS;FBAV/559.0.0.40.105;FBBV/955589806;FBDV/iPhone12,1;FBMD/iPhone;FBSN/iOS;FBSV/18.2;FBSS/2;FBCR/;FBID/phone;FBLC/vi_VN;FBOP/80]	42.1.85.55	\N	\N	\N	\N	\N
561e4790-29c5-4a5d-80a8-120e433316d9	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 11:54:34.335575+00	2026-05-03 11:54:34.335575+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 16_7_15 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/260402802 ZaloTheme/light ZaloLanguage/vn	171.251.239.187	\N	\N	\N	\N	\N
2cce2503-5db3-4118-8a57-57002c6c48f5	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 13:13:34.596162+00	2026-05-03 13:13:34.596162+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.251.239.184	\N	\N	\N	\N	\N
ebf24002-4d07-43ad-b133-359f38413558	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 10:27:08.231875+00	2026-05-03 13:16:25.94364+00	\N	aal1	\N	2026-05-03 13:16:25.943533	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
e85d209a-b9ad-48b1-872b-99f0bca62010	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 13:16:26.624874+00	2026-05-03 13:16:26.624874+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
7fa38bed-e54f-4e21-8cce-170b243f8176	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 14:36:10.267325+00	2026-05-03 14:36:10.267325+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.5 Mobile/15E148 Safari/604.1	171.251.239.152	\N	\N	\N	\N	\N
736b82b5-2088-4768-9db5-1d8eda930207	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 14:41:01.556749+00	2026-05-03 14:41:01.556749+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.251.239.152	\N	\N	\N	\N	\N
ddfa30f6-58ea-4e9d-a093-67527e6ff780	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-02 12:23:13.634025+00	2026-05-03 15:59:16.42777+00	\N	aal1	\N	2026-05-03 15:59:16.427666	Mozilla/5.0 (Linux; Android 15; 23129RAA4G Build/AQ3A.240829.003;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.111 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/dark ZaloLanguage/vi	171.251.238.26	\N	\N	\N	\N	\N
022cd7fd-2ec7-4ac3-a757-19426e25751f	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 21:59:26.390702+00	2026-05-03 21:59:26.390702+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
b41fdbac-f7bd-4f02-bdc8-1ed1b3618154	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 21:59:26.609499+00	2026-05-03 21:59:26.609499+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
780646ad-33f4-4a25-a2a9-a031228410b1	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 21:59:44.618297+00	2026-05-03 21:59:44.618297+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	112.197.13.68	\N	\N	\N	\N	\N
6d3855ed-1ae2-4518-b7ee-094074e817d8	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:00:19.366344+00	2026-05-03 22:00:19.366344+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
792ee504-7c04-4eb4-82c7-21b0e9a203fd	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:01:46.276594+00	2026-05-03 22:01:46.276594+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
f8286ee6-c5ce-4d82-b3f9-29a0be4001fb	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:02:23.766314+00	2026-05-03 22:02:23.766314+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
b78e2a4c-3b59-4244-94d3-cc3e2b06c5d4	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:02:28.529362+00	2026-05-03 22:02:28.529362+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
1cd4ba68-d656-43e6-9e30-2239b47592ee	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:02:33.406977+00	2026-05-03 22:02:33.406977+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
08814b95-d98f-4cf5-9a81-a315ff7e8bd5	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:02:49.440873+00	2026-05-03 22:02:49.440873+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
626a55b8-0ca2-4e39-b766-d07386f7b714	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:03:26.679145+00	2026-05-03 22:03:26.679145+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
9ac05af9-ad69-4376-bb18-dbead4e76184	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:03:31.42898+00	2026-05-03 22:03:31.42898+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
bb2bf0d4-cc91-4375-b5af-26bcd39c3379	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:04:11.861006+00	2026-05-03 22:04:11.861006+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
923e429d-a30b-4418-87d6-9098640cb4cc	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:07:20.030482+00	2026-05-03 22:07:20.030482+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
5ead0212-844b-4856-adb6-4cc0958c5ff1	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:07:37.305067+00	2026-05-03 22:07:37.305067+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
9b1cb33b-bf9e-4668-9bff-8d67256854d0	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:07:56.051883+00	2026-05-03 22:07:56.051883+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
1af02e38-a092-4598-94d8-524b3f66d341	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:08:12.693112+00	2026-05-03 22:08:12.693112+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
cb73a2ef-d2c6-48fb-aad5-48b8400fe70e	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:08:25.398564+00	2026-05-03 22:08:25.398564+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
b203a927-4a6a-4278-aaf9-98ab8a5d6a5c	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:08:34.99774+00	2026-05-03 22:08:34.99774+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
c2b0cead-50e1-40b2-aeca-b1a29ed75868	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:09:00.462406+00	2026-05-03 22:09:00.462406+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
5b2678ca-9731-4ebc-aadf-45023ecb4158	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:12:19.059442+00	2026-05-03 22:12:19.059442+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
742aefac-0409-46bd-b62b-86b1c289997e	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 15:59:17.307046+00	2026-05-04 00:56:00.817199+00	\N	aal1	\N	2026-05-04 00:56:00.817084	Mozilla/5.0 (Linux; Android 15; 23129RAA4G Build/AQ3A.240829.003;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.111 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/dark ZaloLanguage/vi	116.110.227.97	\N	\N	\N	\N	\N
d2f43092-dd37-45cd-8216-e3b3d4c54888	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 22:00:58.73937+00	2026-05-04 01:27:18.664681+00	\N	aal1	\N	2026-05-04 01:27:18.664561	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
5ce13903-ac1b-47fb-aab1-028b1e8ca7c5	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 14:26:26.939034+00	2026-05-04 12:08:39.424935+00	\N	aal1	\N	2026-05-04 12:08:39.424822	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1	123.26.124.186	\N	\N	\N	\N	\N
ccc9e3bb-b175-465c-97a5-99bd17654f8f	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 11:56:01.730398+00	2026-05-04 22:59:08.826186+00	\N	aal1	\N	2026-05-04 22:59:08.826072	Mozilla/5.0 (iPhone; CPU iPhone OS 16_7_15 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/260402802 ZaloTheme/light ZaloLanguage/vn	27.67.75.35	\N	\N	\N	\N	\N
537ddd17-cb00-4948-a643-c30f4e51befb	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 13:22:18.811194+00	2026-05-05 15:25:19.952292+00	\N	aal1	\N	2026-05-05 15:25:19.952094	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.3 Mobile/15E148 Safari/604.1	14.245.55.90	\N	\N	\N	\N	\N
47576508-f0b5-4200-9159-4cb5ca7a2d0e	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:12:40.522975+00	2026-05-03 22:12:40.522975+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
4229f572-9f64-4c02-88f0-f44489af96a7	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:13:04.864955+00	2026-05-03 22:13:04.864955+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
0fd134a3-c414-4f98-98d4-46bb2f36961c	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:13:11.95616+00	2026-05-03 22:13:11.95616+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
7df728e3-6131-4355-9671-2393c55818ea	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:13:17.16691+00	2026-05-03 22:13:17.16691+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
c13af329-b9a5-469d-b414-e30846f97a76	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:13:20.28632+00	2026-05-03 22:13:20.28632+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
379fa945-8e84-41fd-9538-e1b44f180a44	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:13:24.097093+00	2026-05-03 22:13:24.097093+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
3de0434e-c832-4ecb-b6ff-d61acd0fd8c0	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:16:01.850645+00	2026-05-03 22:16:01.850645+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
8f7cef5c-cde4-4648-a32d-acb6abe3df5d	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:16:50.846987+00	2026-05-03 22:16:50.846987+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
fcc8d616-9e96-4cd5-bd27-13e38b0a4022	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:55:34.217707+00	2026-05-03 22:55:34.217707+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.111 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/light ZaloLanguage/vi	171.254.130.116	\N	\N	\N	\N	\N
0cebdc4f-0f13-4a4a-9c63-428e8eec2907	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 23:00:28.821273+00	2026-05-03 23:00:28.821273+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
bc10560b-e57f-4ac5-a305-c182f7a9a115	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 23:01:22.032087+00	2026-05-03 23:01:22.032087+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
e633cdf3-eb03-4599-8582-ab3392b66e94	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 23:01:29.586873+00	2026-05-03 23:01:29.586873+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
1f96eb1f-911d-4904-ae06-1fe125ec6767	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 13:16:31.508002+00	2026-05-03 23:02:41.017848+00	\N	aal1	\N	2026-05-03 23:02:41.017741	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
8d7355e6-a022-4420-8e3e-8eb16655824e	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 23:59:59.619441+00	2026-05-03 23:59:59.619441+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
831ade6e-9235-4b82-ace7-3131601855e8	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 00:00:06.307303+00	2026-05-04 00:00:06.307303+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	123.19.71.119	\N	\N	\N	\N	\N
b79c7b8e-ebf8-477f-9caf-1270504e7c2a	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-03 23:02:49.276238+00	2026-05-04 00:05:58.574891+00	\N	aal1	\N	2026-05-04 00:05:58.574772	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
2fcf52d4-0cb8-47dd-b03b-cb2220f8fb37	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 00:17:57.252643+00	2026-05-04 00:17:57.252643+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	113.185.109.154	\N	\N	\N	\N	\N
41a740ad-869b-41d1-9f3e-357c7b2781cc	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:23:25.285125+00	2026-05-04 00:52:14.721504+00	\N	aal1	\N	2026-05-04 00:52:14.721388	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
23d59a86-9247-4898-8047-3804c31c1e05	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 00:56:01.995123+00	2026-05-04 00:56:01.995123+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 15; 23129RAA4G Build/AQ3A.240829.003;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.111 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/dark ZaloLanguage/vi	116.110.227.97	\N	\N	\N	\N	\N
ab0bb280-ecc9-419f-803b-d805c78081fa	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 02:07:03.774479+00	2026-05-04 02:07:03.774479+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	14.167.128.164	\N	\N	\N	\N	\N
5e135e1a-3a5a-4cbe-895a-b1a0eb391547	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-04 01:20:38.979907+00	2026-05-04 07:02:21.277959+00	\N	aal1	\N	2026-05-04 07:02:21.277852	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
bb66c957-0f8b-4e6c-a415-d2dcc5834d44	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 00:04:31.99004+00	2026-05-04 23:53:26.737526+00	\N	aal1	\N	2026-05-04 23:53:26.737411	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	42.1.107.167	\N	\N	\N	\N	\N
cd941f5c-3252-48a7-988a-0a3146fd740b	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 02:32:25.706557+00	2026-05-04 02:32:25.706557+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1	104.28.163.27	\N	\N	\N	\N	\N
f12cb778-ad5b-4be4-a29e-b85813586f7a	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 02:40:01.915928+00	2026-05-04 02:40:01.915928+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/260402802 ZaloTheme/light ZaloLanguage/vn	171.251.238.98	\N	\N	\N	\N	\N
8fef52f0-97ea-46ec-905e-2c973b458cec	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 03:39:05.352226+00	2026-05-04 03:39:05.352226+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0	171.251.238.34	\N	\N	\N	\N	\N
c8c88c22-cce2-4579-a097-b2304a209b9e	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 01:27:22.526996+00	2026-05-04 09:42:31.339722+00	\N	aal1	\N	2026-05-04 09:42:31.336314	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
e852b441-c39d-4f92-b90c-9a8a107022a6	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 01:03:33.071448+00	2026-05-04 17:21:18.021353+00	\N	aal1	\N	2026-05-04 17:21:18.021215	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	42.1.88.192	\N	\N	\N	\N	\N
29317481-fe82-4e3c-8ee9-6f715d883ef3	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 01:03:46.289167+00	2026-05-04 17:21:27.310873+00	\N	aal1	\N	2026-05-04 17:21:27.310774	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	42.1.88.192	\N	\N	\N	\N	\N
18c7adf2-4889-44d9-a8ac-78ac6e4b2814	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-04 07:32:54.819434+00	2026-05-05 05:29:51.185058+00	\N	aal1	\N	2026-05-05 05:29:51.184952	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
10cb3316-ab6d-4fc6-b596-e9613d3a6d46	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 00:05:59.369722+00	2026-05-05 09:52:05.082774+00	\N	aal1	\N	2026-05-05 09:52:05.082661	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
c4a790ae-b218-4496-9d77-a507dc6cb04c	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-04 00:00:12.761807+00	2026-05-05 11:16:50.710804+00	\N	aal1	\N	2026-05-05 11:16:50.71071	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
b5855e91-6a0b-4ac5-a5f7-2ef3e8c74a68	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 02:08:05.490478+00	2026-05-06 11:04:40.294412+00	\N	aal1	\N	2026-05-06 11:04:40.294296	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/260402802 ZaloTheme/light ZaloLanguage/vn	113.166.114.75	\N	\N	\N	\N	\N
b01a92b3-3e87-4abf-b47a-33ab1e635878	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 23:00:15.84824+00	2026-05-07 04:22:11.561497+00	\N	aal1	\N	2026-05-07 04:22:11.561323	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
f9134f67-ae73-4392-918c-ab90ead4c86c	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-05 01:13:28.249632+00	2026-05-05 01:13:28.249632+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	117.3.142.59	\N	\N	\N	\N	\N
84cf9fcb-bd20-460e-bbb7-3d892d0c3a1c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 09:37:41.717808+00	2026-05-04 09:37:41.717808+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	14.185.217.207	\N	\N	\N	\N	\N
c42ba9ff-32f4-4266-bc13-fa88c4c0615b	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-04 07:31:44.412081+00	2026-05-04 09:42:33.073083+00	\N	aal1	\N	2026-05-04 09:42:33.072989	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
b10743eb-1bbd-4db7-9987-582a0a1ffa6d	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 14:16:09.636328+00	2026-05-04 14:16:09.636328+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 15_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/260402802 ZaloTheme/light ZaloLanguage/vn	42.116.101.130	\N	\N	\N	\N	\N
36c71719-a2bb-4990-98a6-16242d2c5d7c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 14:18:03.983425+00	2026-05-04 14:18:03.983425+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 15_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/260402802 ZaloTheme/light ZaloLanguage/vn	42.116.101.130	\N	\N	\N	\N	\N
dc2f16f9-42d7-4dfb-9ea2-1357b661d5f2	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 15:23:17.087048+00	2026-05-04 15:23:17.087048+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1	14.245.51.99	\N	\N	\N	\N	\N
d9aafebd-ec9a-4ad9-9a8d-5a953fe27aed	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 16:10:21.364047+00	2026-05-04 16:10:21.364047+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1	14.245.51.99	\N	\N	\N	\N	\N
3e3cf196-c0b0-4aa0-92d6-005722817aa4	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 09:21:46.178685+00	2026-05-04 16:44:48.583603+00	\N	aal1	\N	2026-05-04 16:44:48.583471	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.149.123	\N	\N	\N	\N	\N
83afb629-f15b-4b1b-b504-61faa740f181	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 17:21:18.906586+00	2026-05-04 17:21:18.906586+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	42.1.88.192	\N	\N	\N	\N	\N
32b21aee-7494-4636-99ab-3ba93cf6d61a	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 17:36:45.972541+00	2026-05-04 17:36:45.972541+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.2 Mobile/15E148 Safari/604.1	171.251.239.220	\N	\N	\N	\N	\N
f2c660b3-218f-4580-b4cc-ab3f3575bfba	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 17:37:24.075829+00	2026-05-04 17:37:24.075829+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/708 ZaloTheme/light ZaloLanguage/vn	171.251.239.220	\N	\N	\N	\N	\N
60e843bf-f5e1-440d-aca1-f57505a5ca87	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 17:38:23.531307+00	2026-05-04 17:38:23.531307+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/708 ZaloTheme/light ZaloLanguage/vn	171.251.239.220	\N	\N	\N	\N	\N
56f174b4-b753-4e53-aa4b-dc66466ecd85	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 17:38:31.123345+00	2026-05-04 17:38:31.123345+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/708 ZaloTheme/light ZaloLanguage/vn	171.251.239.220	\N	\N	\N	\N	\N
702ee476-a304-466a-b2d4-167e25ca8e1f	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 17:38:56.001535+00	2026-05-04 17:38:56.001535+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/708 ZaloTheme/light ZaloLanguage/vn	171.251.239.220	\N	\N	\N	\N	\N
db460c34-8d43-4b40-b7e3-c1fa1155843b	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 17:39:16.526017+00	2026-05-04 17:39:16.526017+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/708 ZaloTheme/light ZaloLanguage/vn	171.251.239.220	\N	\N	\N	\N	\N
2fd61c0c-8b07-4014-820d-d7461997775c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 17:40:04.253387+00	2026-05-04 17:40:04.253387+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/708 ZaloTheme/light ZaloLanguage/vn	171.251.239.220	\N	\N	\N	\N	\N
b829fbc2-ac7f-4400-b2e0-7fafa8d8a23a	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 17:40:58.725978+00	2026-05-04 17:40:58.725978+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/708 ZaloTheme/light ZaloLanguage/vn	171.251.239.220	\N	\N	\N	\N	\N
0b624b14-677c-4b59-af68-9ae7eacab824	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 18:22:16.239044+00	2026-05-04 18:22:16.239044+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/144.0.7559.95 Mobile/15E148 Safari/604.1	2.56.72.25	\N	\N	\N	\N	\N
9ab5e877-1c1f-45e9-95bc-299c35df278e	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 22:59:09.994961+00	2026-05-04 22:59:09.994961+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 16_7_15 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/260402802 ZaloTheme/light ZaloLanguage/vn	27.67.75.35	\N	\N	\N	\N	\N
1d883c9e-7522-4fef-962d-14d2b6ba2c06	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 23:53:27.465366+00	2026-05-04 23:53:27.465366+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	42.1.107.167	\N	\N	\N	\N	\N
f0b124f4-0361-46da-9f5f-aeb9ae5c0485	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 23:53:57.498357+00	2026-05-04 23:53:57.498357+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	42.1.107.167	\N	\N	\N	\N	\N
7d2e53f6-aa50-4511-b01b-1cee76b254f5	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 23:54:45.395018+00	2026-05-04 23:54:45.395018+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	42.1.107.167	\N	\N	\N	\N	\N
90b90c10-6111-42ec-9389-9b40a939a336	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 23:57:35.623501+00	2026-05-04 23:57:35.623501+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36	42.1.107.167	\N	\N	\N	\N	\N
cfb77a1f-d3f3-4097-8d6d-bf41d217d032	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 17:21:27.780069+00	2026-05-05 00:09:19.164993+00	\N	aal1	\N	2026-05-05 00:09:19.164883	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	113.185.108.246	\N	\N	\N	\N	\N
4328172b-7786-419d-af8a-594897d67a2b	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 00:09:20.194168+00	2026-05-05 00:09:20.194168+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	113.185.108.246	\N	\N	\N	\N	\N
809f7948-cf83-433e-9729-73562edcfd7d	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 12:08:40.35103+00	2026-05-05 00:13:37.947081+00	\N	aal1	\N	2026-05-05 00:13:37.946959	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1	14.236.91.204	\N	\N	\N	\N	\N
4f222a82-6691-45a2-8183-1b5b10c08068	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-05 00:44:25.229986+00	2026-05-05 00:44:25.229986+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 16; SM-A556E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.111 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/light ZaloLanguage/vi	123.19.71.119	\N	\N	\N	\N	\N
6eebc915-64ad-4ae5-846c-16c522ca6700	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 07:52:28.198978+00	2026-05-05 01:12:28.300703+00	\N	aal1	\N	2026-05-05 01:12:28.300598	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	117.3.142.59	\N	\N	\N	\N	\N
96062ea5-a33c-4f49-9d84-a49de190e469	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 01:12:29.012412+00	2026-05-05 01:12:29.012412+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	117.3.142.59	\N	\N	\N	\N	\N
97d7fa3a-1847-4e68-8e17-b84597eda1fc	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 01:14:40.989757+00	2026-05-05 01:14:40.989757+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	117.3.142.59	\N	\N	\N	\N	\N
d5b5d670-e6bc-4109-b80d-5ab30aa44c62	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 09:42:32.099546+00	2026-05-05 05:30:13.770615+00	\N	aal1	\N	2026-05-05 05:30:13.770532	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
437a42a6-bbfb-4520-ba9b-a3144a745219	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-04 16:44:49.956131+00	2026-05-05 10:03:59.216454+00	\N	aal1	\N	2026-05-05 10:03:59.214851	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.251.238.8	\N	\N	\N	\N	\N
714a10fb-95bf-4df0-9823-b91bf611988d	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 01:14:44.81674+00	2026-05-05 01:14:44.81674+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	117.3.142.59	\N	\N	\N	\N	\N
bc1d548e-88d2-41cb-8b94-7a4ee7a2f968	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 01:15:07.154289+00	2026-05-05 01:15:07.154289+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	117.3.142.59	\N	\N	\N	\N	\N
bb92ab88-d663-4927-8185-f9832e5f4ff0	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 01:15:32.547441+00	2026-05-05 01:15:32.547441+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	117.3.142.59	\N	\N	\N	\N	\N
4e01c41a-75a9-4761-acb4-d7f0b502b177	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 01:20:04.810321+00	2026-05-05 01:20:04.810321+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/144.0.7559.95 Mobile/15E148 Safari/604.1	216.170.118.176	\N	\N	\N	\N	\N
ed9c373b-f361-4d5c-92b6-e33984a3a641	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:52:30.479389+00	2026-05-05 08:52:30.479389+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
451979bd-fcab-4e8e-9cec-dc5fafa65aa0	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 04:14:37.61604+00	2026-05-05 04:14:37.61604+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1	171.251.239.211	\N	\N	\N	\N	\N
e8b716fd-1ada-449c-ab5f-63881e9b5da8	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 00:13:39.167682+00	2026-05-05 05:07:58.008773+00	\N	aal1	\N	2026-05-05 05:07:58.008653	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1	14.236.91.204	\N	\N	\N	\N	\N
17eebc96-a8e4-40b8-a4f4-8cf185e8d585	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 05:30:14.426002+00	2026-05-05 06:43:19.186788+00	\N	aal1	\N	2026-05-05 06:43:19.186676	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
c4629844-c5b0-4f4a-b675-9e79aa8079fc	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 01:38:58.932001+00	2026-05-05 06:58:02.229828+00	\N	aal1	\N	2026-05-05 06:58:02.229717	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	117.3.142.59	\N	\N	\N	\N	\N
0252ff6a-4f5d-419e-bada-5db881b3f557	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 05:29:52.06198+00	2026-05-05 07:31:05.157453+00	\N	aal1	\N	2026-05-05 07:31:05.157346	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
746ac5b7-ba5d-4437-99a1-1b7b2b98af3c	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 07:31:06.037492+00	2026-05-05 07:31:06.037492+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
bdc600f7-ab51-420b-bd57-886abc293f1c	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 07:48:22.02121+00	2026-05-05 07:48:22.02121+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
ddfb7882-9b63-4979-aa59-280bcbd46f83	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 07:48:26.329467+00	2026-05-05 07:48:26.329467+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
76ef158e-2723-424e-88a7-e33cee110365	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 07:48:32.389414+00	2026-05-05 07:48:32.389414+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
66c61761-aad9-4b27-99e0-2b1a3aedeea1	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 07:49:04.966724+00	2026-05-05 07:49:04.966724+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
7226c412-1d6a-4b0a-8e7a-91509f076113	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 07:49:09.265586+00	2026-05-05 07:49:09.265586+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
a4898a5c-7896-4a83-9e90-e9f68f802f27	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 08:45:35.922717+00	2026-05-05 08:45:35.922717+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
55ba7369-bbaf-49f5-8f5e-eee95ba064d4	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 08:45:59.407318+00	2026-05-05 08:45:59.407318+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
e3768ef2-e43a-4d91-9192-0635f30bba15	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 06:43:20.137548+00	2026-05-05 08:47:10.816208+00	\N	aal1	\N	2026-05-05 08:47:10.816098	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
f9d66a5c-41d0-44b0-837f-216b42c285f5	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:47:11.775068+00	2026-05-05 08:47:11.775068+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
23d9aa11-b4fd-4b88-a669-115f51f985db	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:48:25.150571+00	2026-05-05 08:48:25.150571+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
0b5f07f0-84b0-4989-b852-a4a2b3c30d4e	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:48:30.907431+00	2026-05-05 08:48:30.907431+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
35a91ad8-6b74-4eff-b707-d1afc380544b	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:49:01.518308+00	2026-05-05 08:49:01.518308+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
9b5bc7a9-258f-442d-ae44-48e725494b93	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:51:18.399339+00	2026-05-05 08:51:18.399339+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
565d57e9-fa45-4c55-b129-fa5bb637ecc7	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:51:25.521823+00	2026-05-05 08:51:25.521823+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
cf928da7-81eb-4794-b216-c72f55f4a71e	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:51:33.085436+00	2026-05-05 08:51:33.085436+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
3e54b0ef-5541-4cd6-9512-b209c912c316	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:52:17.362647+00	2026-05-05 08:52:17.362647+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
bbbe0ad9-7faf-46df-bee3-932207d777c0	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:52:22.368797+00	2026-05-05 08:52:22.368797+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
d4b17260-a81f-4b65-b30b-ac1f0999dbcc	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:52:35.317374+00	2026-05-05 08:52:35.317374+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
287b93fc-d59f-4367-8299-7f5f0b7b3614	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:52:50.611011+00	2026-05-05 08:52:50.611011+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
52409d80-f00d-4a3b-9058-7c6c9e0f1f22	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:52:55.678651+00	2026-05-05 08:52:55.678651+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
ce95d173-00c9-4acd-a35d-5f3e7715b72c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 08:53:16.409493+00	2026-05-05 08:53:16.409493+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
177749b0-dfdb-4a9c-9af1-a7c841ae36ab	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-05 08:56:05.818716+00	2026-05-05 08:56:05.818716+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
ae763eb9-2669-4978-80a0-d0d6986f2644	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-05 08:56:42.179071+00	2026-05-05 08:56:42.179071+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	42.112.8.72	\N	\N	\N	\N	\N
81d36529-2bb9-40f8-ba59-8664a2b95ba8	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:04:51.157848+00	2026-05-05 09:04:51.157848+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
19fa2897-d1e9-4457-aa6b-634c3358732c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 04:14:59.517778+00	2026-05-05 13:18:43.262795+00	\N	aal1	\N	2026-05-05 13:18:43.262688	Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1	171.251.239.211	\N	\N	\N	\N	\N
36c21b72-c61d-4396-a6ae-33fdc6229e5f	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:05:00.143765+00	2026-05-05 09:05:00.143765+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
65377ec6-9c52-4c5c-9004-2480cc30ef2d	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:05:04.315163+00	2026-05-05 09:05:04.315163+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
b595635b-14cc-49aa-8083-a6101cc26f30	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:05:06.401397+00	2026-05-05 09:05:06.401397+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
8c44043c-b0e9-43cb-a6a3-15800a3b3dc7	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:05:07.668226+00	2026-05-05 09:05:07.668226+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
ef39d3aa-435e-4897-9f6e-dd3d3502525b	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:05:10.255275+00	2026-05-05 09:05:10.255275+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
8977b9fc-f710-4aad-9a7e-a75d814e3af2	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:05:13.14037+00	2026-05-05 09:05:13.14037+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
b3cb45ed-5a14-4f7c-a5c4-248b9a629f5a	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:05:16.127567+00	2026-05-05 09:05:16.127567+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
46d0eeab-9af3-4b0c-9087-f94bb88b00f3	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:05:19.323546+00	2026-05-05 09:05:19.323546+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
e001f007-5fa5-4dea-8be0-f4fc21e1c910	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:05:31.449865+00	2026-05-05 09:05:31.449865+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
00e11523-c130-4426-9cc2-3b3e25e2df5b	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:05:37.732865+00	2026-05-05 09:05:37.732865+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
4683efc8-ceab-4973-845c-958e1c86b6a1	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:06:05.617318+00	2026-05-05 09:06:05.617318+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
2c037710-a3bc-4d20-8c2c-1a82e824d15c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:06:43.113073+00	2026-05-05 09:06:43.113073+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
46ca7411-881f-41d6-8c7b-e9c47735c1c0	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:10:41.026846+00	2026-05-05 09:10:41.026846+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
b4a45a6f-f318-4044-a329-1bb5a47b4e77	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:11:35.73111+00	2026-05-05 09:11:35.73111+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
ff560c57-9b1a-486b-9827-c9f1fa6a654d	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:11:39.595639+00	2026-05-05 09:11:39.595639+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
b80661e0-77c3-41b0-80c0-543588924842	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:11:44.221669+00	2026-05-05 09:11:44.221669+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
4e118ef6-0f15-41f2-8a65-8ec1c8efeb91	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:11:52.905425+00	2026-05-05 09:11:52.905425+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
0b729218-9ab7-48c8-b1d9-f0b394264d21	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:11:58.730139+00	2026-05-05 09:11:58.730139+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
fb0964c0-18e1-4f09-b14f-ca6e79636db6	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:19:49.53356+00	2026-05-05 09:19:49.53356+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
3edd612f-ebe1-4e68-ad26-ee80767bf38c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:19:53.723467+00	2026-05-05 09:19:53.723467+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
69dc4520-f8ca-4afc-9dca-31ab6e2f89ea	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:19:57.486242+00	2026-05-05 09:19:57.486242+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
287b9f54-27ef-442f-bfff-69f8809e55c2	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:20:00.428489+00	2026-05-05 09:20:00.428489+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
cff2cf55-bbb3-421a-8a2d-c483a48677b4	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:20:07.947251+00	2026-05-05 09:20:07.947251+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
198a0c13-e000-4910-93a9-1f047793fa96	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:20:10.577024+00	2026-05-05 09:20:10.577024+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
f425b5a9-6712-4bec-894b-0684b4920443	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:20:13.239794+00	2026-05-05 09:20:13.239794+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
7146453c-0da3-4d01-8fe3-597aba3e7f76	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:20:37.399469+00	2026-05-05 09:20:37.399469+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
5794d0fb-3de4-4a21-ad88-30608322e40d	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:20:43.024753+00	2026-05-05 09:20:43.024753+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
56ba64c8-0127-42fe-8c08-22d48bf593c0	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:20:46.170535+00	2026-05-05 09:20:46.170535+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
9e79887b-ebb7-41a3-b557-f086a8bbe84e	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:20:48.916045+00	2026-05-05 09:20:48.916045+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
2904744f-6e4b-42eb-b5f7-2cb01aba1201	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:20:51.679915+00	2026-05-05 09:20:51.679915+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
d8530133-e9f3-403f-9671-9f97a29031fc	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 09:36:00.266041+00	2026-05-05 09:36:00.266041+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
dec25eb0-01a7-4a53-9713-f05ec9688102	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 09:36:35.012151+00	2026-05-05 09:36:35.012151+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
065a6a8a-307c-4549-ab89-f7b2d3fa6071	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:39:01.726178+00	2026-05-05 09:39:01.726178+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
266ab7ad-fee4-4060-b714-0df6ae56f7ef	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:39:05.588709+00	2026-05-05 09:39:05.588709+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
f66a48a1-8e28-4f9b-9060-24e981e39b13	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:39:10.51953+00	2026-05-05 09:39:10.51953+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
6f5185ee-9a32-495e-acd8-a237e0906983	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:39:22.298731+00	2026-05-05 09:39:22.298731+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
66d1ad24-ea77-448c-ba47-b9253b785162	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 09:39:53.290574+00	2026-05-05 09:39:53.290574+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
b2fd433f-56d3-42f3-83e7-5f310c97989b	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 09:40:04.110621+00	2026-05-05 09:40:04.110621+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
170e25f2-52c2-4794-98ba-1607557e84e3	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 09:40:07.735568+00	2026-05-05 09:40:07.735568+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
5bb6dec3-adb6-4c26-bbd0-732eebcc49cd	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:40:45.293096+00	2026-05-05 09:40:45.293096+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
416aa2ba-63fa-4b96-aacb-fc0886a05708	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:52:06.160396+00	2026-05-05 09:52:06.160396+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
c57cfdf1-6c5b-434f-8c6d-973a38aedb0a	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:52:45.688978+00	2026-05-05 09:52:45.688978+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
2bb14976-f280-4aa1-979c-c185709ef86e	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:52:51.084937+00	2026-05-05 09:52:51.084937+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
9676c8c5-b532-41d3-869b-3940abe754e9	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:52:54.079813+00	2026-05-05 09:52:54.079813+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
9cc2c579-cbb7-4420-9edd-6459c8824156	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:52:57.713801+00	2026-05-05 09:52:57.713801+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
c72404dc-1467-4c5d-a894-ae5b39e36053	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:53:00.955388+00	2026-05-05 09:53:00.955388+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
b7b68fe3-ca3a-4cd2-a60f-75772440c0d9	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:53:03.964064+00	2026-05-05 09:53:03.964064+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
37620b72-37c5-4ae6-9372-cc9b5914e607	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:53:13.572798+00	2026-05-05 09:53:13.572798+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
fa708d2b-9f81-4ad4-bd43-479b2f2af26f	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:53:52.292094+00	2026-05-05 09:53:52.292094+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
75028800-d27a-4e77-877e-028fa64bca10	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 10:01:37.919011+00	2026-05-05 10:01:37.919011+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
5603fb42-13c5-4cb2-912a-003124de62e4	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 10:01:48.632051+00	2026-05-05 10:01:48.632051+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
783ccce5-9ec5-43f9-a305-06e7f4b2c23c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 10:02:12.444651+00	2026-05-05 10:02:12.444651+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
031c3e37-a433-403f-838e-08c403e13ee8	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 10:02:19.674828+00	2026-05-05 10:02:19.674828+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
532a2e5e-b419-4c51-95ee-3d31ae7bc179	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 10:14:01.921473+00	2026-05-05 10:14:01.921473+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
a9d35b7d-c90a-4e56-8d70-28ece2cdd63e	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 10:14:14.37989+00	2026-05-05 10:14:14.37989+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
188540b9-3fc4-410a-ba05-91e0d39416bf	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 10:23:59.614411+00	2026-05-05 10:23:59.614411+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
fdd1f54c-7b4a-4a3e-9ad4-fe69cb23377f	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 10:29:47.661714+00	2026-05-05 10:29:47.661714+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1	14.236.91.204	\N	\N	\N	\N	\N
4005f373-5f9d-486e-b912-8a0e4f8386d1	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 10:40:02.388788+00	2026-05-05 10:40:02.388788+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	113.185.108.37	\N	\N	\N	\N	\N
5920c8c1-8ed5-4a6c-b7f5-cf52005b5df9	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:16:33.207475+00	2026-05-05 11:16:33.207475+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
e9edff2f-72e3-4119-8742-d18f83784b8e	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 05:07:58.930202+00	2026-05-05 11:20:48.125742+00	\N	aal1	\N	2026-05-05 11:20:48.12562	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1	14.191.234.131	\N	\N	\N	\N	\N
ccda3d9e-6f2e-437a-a296-e31f80a264aa	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:25:37.424815+00	2026-05-05 11:25:37.424815+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
62604bc2-0044-4523-9d70-226c132e60b9	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:25:40.146395+00	2026-05-05 11:25:40.146395+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
c3fb64f6-59ca-4d6b-a1ca-efacdd08b485	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:25:42.066619+00	2026-05-05 11:25:42.066619+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
cd004805-a941-4a3c-8165-63081c3947a5	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:25:44.071637+00	2026-05-05 11:25:44.071637+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
d4306924-41ef-4da4-9f0a-805505044a54	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:25:45.953468+00	2026-05-05 11:25:45.953468+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
520f80a6-4a95-4538-af31-c36d708826d1	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:25:49.134825+00	2026-05-05 11:25:49.134825+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
29b67951-dd20-4cfb-a3d4-9dbdfa17ba40	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:25:51.03307+00	2026-05-05 11:25:51.03307+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
01df7d0c-48ba-4179-9b9c-f031f6a6c797	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:25:53.016339+00	2026-05-05 11:25:53.016339+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
70b3669a-dea5-4f1f-846f-a70c85148727	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:25:55.713072+00	2026-05-05 11:25:55.713072+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
1d65b308-36d6-4962-bbe1-eaee021b88ea	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:26:01.671704+00	2026-05-05 11:26:01.671704+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.172.219	\N	\N	\N	\N	\N
f5b8ecfe-4e0f-4947-87d0-b89d590c13ee	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 10:04:00.036729+00	2026-05-07 05:27:47.522984+00	\N	aal1	\N	2026-05-07 05:27:47.522878	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.251.239.138	\N	\N	\N	\N	\N
60432168-ba3d-4b59-ae8b-7dc310046b03	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-05 11:16:51.238426+00	2026-05-07 01:30:42.683374+00	\N	aal1	\N	2026-05-07 01:30:42.683224	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.122.75	\N	\N	\N	\N	\N
f56b1375-f128-47ed-ba05-dda6cfd4c37d	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 09:41:02.042914+00	2026-05-06 09:31:41.008717+00	\N	aal1	\N	2026-05-06 09:31:41.008608	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
41bd728f-cd6d-4f75-b567-dda95e0017a2	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 10:09:33.894732+00	2026-05-05 13:28:14.060036+00	\N	aal1	\N	2026-05-05 13:28:14.059933	Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.1	14.233.245.140	\N	\N	\N	\N	\N
f8cfedfc-bbd8-4fec-9837-cffb780237bc	815c5ba4-df3e-470b-a277-f6e9b9c1941e	2026-05-09 03:55:37.916395+00	2026-05-09 03:55:37.916395+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.120 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/light ZaloLanguage/vi	171.226.24.154	\N	\N	\N	\N	\N
f698b2cd-bbd1-48df-8711-abc037c2f86a	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:20:48.756526+00	2026-05-05 14:56:44.743192+00	\N	aal1	\N	2026-05-05 14:56:44.743082	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1	14.233.247.92	\N	\N	\N	\N	\N
b0d4b141-d279-4131-8612-399170fb322c	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 00:18:48.753763+00	2026-05-05 16:48:42.092687+00	\N	aal1	\N	2026-05-05 16:48:42.092579	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	42.1.105.74	\N	\N	\N	\N	\N
d37d81b0-8e0f-454e-b267-2dedb65d530e	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 13:28:14.572907+00	2026-05-06 06:53:58.215557+00	\N	aal1	\N	2026-05-06 06:53:58.215451	Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.1	171.255.130.150	\N	\N	\N	\N	\N
d2aeb278-0666-4fce-97f4-b67f59b819a3	815c5ba4-df3e-470b-a277-f6e9b9c1941e	2026-05-09 08:57:05.48575+00	2026-05-09 08:57:05.48575+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	58.186.151.4	\N	\N	\N	\N	\N
70ed0cf8-9b7c-4ad0-accc-c6034e7de1c9	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 11:26:04.081592+00	2026-05-06 12:51:04.510331+00	\N	aal1	\N	2026-05-06 12:51:04.510207	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.176.126	\N	\N	\N	\N	\N
ee259390-b741-418f-a143-07dadf976d40	f38b5572-029f-4d74-ac31-3d5e278df151	2026-05-05 09:39:36.407474+00	2026-05-06 12:55:46.403424+00	\N	aal1	\N	2026-05-06 12:55:46.403321	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
e22c7e96-caf6-4617-bad4-d8cd3f0f6afa	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-03 22:59:40.100299+00	2026-05-06 13:53:48.803849+00	\N	aal1	\N	2026-05-06 13:53:48.803742	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.111 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/light ZaloLanguage/vi	171.254.173.81	\N	\N	\N	\N	\N
242199f4-395a-454d-83e0-67cfa7222f97	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-06 13:53:49.790778+00	2026-05-07 03:32:12.57825+00	\N	aal1	\N	2026-05-07 03:32:12.578128	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.137 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/light ZaloLanguage/vi	171.254.184.187	\N	\N	\N	\N	\N
60ba9e8b-0479-4868-97bf-ef70c2bb3266	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-07 03:32:13.579349+00	2026-05-07 03:32:13.579349+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.137 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/light ZaloLanguage/vi	171.254.184.187	\N	\N	\N	\N	\N
5231d6de-9266-4dca-b421-c7bc1fc3343b	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-07 04:22:13.003719+00	2026-05-07 04:22:13.003719+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
f1f20aee-43c5-4368-99ac-921f6f91d405	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-10 02:22:30.841284+00	2026-05-10 02:22:30.841284+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.3 Mobile/15E148 Safari/604.1	14.245.55.90	\N	\N	\N	\N	\N
c50a15ab-4492-4581-bcde-1688c05ffe9b	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-07 05:27:48.551857+00	2026-05-07 07:37:21.681898+00	\N	aal1	\N	2026-05-07 07:37:21.681784	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.251.239.138	\N	\N	\N	\N	\N
79ec4ab0-5548-45ec-800d-94b0d3f11ceb	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-07 01:30:43.626704+00	2026-05-07 07:52:09.192705+00	\N	aal1	\N	2026-05-07 07:52:09.192587	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
985a6fb5-dd71-4f3c-9f23-342ffef72660	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	2026-05-07 07:52:10.085272+00	2026-05-07 07:52:10.085272+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
c25d9809-45d9-4a72-b6a6-bc6ec95f4969	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-05 15:25:21.099436+00	2026-05-07 17:39:07.184616+00	\N	aal1	\N	2026-05-07 17:39:07.184492	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.3 Mobile/15E148 Safari/604.1	14.245.55.90	\N	\N	\N	\N	\N
283eee76-180d-444b-8d01-f9d01b30dd1f	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-07 07:37:23.018293+00	2026-05-08 13:45:35.170878+00	\N	aal1	\N	2026-05-08 13:45:35.170766	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.251.239.138	\N	\N	\N	\N	\N
53fda4c7-6e61-4c7d-bdc8-6b933c1c7883	815c5ba4-df3e-470b-a277-f6e9b9c1941e	2026-05-09 03:51:09.753156+00	2026-05-09 03:51:09.753156+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
411dd013-b3ae-49d4-afec-bb2318f2c810	815c5ba4-df3e-470b-a277-f6e9b9c1941e	2026-05-09 08:56:48.386594+00	2026-05-09 22:37:16.891559+00	\N	aal1	\N	2026-05-09 22:37:16.891442	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
ca4c863a-9a15-4c49-8eb3-ecbf6f441425	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-07 17:39:08.507448+00	2026-05-10 01:38:27.009127+00	\N	aal1	\N	2026-05-10 01:38:27.009018	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.3 Mobile/15E148 Safari/604.1	14.245.55.90	\N	\N	\N	\N	\N
7c515e71-0f87-4ab3-adad-8905fc80ee8f	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-10 01:38:27.879299+00	2026-05-10 01:38:27.879299+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.3 Mobile/15E148 Safari/604.1	14.245.55.90	\N	\N	\N	\N	\N
aa8653a4-f2fa-4bf1-8eee-33f2d4962055	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-10 01:42:49.195319+00	2026-05-10 01:42:49.195319+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.3 Mobile/15E148 Safari/604.1	14.245.55.90	\N	\N	\N	\N	\N
39e8b758-f1db-4777-9160-edc23a7a3fdc	815c5ba4-df3e-470b-a277-f6e9b9c1941e	2026-05-10 00:27:00.685797+00	2026-05-10 01:51:43.355701+00	\N	aal1	\N	2026-05-10 01:51:43.355548	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	27.67.72.208	\N	\N	\N	\N	\N
c26f1670-380b-4135-8454-b6308cfe83ae	815c5ba4-df3e-470b-a277-f6e9b9c1941e	2026-05-09 03:51:10.035025+00	2026-05-10 02:11:12.856519+00	\N	aal1	\N	2026-05-10 02:11:12.856355	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
c68b23b6-4a30-480f-b672-e86dc4a40424	adea62ce-52d6-489d-82e7-362203d85c01	2026-05-12 03:33:37.106709+00	2026-05-12 03:33:37.106709+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
dca37899-79e9-4128-9868-d2919b25d223	815c5ba4-df3e-470b-a277-f6e9b9c1941e	2026-05-10 02:11:13.370633+00	2026-05-10 09:10:01.256413+00	\N	aal1	\N	2026-05-10 09:10:01.25631	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
2e2b56bf-045f-48dd-9217-26512e6cd3c8	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-08 13:45:35.779432+00	2026-05-10 09:56:26.330864+00	\N	aal1	\N	2026-05-10 09:56:26.330752	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.251.239.138	\N	\N	\N	\N	\N
2ebb6473-f134-4ccc-9d89-8bb556761f15	4528c17c-395c-4e97-981c-17dbe2bc8181	2026-05-12 03:55:40.218399+00	2026-05-12 03:55:40.218399+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
77216d52-e035-4932-ba7e-95dc667cb37d	4528c17c-395c-4e97-981c-17dbe2bc8181	2026-05-12 03:59:29.13166+00	2026-05-12 03:59:29.13166+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
d1773aa4-e2cf-4f16-9cc7-d8011cef7d4d	4528c17c-395c-4e97-981c-17dbe2bc8181	2026-05-12 04:06:24.250573+00	2026-05-12 04:06:24.250573+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
b52db1d5-6c8c-4995-b853-f397880ae4f9	adea62ce-52d6-489d-82e7-362203d85c01	2026-05-12 04:12:25.452008+00	2026-05-12 04:12:25.452008+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	112.197.13.73	\N	\N	\N	\N	\N
5a6c9ea6-1188-4c21-93a6-b3efb87a6a62	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-10 09:56:26.850813+00	2026-05-12 14:02:32.240697+00	\N	aal1	\N	2026-05-12 14:02:32.240579	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	14.174.118.71	\N	\N	\N	\N	\N
5a8cf411-baf1-4b30-b544-3c2e7fa015ba	4528c17c-395c-4e97-981c-17dbe2bc8181	2026-05-12 04:12:28.478452+00	2026-05-12 04:12:28.478452+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
77fb3af8-c054-4368-9646-76975b99daab	4528c17c-395c-4e97-981c-17dbe2bc8181	2026-05-12 04:28:07.460121+00	2026-05-12 04:28:07.460121+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
951306fa-76e5-4cd6-8af4-a03b3d32a7d4	4528c17c-395c-4e97-981c-17dbe2bc8181	2026-05-12 04:30:02.743157+00	2026-05-12 04:30:02.743157+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
7239565e-2a02-4ae8-a885-79423fc264b5	adea62ce-52d6-489d-82e7-362203d85c01	2026-05-12 06:41:10.8232+00	2026-05-12 07:47:50.303535+00	\N	aal1	\N	2026-05-12 07:47:50.303399	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	14.233.245.100	\N	\N	\N	\N	\N
f6621222-744f-4704-aa28-e79af2f5cdc9	adea62ce-52d6-489d-82e7-362203d85c01	2026-05-12 03:33:37.407484+00	2026-05-12 08:17:34.025277+00	\N	aal1	\N	2026-05-12 08:17:34.025132	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	14.233.245.100	\N	\N	\N	\N	\N
d60afcd7-b32f-48b5-bae3-dca6ea401fa5	99321c1d-2254-4bbe-a5df-d14e52829a39	2026-05-12 08:51:23.330302+00	2026-05-12 08:51:23.330302+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.120 Mobile Safari/537.36 Zalo android/260402903 ZaloTheme/light ZaloLanguage/vi	171.255.155.137	\N	\N	\N	\N	\N
1f914aeb-48e0-42f8-b2c1-97655312f96b	99321c1d-2254-4bbe-a5df-d14e52829a39	2026-05-12 09:10:19.591848+00	2026-05-12 09:10:19.591848+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
56a07ac3-04d7-4170-a60c-677df48ce0c2	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-15 08:02:54.592101+00	2026-05-15 09:22:34.587549+00	\N	aal1	\N	2026-05-15 09:22:34.587444	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	14.245.58.191	\N	\N	\N	\N	\N
22ea508e-6367-466a-827c-20bb8d5a49b0	adea62ce-52d6-489d-82e7-362203d85c01	2026-05-12 08:17:34.683517+00	2026-05-12 13:21:01.290511+00	\N	aal1	\N	2026-05-12 13:21:01.290404	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
3ba82bd1-8321-4ca5-ac96-1fae1ec0181c	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-18 04:08:36.487378+00	2026-05-18 05:30:18.401637+00	\N	aal1	\N	2026-05-18 05:30:18.401518	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
4d00bd00-001c-441c-8adb-3f1cc803f68e	99321c1d-2254-4bbe-a5df-d14e52829a39	2026-05-12 09:12:02.783304+00	2026-05-12 13:55:40.136507+00	\N	aal1	\N	2026-05-12 13:55:40.136366	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
df9d2a92-9a6c-4462-92b9-c735af849ff0	4ab940a0-686b-4685-ac38-9d5e566db113	2026-05-12 14:02:32.973239+00	2026-05-12 14:02:32.973239+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	14.174.118.71	\N	\N	\N	\N	\N
5b87f05b-cae5-422d-9b90-7b064bfa0c0a	adea62ce-52d6-489d-82e7-362203d85c01	2026-05-12 13:21:08.83939+00	2026-05-12 14:21:48.693083+00	\N	aal1	\N	2026-05-12 14:21:48.69297	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
1e05550b-a835-47de-b6c4-89c3becb4d3d	99321c1d-2254-4bbe-a5df-d14e52829a39	2026-05-12 08:39:50.506404+00	2026-05-12 23:33:56.031149+00	\N	aal1	\N	2026-05-12 23:33:56.031035	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.255.159.118	\N	\N	\N	\N	\N
2777a7c1-042f-4dca-8f0c-45dbd379f32d	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-12 23:34:48.843179+00	2026-05-12 23:34:48.843179+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.255.159.118	\N	\N	\N	\N	\N
1e168b2c-11d4-4092-b676-4c8e788f8538	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-12 23:34:49.141823+00	2026-05-13 00:33:19.277312+00	\N	aal1	\N	2026-05-13 00:33:19.277179	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.255.159.118	\N	\N	\N	\N	\N
ba596001-f01e-4933-975e-9dda2a467689	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-14 03:23:34.340385+00	2026-05-14 03:23:34.340385+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.144.234	\N	\N	\N	\N	\N
c19eba59-c4b0-4aea-830f-e4f19f8b6b57	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-14 03:23:51.644518+00	2026-05-14 03:23:51.644518+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	27.2.199.6	\N	\N	\N	\N	\N
2c0ce936-6eed-428e-82b8-3ac1f2b20896	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-15 08:03:27.094199+00	2026-05-15 08:03:27.094199+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	27.2.199.6	\N	\N	\N	\N	\N
ff7b77e1-d0da-4e7d-a9fe-66e66212fbd0	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	2026-05-18 09:54:24.278536+00	2026-05-18 09:54:24.278536+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
3d9d94be-a801-4d2c-8d9d-ac009eed2490	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	2026-05-18 08:14:28.434335+00	2026-05-18 08:14:28.434335+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
b3db0ff5-e566-4e01-9e71-8d96ca73f793	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	2026-05-18 08:14:28.747753+00	2026-05-18 08:14:28.747753+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
2c24d48f-886c-48c1-8033-d4c3baa33181	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	2026-05-18 10:28:58.647845+00	2026-05-18 10:28:58.647845+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
178edd41-53bd-41f6-aa72-5682326ecd16	722d8397-103b-4234-8e9d-e329674e79f2	2026-05-18 11:05:49.090332+00	2026-05-19 14:54:58.11094+00	\N	aal1	\N	2026-05-19 14:54:58.110817	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.175.116	\N	\N	\N	\N	\N
301ea009-f107-459d-a047-89550e1a5fa1	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	2026-05-18 08:31:26.288991+00	2026-05-18 09:53:45.458353+00	\N	aal1	\N	2026-05-18 09:53:45.458241	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
b0bfa512-f3f1-4e1b-a670-6b2ec0ca061e	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	2026-05-18 09:54:09.203619+00	2026-05-18 09:54:09.203619+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
ac829951-5a35-41ec-a5f4-89d73a923a5b	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	2026-05-18 10:08:14.80156+00	2026-05-18 10:08:14.80156+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
ba5f6d5c-056c-495c-8ee8-40c28dd0c413	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	2026-05-18 10:09:30.434109+00	2026-05-18 10:09:30.434109+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
a408d35f-c1a0-49af-866e-3daa69f6a218	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	2026-05-18 10:10:43.324293+00	2026-05-18 10:10:43.324293+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
d34e0fae-d491-403a-86f4-8ac23bdb5b21	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-18 06:15:28.939397+00	2026-05-18 10:10:57.827441+00	\N	aal1	\N	2026-05-18 10:10:57.827345	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
4d66d408-82ab-46de-a7b6-934f9e7eeaaa	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	2026-05-18 10:23:46.222586+00	2026-05-18 10:23:46.222586+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
ac1a3931-538e-47e3-acd7-0d8bc8aeab11	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-15 09:43:06.244828+00	2026-05-18 11:04:28.862465+00	\N	aal1	\N	2026-05-18 11:04:28.862348	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.120 Mobile Safari/537.36 Zalo android/260402903 ZaloTheme/light ZaloLanguage/vi	171.255.156.159	\N	\N	\N	\N	\N
8b41447d-9c32-4326-88e3-110c74428913	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-15 10:23:21.363618+00	2026-05-18 11:04:50.218446+00	\N	aal1	\N	2026-05-18 11:04:50.218351	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.156.159	\N	\N	\N	\N	\N
93d9de5e-25f0-4ac9-a89d-0e181191a7cd	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-18 11:05:27.769439+00	2026-05-18 11:05:27.769439+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.156.159	\N	\N	\N	\N	\N
6d57fa82-abff-4e10-8999-0e08f39bec07	722d8397-103b-4234-8e9d-e329674e79f2	2026-05-18 11:05:48.818247+00	2026-05-18 11:05:48.818247+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.255.156.159	\N	\N	\N	\N	\N
173bdbdc-9ed8-431e-a70b-005c30c9b18c	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:02:00.974103+00	2026-05-18 13:02:00.974103+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
1812dafd-f0c3-46e3-87f1-47e582dba5c6	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:02:01.20945+00	2026-05-18 13:02:01.20945+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
56a558f9-91d8-4314-9657-fe5ab0b3fe39	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:02:04.199774+00	2026-05-18 13:02:04.199774+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
787f349d-0811-4b90-899c-a78659a6e9e4	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:02:08.901938+00	2026-05-18 13:02:08.901938+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
a273fcc9-ee59-4450-9cb6-df0c9da8f5d0	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:02:14.599441+00	2026-05-18 13:02:14.599441+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
5aaaac41-8517-4c2a-8032-3d4558b4cdad	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:02:18.54849+00	2026-05-18 13:02:18.54849+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
7610f4c3-8829-444e-b095-a1053a3ebf4e	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:02:22.053977+00	2026-05-18 13:02:22.053977+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
077d4037-bff8-44e0-b512-41064312a15a	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:02:31.767003+00	2026-05-18 13:02:31.767003+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
7157f531-a0a6-4885-a1e5-5bbfa26eef79	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:02:36.403453+00	2026-05-18 13:02:36.403453+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
dc834374-9cbe-409c-8415-890821d4a1cf	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:03:40.197668+00	2026-05-18 13:03:40.197668+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
6f43e9ca-0450-4a4c-8046-53528ca63fb2	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:03:46.301991+00	2026-05-18 13:03:46.301991+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
6bd75a30-b7e0-4c78-b691-1f95c4578c91	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:03:52.82402+00	2026-05-18 13:03:52.82402+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
fc9a9266-354d-42c0-bf31-88f379ddf804	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:04:54.988329+00	2026-05-18 13:04:54.988329+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
0145cc85-5691-435d-ad55-8eab30cc0984	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:05:08.844593+00	2026-05-18 13:05:08.844593+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
298fcc0c-55c4-4360-b565-f10207a39720	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:06:01.390734+00	2026-05-18 13:06:01.390734+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
eedcda3d-ddca-4dcd-9963-76557e88415e	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:06:31.882099+00	2026-05-18 13:06:31.882099+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
9e53e2ef-f449-4f60-a723-f5d36105a677	a24e2881-8767-4f08-9552-fc3376516585	2026-05-18 13:06:34.698345+00	2026-05-18 13:06:34.698345+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
281b0af4-4387-42c9-b740-75e26f4a86ea	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-18 12:37:54.469212+00	2026-05-19 00:10:25.156473+00	\N	aal1	\N	2026-05-19 00:10:25.156352	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.154.137	\N	\N	\N	\N	\N
45a78244-e0b5-4800-a0a6-6d4b8d77b1d9	46283390-81d3-4324-9d77-9cfd33c224bc	2026-05-19 00:10:26.226638+00	2026-05-19 00:10:26.226638+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.154.137	\N	\N	\N	\N	\N
403f4ce5-7ae0-47bb-8c39-5bbe942ed4f9	99321c1d-2254-4bbe-a5df-d14e52829a39	2026-05-20 09:26:11.475186+00	2026-05-20 09:26:11.475186+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.175.116	\N	\N	\N	\N	\N
fa339652-cd72-40ea-ba85-1a74a7ac69aa	99321c1d-2254-4bbe-a5df-d14e52829a39	2026-05-20 09:29:29.499559+00	2026-05-20 09:29:29.499559+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.175.116	\N	\N	\N	\N	\N
23fa685a-8a86-4bd6-9ace-e59d31ef4934	0b718cac-6cd9-494a-9076-e924f23783d0	2026-05-20 11:13:45.030128+00	2026-05-23 01:31:24.039741+00	\N	aal1	\N	2026-05-23 01:31:24.039636	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.170.143	\N	\N	\N	\N	\N
9650b067-00cf-4467-9bab-26c6971b506d	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-20 10:16:05.089346+00	2026-05-20 10:16:05.089346+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.251.238.135	\N	\N	\N	\N	\N
b55abdfb-eee2-4d74-ba51-db2efd6bd37f	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-20 10:16:57.375436+00	2026-05-20 10:16:57.375436+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.251.238.135	\N	\N	\N	\N	\N
718b35c6-8d24-4290-b73a-b23ef6886f7c	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-20 10:31:04.231525+00	2026-05-20 10:31:04.231525+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.251.238.135	\N	\N	\N	\N	\N
f5d23264-269e-441f-a54a-98cc655586c6	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-20 10:31:31.426546+00	2026-05-20 10:31:31.426546+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.251.238.135	\N	\N	\N	\N	\N
9f13e170-8b46-4398-9311-fbeb9e4df81e	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-20 10:32:05.795484+00	2026-05-20 10:32:05.795484+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.251.238.135	\N	\N	\N	\N	\N
3e540e7a-1663-46b1-993d-4fc552d9ee71	0b718cac-6cd9-494a-9076-e924f23783d0	2026-05-20 11:11:02.245582+00	2026-05-20 11:11:02.245582+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.175.116	\N	\N	\N	\N	\N
22db4a20-9d90-4d8f-9238-2fc87d44ca8b	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-21 07:27:31.698186+00	2026-05-21 07:27:31.698186+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.153.201	\N	\N	\N	\N	\N
c961e55c-311d-4fff-9aaa-53c8bae47578	0b718cac-6cd9-494a-9076-e924f23783d0	2026-05-21 06:37:58.8101+00	2026-05-21 06:37:58.8101+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.153.201	\N	\N	\N	\N	\N
48d65a47-d38a-41ae-ac93-f86e647ffcb0	0b718cac-6cd9-494a-9076-e924f23783d0	2026-05-21 06:38:37.496602+00	2026-05-21 06:38:37.496602+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36	112.197.12.68	\N	\N	\N	\N	\N
e5c5d073-5be8-4eb3-a6fd-923c101e1af1	0b718cac-6cd9-494a-9076-e924f23783d0	2026-05-21 07:20:33.673458+00	2026-05-21 07:20:33.673458+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	112.197.13.71	\N	\N	\N	\N	\N
99c5a4a8-3ae9-4d40-b307-c2c733aa45c0	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-20 10:33:21.885759+00	2026-05-21 07:24:57.735791+00	\N	aal1	\N	2026-05-21 07:24:57.735634	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.153.201	\N	\N	\N	\N	\N
ea8dad74-f70d-438c-8526-cc46490b27b2	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-21 07:25:53.238437+00	2026-05-21 07:25:53.238437+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.153.201	\N	\N	\N	\N	\N
eddca24c-cb63-455b-9d60-83fb02e06ba0	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-21 07:27:53.987686+00	2026-05-21 07:27:53.987686+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.153.201	\N	\N	\N	\N	\N
2267c369-25de-4d41-ac5e-a2a6c1db726d	99321c1d-2254-4bbe-a5df-d14e52829a39	2026-05-18 06:12:26.417805+00	2026-05-28 03:38:09.242174+00	\N	aal1	\N	2026-05-28 03:38:09.242068	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.251.238.41	\N	\N	\N	\N	\N
e79dd47d-76bd-4f67-9ed9-f7bedbd770a3	0b718cac-6cd9-494a-9076-e924f23783d0	2026-05-21 07:06:41.403685+00	2026-05-24 09:39:27.335533+00	\N	aal1	\N	2026-05-24 09:39:27.335429	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.147.35	\N	\N	\N	\N	\N
b5726f4e-5818-495a-9ae6-64502b093101	0b718cac-6cd9-494a-9076-e924f23783d0	2026-05-21 07:44:24.577083+00	2026-05-21 07:44:24.577083+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36	112.197.13.69	\N	\N	\N	\N	\N
b0bd8c31-6419-4c4e-b99a-315327dc19d1	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-21 07:28:09.145771+00	2026-05-21 08:29:29.71054+00	\N	aal1	\N	2026-05-21 08:29:29.710442	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.153.201	\N	\N	\N	\N	\N
9cc68a49-4bd7-450a-9bac-2170d2bb9986	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-21 08:30:48.90566+00	2026-05-21 08:30:48.90566+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	42.112.8.6	\N	\N	\N	\N	\N
de9475b5-d803-4ebe-b3b9-374ddbfecb34	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-21 08:42:28.471362+00	2026-05-21 08:42:28.471362+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.153.201	\N	\N	\N	\N	\N
fa513c6d-6a2e-4da8-9f86-8fd529a87df6	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-21 08:45:05.227167+00	2026-05-21 08:45:05.227167+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.153.201	\N	\N	\N	\N	\N
d63f1d54-62c1-4c78-9cd4-7e8ffaa6ae7d	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-21 08:47:08.176203+00	2026-05-21 08:47:08.176203+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.153.201	\N	\N	\N	\N	\N
46dfae19-78ed-4b2b-af7c-63986cbd74aa	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-21 13:31:13.35618+00	2026-05-21 13:31:13.35618+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.251.238.135	\N	\N	\N	\N	\N
283c23e1-cc38-4c9b-85dd-3ecd554b09ae	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-21 13:39:07.595012+00	2026-05-21 13:39:07.595012+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.251.238.135	\N	\N	\N	\N	\N
b36e0ec7-3f50-4b01-9df8-dd3c4fa0c1ab	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-21 14:01:12.616353+00	2026-05-21 22:22:29.448212+00	\N	aal1	\N	2026-05-21 22:22:29.448103	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.120 Mobile Safari/537.36 Zalo android/260402903 ZaloTheme/light ZaloLanguage/vi	171.255.171.87	\N	\N	\N	\N	\N
96d35821-a260-4954-8329-7649210b0214	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-21 22:22:49.392389+00	2026-05-21 22:22:49.392389+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.120 Mobile Safari/537.36 Zalo android/260402903 ZaloTheme/light ZaloLanguage/vi	171.255.171.87	\N	\N	\N	\N	\N
c4b8a017-9ec0-404c-922b-3faf9d1d0801	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-21 13:39:49.498947+00	2026-05-22 01:46:55.457377+00	\N	aal1	\N	2026-05-22 01:46:55.457233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.251.238.135	\N	\N	\N	\N	\N
77dafdca-349c-456e-85b7-448b181ce5eb	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-22 02:12:01.649825+00	2026-05-22 02:12:01.649825+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.251.238.135	\N	\N	\N	\N	\N
457666af-61bc-4bcb-b890-deab4753d655	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-22 02:15:29.183531+00	2026-05-22 02:15:29.183531+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.251.238.135	\N	\N	\N	\N	\N
f3fa874b-4e67-4a59-bf93-a8894c56dc21	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-23 11:13:20.536402+00	2026-05-23 11:13:20.536402+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 16; SM-S711B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	203.113.130.36	\N	\N	\N	\N	\N
bb9f3c3d-b297-4c32-98c8-f3cf3c4cc484	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-22 07:50:45.35156+00	2026-05-22 08:48:47.110896+00	\N	aal1	\N	2026-05-22 08:48:47.110782	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.255.171.87	\N	\N	\N	\N	\N
8b4d20e2-3163-4cfd-a003-cdb5ce4f1338	99321c1d-2254-4bbe-a5df-d14e52829a39	2026-05-27 08:37:28.915501+00	2026-05-27 08:37:28.915501+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.168.84	\N	\N	\N	\N	\N
8238c927-83c9-4054-9a12-53acc1d66929	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-22 15:06:51.453712+00	2026-05-22 15:06:51.453712+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	113.165.99.66	\N	\N	\N	\N	\N
8bab0b44-e764-4f42-b2d5-e318725f1734	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-24 08:48:14.822133+00	2026-06-17 14:50:02.310085+00	\N	aal1	\N	2026-06-17 14:50:02.308902	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0	14.185.217.194	\N	\N	\N	\N	\N
9131093e-a99e-44fe-a072-0894450b6fbc	0b718cac-6cd9-494a-9076-e924f23783d0	2026-05-24 08:14:17.137925+00	2026-05-24 08:14:17.137925+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36	112.197.8.70	\N	\N	\N	\N	\N
02bc7fff-98c3-43ad-86ab-28925e678009	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-22 15:56:39.132187+00	2026-05-23 09:00:56.253466+00	\N	aal1	\N	2026-05-23 09:00:56.253301	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	171.255.170.143	\N	\N	\N	\N	\N
c835c00e-cb33-4e73-9bc0-fe568684a28f	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-30 09:11:27.808073+00	2026-06-18 03:33:07.906031+00	\N	aal1	\N	2026-06-18 03:33:07.905912	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	171.226.27.148	\N	\N	\N	\N	\N
52f853d9-9eab-4876-b6b0-43b6e1c7880e	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-23 11:11:22.661949+00	2026-06-16 03:03:11.242216+00	\N	aal1	\N	2026-06-16 03:03:11.242096	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.244.211.100	\N	\N	\N	\N	\N
975c401c-8e8d-4a1a-9879-c69722702e0d	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-23 10:47:48.389088+00	2026-05-23 10:47:48.389088+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.120 Mobile Safari/537.36 Zalo android/260402903 ZaloTheme/light ZaloLanguage/vi	171.255.170.143	\N	\N	\N	\N	\N
fd8f66da-70d6-4b14-8746-c4341d602dca	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-23 11:11:53.842606+00	2026-05-23 11:11:53.842606+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	27.2.201.6	\N	\N	\N	\N	\N
a15943b5-992b-4578-8ee9-e1e2c7ee156e	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-24 08:36:52.595978+00	2026-05-24 08:36:52.595978+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	171.255.147.35	\N	\N	\N	\N	\N
931f3634-9901-4777-b724-c3df2dd671bc	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-24 09:06:33.529285+00	2026-05-24 09:06:33.529285+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36	171.255.147.35	\N	\N	\N	\N	\N
48d564af-f6fe-4061-81c9-c6a61ad16e01	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-24 09:08:39.638396+00	2026-05-24 09:08:39.638396+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	171.255.147.35	\N	\N	\N	\N	\N
b74e8776-ad72-49c7-aa44-18dacaedf981	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-24 09:57:07.169295+00	2026-05-24 09:57:07.169295+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Zalo iOS/260501802 ZaloTheme/light ZaloLanguage/vn	171.251.239.158	\N	\N	\N	\N	\N
e71b1cde-0aa7-49dc-98f1-d3aac63eec8e	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-23 12:38:36.039892+00	2026-05-26 03:25:02.996114+00	\N	aal1	\N	2026-05-26 03:25:02.996003	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	113.165.99.66	\N	\N	\N	\N	\N
1cf5af7a-4330-4772-9dc7-f1217403bee6	a670a3d7-db76-4536-ad05-13c3ee563069	2026-05-22 02:18:01.804904+00	2026-05-29 13:19:15.275775+00	\N	aal1	\N	2026-05-29 13:19:15.275663	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	171.251.238.41	\N	\N	\N	\N	\N
0a7cd3f3-b5ff-477c-8c9e-99708168fcec	a670a3d7-db76-4536-ad05-13c3ee563069	2026-06-02 08:26:11.714965+00	2026-06-02 08:26:11.714965+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	172.253.234.208	\N	\N	\N	\N	\N
784300a9-8a3e-4390-aa42-3065063e4d07	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	2026-05-21 08:45:41.213705+00	2026-05-31 09:24:25.514226+00	\N	aal1	\N	2026-05-31 09:24:25.514113	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	117.3.120.122	\N	\N	\N	\N	\N
c2695ce5-1b4d-4470-9385-09bb30729934	a670a3d7-db76-4536-ad05-13c3ee563069	2026-06-03 11:16:32.384858+00	2026-06-04 07:42:18.885751+00	\N	aal1	\N	2026-06-04 07:42:18.885645	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	171.231.8.63	\N	\N	\N	\N	\N
1657630c-a6b6-4d4b-aa47-068334954bd4	a670a3d7-db76-4536-ad05-13c3ee563069	2026-06-03 14:07:25.689599+00	2026-06-04 01:32:06.587771+00	\N	aal1	\N	2026-06-04 01:32:06.587662	Mozilla/5.0 (Linux; Android 16; 24117RN76O Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.215 Mobile Safari/537.36 Zalo android/260501901 ZaloTheme/dark ZaloLanguage/vi	113.166.114.87	\N	\N	\N	\N	\N
3a3565fe-10d8-422b-8952-cde21c275df5	a670a3d7-db76-4536-ad05-13c3ee563069	2026-06-06 01:59:04.713305+00	2026-06-06 01:59:04.713305+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	116.110.226.30	\N	\N	\N	\N	\N
cd501d74-ce02-4630-8f9d-1b95177b998b	a670a3d7-db76-4536-ad05-13c3ee563069	2026-06-16 10:18:23.654836+00	2026-06-18 06:32:55.748753+00	\N	aal1	\N	2026-06-18 06:32:55.748645	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	171.251.238.41	\N	\N	\N	\N	\N
7a740360-2e6d-42ad-b659-ca3312d3684d	a670a3d7-db76-4536-ad05-13c3ee563069	2026-06-19 03:03:05.577298+00	2026-06-19 03:03:05.577298+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	172.253.7.127	\N	\N	\N	\N	\N
3c2db4f4-ed7d-430b-9274-ef08068b5efe	99321c1d-2254-4bbe-a5df-d14e52829a39	2026-06-21 09:33:29.536484+00	2026-06-21 09:33:29.536484+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	171.251.238.41	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
00000000-0000-0000-0000-000000000000	99321c1d-2254-4bbe-a5df-d14e52829a39	authenticated	authenticated	admin@htqltd.local	$2a$10$TYKRAB1yeJJrq5kxjWFQQOtnan2s7NUeafQD1NJ.haz//A1JU4Sh6	2026-05-12 06:27:35.321732+00	\N		\N		\N			\N	2026-06-21 09:33:29.53535+00	{"provider": "email", "providers": ["email"]}	{"sub": "99321c1d-2254-4bbe-a5df-d14e52829a39", "email": "admin@htqltd.local", "email_verified": true, "phone_verified": false}	\N	2026-05-12 06:27:35.298681+00	2026-06-21 09:33:29.55194+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	aa09c8ca-e8b5-48c6-8a28-533a5ec44d65	authenticated	authenticated	host_quanlythiduamoi11.huuthe87.workers.dev@system.local	$2a$10$KRaUIiZh5ok5xHOpwAEcze8ApyJOQ.0Bvx9qeU8/G2POftxYba8/S	2026-05-18 08:14:28.424765+00	\N		\N		\N			\N	2026-05-18 10:28:58.646682+00	{"provider": "email", "providers": ["email"]}	{"sub": "aa09c8ca-e8b5-48c6-8a28-533a5ec44d65", "email": "host_quanlythiduamoi11.huuthe87.workers.dev@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-18 08:14:28.385496+00	2026-05-18 10:28:58.664378+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f38b5572-029f-4d74-ac31-3d5e278df151	authenticated	authenticated	host_lehoan.vercel.app@system.local	$2a$10$yB16Hd0cA7zETjsBFz7WlOAY0wjO3bDHnQxS2fxqB0izfA/rIPYiK	2026-05-02 04:28:31.275813+00	\N		\N		\N			\N	2026-05-05 09:40:07.735438+00	{"provider": "email", "providers": ["email"]}	{"sub": "f38b5572-029f-4d74-ac31-3d5e278df151", "email": "host_lehoan.vercel.app@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-02 04:28:31.261902+00	2026-05-06 12:55:46.392806+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	964af5e8-7c20-40b1-b6ff-3a448dfc265a	authenticated	authenticated	host_localhost@system.local	$2a$10$pMAd9huPCkleB2L.W4B1qe4iAnX22NeCykLNmWGJ9j7sNvc4wx5hS	2026-05-02 04:23:38.018886+00	\N		\N		\N			\N	2026-05-02 04:23:38.138525+00	{"provider": "email", "providers": ["email"]}	{"sub": "964af5e8-7c20-40b1-b6ff-3a448dfc265a", "email": "host_localhost@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-02 04:23:38.009158+00	2026-05-02 04:23:38.140698+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b01761d2-e8bb-4bd5-9735-e8bfb8c2f411	authenticated	authenticated	host_quanlythiduaxoahk.vercel.app@system.local	$2a$10$Wno75g1x1Q7MTwibJpNNHut3tFQb.6dfPrOlN34Wy0XUzKXx4cs6O	2026-05-03 21:59:26.38049+00	\N		\N		\N			\N	2026-05-07 07:52:10.085154+00	{"provider": "email", "providers": ["email"]}	{"sub": "b01761d2-e8bb-4bd5-9735-e8bfb8c2f411", "email": "host_quanlythiduaxoahk.vercel.app@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-03 21:59:26.353236+00	2026-05-07 07:52:10.088358+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	46283390-81d3-4324-9d77-9cfd33c224bc	authenticated	authenticated	host_quanlythiduamoi1.vercel.app@system.local	$2a$10$OhDP7UunETpTsu3UUkdIZ.uoAJ2thDiw3TOLbmhBF6HNRLDyK5jl2	2026-05-12 23:34:48.83364+00	\N		\N		\N			\N	2026-05-19 00:10:26.225749+00	{"provider": "email", "providers": ["email"]}	{"sub": "46283390-81d3-4324-9d77-9cfd33c224bc", "email": "host_quanlythiduamoi1.vercel.app@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-12 23:34:48.804472+00	2026-05-19 00:10:26.248393+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	722d8397-103b-4234-8e9d-e329674e79f2	authenticated	authenticated	host_lehoan@system.local	$2a$10$pLmsJGxo8wNUMVqNObGRMe1jWNXvfna/BOoArZgxR6qmXMh9nNJh.	2026-05-18 11:05:48.806321+00	\N		\N		\N			\N	2026-05-18 11:05:49.089885+00	{"provider": "email", "providers": ["email"]}	{"sub": "722d8397-103b-4234-8e9d-e329674e79f2", "email": "host_lehoan@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-18 11:05:48.786953+00	2026-05-19 14:54:58.096146+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	dd2562d3-83c2-4544-9636-9e4809b41ea7	authenticated	authenticated	hohuuthe@htqltd.local	$2a$10$DfJ5vLZv1X6ivcea37dLtejowHFlJHY9PAZS2zShzGBOM8nyhWggW	2026-05-12 08:09:50.770219+00	\N		\N		\N			\N	2026-05-12 08:09:50.776458+00	{"provider": "email", "providers": ["email"]}	{"sub": "dd2562d3-83c2-4544-9636-9e4809b41ea7", "email": "hohuuthe@htqltd.local", "email_verified": true, "phone_verified": false}	\N	2026-05-12 08:09:50.755885+00	2026-05-12 08:09:50.780153+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	815c5ba4-df3e-470b-a277-f6e9b9c1941e	authenticated	authenticated	host_hethongquanlythiduacsdlmoi.vercel.app@system.local	$2a$10$Cqpjy5I6DgHpMQnNraFox.8lIT0IU5o7eNDoqxF9LaXakZ3vjS8.O	2026-05-09 03:51:09.739279+00	\N		\N		\N			\N	2026-05-10 02:11:13.370542+00	{"provider": "email", "providers": ["email"]}	{"sub": "815c5ba4-df3e-470b-a277-f6e9b9c1941e", "email": "host_hethongquanlythiduacsdlmoi.vercel.app@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-09 03:51:09.710336+00	2026-05-10 09:10:01.246049+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4528c17c-395c-4e97-981c-17dbe2bc8181	authenticated	authenticated	host_@system.local	$2a$10$GXX4iIRl6Kf7lIXb17XhDe0eqS2ABDvFs8JyCiBaVD7r4B8fm7/EG	2026-05-12 03:55:40.208593+00	\N		\N		\N			\N	2026-05-12 04:30:02.742421+00	{"provider": "email", "providers": ["email"]}	{"sub": "4528c17c-395c-4e97-981c-17dbe2bc8181", "email": "host_@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-12 03:55:40.190242+00	2026-05-12 04:30:02.752474+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	adea62ce-52d6-489d-82e7-362203d85c01	authenticated	authenticated	host_he-thong-quan-ly-thi-dua-csdl-moi-1.vercel.app@system.local	$2a$10$dFYF1aRA.fSFMhtrH9xkY.m4iOOo3hQ9oulMJby5lkYHO9e5/K.tm	2026-05-12 03:33:37.09747+00	\N		\N		\N			\N	2026-05-12 13:21:08.838077+00	{"provider": "email", "providers": ["email"]}	{"sub": "adea62ce-52d6-489d-82e7-362203d85c01", "email": "host_he-thong-quan-ly-thi-dua-csdl-moi-1.vercel.app@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-12 03:33:37.064575+00	2026-05-12 14:21:48.681971+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4ab940a0-686b-4685-ac38-9d5e566db113	authenticated	authenticated	host_quanlytd.vercel.app@system.local	$2a$10$7Y2HCNPdKxcxxnJHtNyztOOriEoG8SP8mIZesmDCa1CfTHCdfP4LK	2026-05-02 04:21:33.192397+00	\N		\N		\N			\N	2026-05-12 14:02:32.973146+00	{"provider": "email", "providers": ["email"]}	{"sub": "4ab940a0-686b-4685-ac38-9d5e566db113", "email": "host_quanlytd.vercel.app@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-02 04:21:33.150187+00	2026-05-12 14:02:32.981703+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a670a3d7-db76-4536-ad05-13c3ee563069	authenticated	authenticated	hethongquanlythidua_vercel_app@system.local	$2a$10$M4vKbz7NgVfeKJwSQc0s6esynPS4UkPJjqV7KooWWQed5KUsUlN2C	2026-05-21 13:31:13.3453+00	\N		\N		\N			\N	2026-06-19 03:03:05.576073+00	{"provider": "email", "providers": ["email"]}	{"sub": "a670a3d7-db76-4536-ad05-13c3ee563069", "email": "hethongquanlythidua_vercel_app@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-21 13:31:13.287143+00	2026-06-19 03:03:05.651659+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a24e2881-8767-4f08-9552-fc3376516585	authenticated	authenticated	host_htqltd.vercel.app@system.local	$2a$10$Ea1GLo0O4iHsBU/qAbFD.uLjcoNjjuP752G1iNy6hMAUMY1EG.pyO	2026-05-18 13:02:00.955652+00	\N		\N		\N			\N	2026-05-18 13:06:34.698246+00	{"provider": "email", "providers": ["email"]}	{"sub": "a24e2881-8767-4f08-9552-fc3376516585", "email": "host_htqltd.vercel.app@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-18 13:02:00.922732+00	2026-05-18 13:06:34.700459+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a3bf7198-1be3-4e4d-82a4-5de1009f5ea2	authenticated	authenticated	htqltd_vercel_app@system.local	$2a$10$MsNSLdwqBtr5WvdsgCM34OQEym.uyxuFfhpgQxZgVvHVUdwsnZKjW	2026-05-20 10:16:05.078595+00	\N		\N		\N			\N	2026-05-24 09:08:39.638299+00	{"provider": "email", "providers": ["email"]}	{"sub": "a3bf7198-1be3-4e4d-82a4-5de1009f5ea2", "email": "htqltd_vercel_app@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-20 10:16:05.050756+00	2026-06-17 14:50:02.299317+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	0b718cac-6cd9-494a-9076-e924f23783d0	authenticated	authenticated	htqltd_huuthe87_workers_dev@system.local	$2a$10$IWgR0fPWuaieEyEAqi2ybOUuRJksCT6SRM5pxMDtbKb.4TzGCd59i	2026-05-20 11:11:02.236047+00	\N		\N		\N			\N	2026-05-24 08:14:17.13783+00	{"provider": "email", "providers": ["email"]}	{"sub": "0b718cac-6cd9-494a-9076-e924f23783d0", "email": "htqltd_huuthe87_workers_dev@system.local", "email_verified": true, "phone_verified": false}	\N	2026-05-20 11:11:02.207705+00	2026-05-24 09:39:27.32548+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: danh_sach_truong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."danh_sach_truong" ("id", "domain", "ten_truong", "dia_chi_truong", "so_dien_thoai", "nguoi_quan_ly", "thoi_gian_bat_dau_su_dung", "thoi_gian_ket_thuc_su_dung", "trang_thai_kich_hoat", "supabase_url", "supabase_key", "created_at", "thong_bao", "slug") FROM stdin;
18a7e7c9-72d4-4df1-b3ba-59f69a471061	hethongquanlythidua.vercel.app	hethongquanlythidua.vercel.app	\N	\N	\N	2026-05-21 13:31:51.79922+00	2028-05-03 21:58:21.090198+00	t	https://lqvjlcjybrshbwrzeqrp.supabase.co	sb_publishable_SXzLRQeCP15j9OGX_ghD6g_Cnp2i7GV	2026-05-21 13:31:51.79922+00	\N	gioithieu2
dbbed241-eb0a-4ab2-87d4-e033cc926f3c	hethongquanlythidua.vercel.app	hethongquanlythidua.vercel.app	\N	\N	\N	2026-05-22 00:00:00+00	2027-11-20 00:00:00+00	t	https://ekmqkgzatxmixkxuxwgr.supabase.co	sb_publishable_ATtjfL3T6zurpEHOlYoaHQ_ppM6jKLG	2026-05-22 02:11:32.075372+00	\N	gioithieu
d2025742-0c5b-4922-9bb1-d6bbf7a8e401	htqltd.vercel.app	htqltd.vercel.app	\N	\N	\N	2025-05-18 12:59:22.709338+00	2036-05-02 02:52:44+00	t	https://lqvjlcjybrshbwrzeqrp.supabase.co	sb_publishable_SXzLRQeCP15j9OGX_ghD6g_Cnp2i7GV	2026-05-18 12:59:22.709338+00	\N	duphong2
2306f73f-5168-4f4b-a96e-3626cd3b24ce	htqltd.huuthe87.workers.dev	htqltd.huuthe87.workers.dev	1	1	1	2026-05-20 00:00:00+00	2026-10-17 00:00:00+00	t	https://olxebyzmyddwtwxzhire.supabase.co	sb_publishable_vMokUKGEmQb3SLclCyrMNw_yUfE3t-I	2026-05-20 09:42:01.016694+00	HETHONGQUANLYTHIDUA_CSDL_MOI	chinhthuc1
fb2ae88f-d724-47fb-94e8-2631510fc38d	htqltd.vercel.app	htqltd.vercel.app	\N	\N	\N	2026-05-18 14:01:05.610916+00	2036-05-02 02:52:44+00	t	https://olxebyzmyddwtwxzhire.supabase.co	sb_publishable_vMokUKGEmQb3SLclCyrMNw_yUfE3t-I	2026-05-18 14:01:05.610916+00	HETHONGQUANLYTHIDUA_CSDL_MOI\r\n	chinhthuc2
cbd5968c-0aa3-4b00-9b98-9fcfc7755304	htqltd.huuthe87.workers.dev	htqltd.huuthe87.workers.dev	123	123	123	2026-05-03 21:58:21.090198+00	2036-05-02 02:52:44+00	t	https://lqvjlcjybrshbwrzeqrp.supabase.co	sb_publishable_SXzLRQeCP15j9OGX_ghD6g_Cnp2i7GV	2026-05-03 21:58:21.090198+00	HETHONGQUANLYTHIDUA_CSDL_MOI1	duphong1
\.


--
-- Data for Name: dia_chi_truy_cap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."dia_chi_truy_cap" ("id", "domain", "ten_truong_so_huu", "created_at") FROM stdin;
0c135dbb-f0ee-4efd-b339-17ad7d1227a7	htqltd.huuthe87.workers.dev	\N	2026-05-20 09:39:43.614334+00
cb8ae734-2974-4438-952e-2cb345fce933	htqltd.vercel.app	htqltd.vercel.app	2026-05-18 13:01:41.242126+00
3d566e7e-6911-4466-a360-22a8bd1afa48	hethongquanlythidua.vercel.app	hethongquanlythidua.vercel.app	2026-05-21 13:31:04.851674+00
\.


--
-- Data for Name: duytricsdl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."duytricsdl" ("id", "so", "thoigian") FROM stdin;
d5cd77e2-2f36-422d-89fe-c564b58efb8a	1	2026-05-01 07:36:06.449035+00
\.


--
-- Data for Name: tai_khoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tai_khoan" ("id", "ten_dang_nhap", "mat_khau", "ho_ten", "vai_tro", "trang_thai_kich_hoat", "created_at") FROM stdin;
3125619d-2d1f-44cf-9c89-75e02f829322	admin	$2a$06$zjW3cpxeOvaVFUCO8QinxONtptDABeclAM5saqaY86zOdacEb01IC	Quản trị viên tối cao	Admin	t	2026-05-12 08:03:51.421008+00
3879ea6d-1e4a-484b-8da0-86f1601204c9	hohuuthe	$2a$06$x/PMsv7eUynl0viDwxjq5u2XB4ssOYGe5PvM2YX8XZYHoBxAx9Twq	Hồ Hữu Thế	Admin	t	2026-05-12 08:08:53.679341+00
\.


--
-- Data for Name: messages_2026_05_01; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_01" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_02; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_02" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_03; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_03" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_04; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_04" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_05; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_05" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."schema_migrations" ("version", "inserted_at") FROM stdin;
20211116024918	2026-05-01 02:19:31
20211116045059	2026-05-01 02:19:31
20211116050929	2026-05-01 02:19:31
20211116051442	2026-05-01 02:19:31
20211116212300	2026-05-01 02:19:31
20211116213355	2026-05-01 02:19:31
20211116213934	2026-05-01 02:19:31
20211116214523	2026-05-01 02:19:31
20211122062447	2026-05-01 02:19:31
20211124070109	2026-05-01 02:19:31
20211202204204	2026-05-01 02:19:31
20211202204605	2026-05-01 02:19:31
20211210212804	2026-05-01 02:19:31
20211228014915	2026-05-01 02:19:31
20220107221237	2026-05-01 02:19:31
20220228202821	2026-05-01 02:19:31
20220312004840	2026-05-01 02:19:31
20220603231003	2026-05-01 02:19:31
20220603232444	2026-05-01 02:19:31
20220615214548	2026-05-01 02:19:31
20220712093339	2026-05-01 02:19:31
20220908172859	2026-05-01 02:19:31
20220916233421	2026-05-01 02:19:31
20230119133233	2026-05-01 02:19:31
20230128025114	2026-05-01 02:19:31
20230128025212	2026-05-01 02:19:31
20230227211149	2026-05-01 02:19:31
20230228184745	2026-05-01 02:19:31
20230308225145	2026-05-01 02:19:31
20230328144023	2026-05-01 02:19:31
20231018144023	2026-05-01 02:19:31
20231204144023	2026-05-01 02:19:31
20231204144024	2026-05-01 02:19:31
20231204144025	2026-05-01 02:19:31
20240108234812	2026-05-01 02:19:31
20240109165339	2026-05-01 02:19:31
20240227174441	2026-05-01 02:19:31
20240311171622	2026-05-01 02:19:31
20240321100241	2026-05-01 02:19:31
20240401105812	2026-05-01 02:19:31
20240418121054	2026-05-01 02:19:44
20240523004032	2026-05-01 02:19:44
20240618124746	2026-05-01 02:19:44
20240801235015	2026-05-01 02:19:44
20240805133720	2026-05-01 02:19:44
20240827160934	2026-05-01 02:19:44
20240919163303	2026-05-01 02:19:44
20240919163305	2026-05-01 02:19:44
20241019105805	2026-05-01 02:19:44
20241030150047	2026-05-01 02:19:44
20241108114728	2026-05-01 02:19:44
20241121104152	2026-05-01 02:19:44
20241130184212	2026-05-01 02:19:44
20241220035512	2026-05-01 02:19:44
20241220123912	2026-05-01 02:19:44
20241224161212	2026-05-01 02:19:44
20250107150512	2026-05-01 02:19:44
20250110162412	2026-05-01 02:19:44
20250123174212	2026-05-01 02:19:44
20250128220012	2026-05-01 02:19:44
20250506224012	2026-05-01 02:19:44
20250523164012	2026-05-01 02:19:44
20250714121412	2026-05-01 02:19:44
20250905041441	2026-05-01 02:19:44
20251103001201	2026-05-01 02:19:44
20251120212548	2026-05-01 02:19:44
20251120215549	2026-05-01 02:19:44
20260218120000	2026-05-01 02:19:44
20260326120000	2026-05-01 02:19:44
20260514120000	2026-06-21 06:17:03
20260527120000	2026-06-21 06:17:03
20260528120000	2026-06-21 06:17:03
20260603120000	2026-06-21 06:17:03
20260605120000	2026-06-21 06:17:03
20260606110000	2026-06-21 06:17:03
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."subscription" ("id", "subscription_id", "entity", "filters", "claims", "created_at", "action_filter", "selected_columns") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."migrations" ("id", "name", "hash", "executed_at") FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-05-01 02:20:09.17961
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-05-01 02:20:09.198298
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-05-01 02:20:09.202582
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-05-01 02:20:09.219831
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-05-01 02:20:09.230801
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-05-01 02:20:09.235611
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-05-01 02:20:09.24088
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-05-01 02:20:09.246176
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-05-01 02:20:09.251106
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-05-01 02:20:09.256274
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-05-01 02:20:09.261328
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-05-01 02:20:09.266246
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-05-01 02:20:09.272302
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-05-01 02:20:09.277368
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-05-01 02:20:09.282293
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-05-01 02:20:09.305222
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-05-01 02:20:09.310018
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-05-01 02:20:09.314677
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-05-01 02:20:09.319325
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-05-01 02:20:09.325499
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-05-01 02:20:09.330065
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-05-01 02:20:09.336216
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-05-01 02:20:09.35009
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-05-01 02:20:09.360085
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-05-01 02:20:09.364816
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-05-01 02:20:09.369656
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-05-01 02:20:09.374467
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-05-01 02:20:09.378829
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-05-01 02:20:09.38312
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-05-01 02:20:09.387334
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-05-01 02:20:09.391577
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-05-01 02:20:09.395977
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-05-01 02:20:09.400194
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-05-01 02:20:09.404483
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-05-01 02:20:09.408699
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-05-01 02:20:09.412913
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-05-01 02:20:09.417204
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-05-01 02:20:09.421561
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-05-01 02:20:09.426654
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-05-01 02:20:09.437645
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-05-01 02:20:09.441723
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-05-01 02:20:09.446135
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-05-01 02:20:09.451358
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-05-01 02:20:09.455748
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-05-01 02:20:09.459929
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-05-01 02:20:09.46663
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-05-01 02:20:09.482722
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-05-01 02:20:09.487333
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-05-01 02:20:09.491712
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-05-01 02:20:09.508418
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-05-01 02:20:09.513225
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-05-01 02:20:09.600339
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-05-01 02:20:09.602489
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-05-01 02:20:09.612807
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-05-01 02:20:09.61591
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-05-01 02:20:09.617737
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-05-01 02:20:09.628542
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-05-01 02:20:09.633146
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-05-01 02:20:09.623011
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-05-09 03:49:49.065872
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-05-09 03:49:49.077451
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY "vault"."secrets" ("id", "name", "description", "secret", "key_id", "nonce", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 619, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('"realtime"."subscription_id_seq"', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "amr_id_pk" PRIMARY KEY ("id");


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_identifier_key" UNIQUE ("identifier");


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_pkey" PRIMARY KEY ("id");


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."flow_state"
    ADD CONSTRAINT "flow_state_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_provider_id_provider_unique" UNIQUE ("provider_id", "provider");


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_authentication_method_pkey" UNIQUE ("session_id", "authentication_method");


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_last_challenged_at_key" UNIQUE ("last_challenged_at");


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_code_key" UNIQUE ("authorization_code");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_id_key" UNIQUE ("authorization_id");


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_client_states"
    ADD CONSTRAINT "oauth_client_states_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_clients"
    ADD CONSTRAINT "oauth_clients_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_client_unique" UNIQUE ("user_id", "client_id");


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_entity_id_key" UNIQUE ("entity_id");


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_pkey" PRIMARY KEY ("id");


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_pkey" PRIMARY KEY ("id");


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_providers"
    ADD CONSTRAINT "sso_providers_pkey" PRIMARY KEY ("id");


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_pkey" PRIMARY KEY ("id");


--
-- Name: danh_sach_truong danh_sach_truong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."danh_sach_truong"
    ADD CONSTRAINT "danh_sach_truong_pkey" PRIMARY KEY ("id");


--
-- Name: danh_sach_truong danh_sach_truong_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."danh_sach_truong"
    ADD CONSTRAINT "danh_sach_truong_slug_key" UNIQUE ("slug");


--
-- Name: dia_chi_truy_cap dia_chi_truy_cap_domain_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dia_chi_truy_cap"
    ADD CONSTRAINT "dia_chi_truy_cap_domain_key" UNIQUE ("domain");


--
-- Name: dia_chi_truy_cap dia_chi_truy_cap_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dia_chi_truy_cap"
    ADD CONSTRAINT "dia_chi_truy_cap_pkey" PRIMARY KEY ("id");


--
-- Name: duytricsdl duytricsdl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."duytricsdl"
    ADD CONSTRAINT "duytricsdl_pkey" PRIMARY KEY ("id");


--
-- Name: tai_khoan tai_khoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tai_khoan"
    ADD CONSTRAINT "tai_khoan_pkey" PRIMARY KEY ("id");


--
-- Name: tai_khoan tai_khoan_ten_dang_nhap_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tai_khoan"
    ADD CONSTRAINT "tai_khoan_ten_dang_nhap_key" UNIQUE ("ten_dang_nhap");


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages"
    ADD CONSTRAINT "messages_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_01 messages_2026_05_01_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_01"
    ADD CONSTRAINT "messages_2026_05_01_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_02 messages_2026_05_02_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_02"
    ADD CONSTRAINT "messages_2026_05_02_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_03 messages_2026_05_03_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_03"
    ADD CONSTRAINT "messages_2026_05_03_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_04 messages_2026_05_04_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_04"
    ADD CONSTRAINT "messages_2026_05_04_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_05 messages_2026_05_05_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_05"
    ADD CONSTRAINT "messages_2026_05_05_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages"
    ADD CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL))) NOT VALID;


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."subscription"
    ADD CONSTRAINT "pk_subscription" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_analytics"
    ADD CONSTRAINT "buckets_analytics_pkey" PRIMARY KEY ("id");


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_vectors"
    ADD CONSTRAINT "buckets_vectors_pkey" PRIMARY KEY ("id");


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_pkey" PRIMARY KEY ("id");


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_created_at_idx" ON "auth"."custom_oauth_providers" USING "btree" ("created_at");


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_enabled_idx" ON "auth"."custom_oauth_providers" USING "btree" ("enabled");


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_identifier_idx" ON "auth"."custom_oauth_providers" USING "btree" ("identifier");


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_provider_type_idx" ON "auth"."custom_oauth_providers" USING "btree" ("provider_type");


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "factor_id_created_at_idx" ON "auth"."mfa_factors" USING "btree" ("user_id", "created_at");


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "flow_state_created_at_idx" ON "auth"."flow_state" USING "btree" ("created_at" DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_email_idx" ON "auth"."identities" USING "btree" ("email" "text_pattern_ops");


--
-- Name: INDEX "identities_email_idx"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."identities_email_idx" IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_auth_code" ON "auth"."flow_state" USING "btree" ("auth_code");


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_oauth_client_states_created_at" ON "auth"."oauth_client_states" USING "btree" ("created_at");


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_user_id_auth_method" ON "auth"."flow_state" USING "btree" ("user_id", "authentication_method");


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_created_at_desc" ON "auth"."users" USING "btree" ("created_at" DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_email" ON "auth"."users" USING "btree" ("email");


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_last_sign_in_at_desc" ON "auth"."users" USING "btree" ("last_sign_in_at" DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_name" ON "auth"."users" USING "btree" ((("raw_user_meta_data" ->> 'name'::"text"))) WHERE (("raw_user_meta_data" ->> 'name'::"text") IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_challenge_created_at_idx" ON "auth"."mfa_challenges" USING "btree" ("created_at" DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "mfa_factors_user_friendly_name_unique" ON "auth"."mfa_factors" USING "btree" ("friendly_name", "user_id") WHERE (TRIM(BOTH FROM "friendly_name") <> ''::"text");


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_factors_user_id_idx" ON "auth"."mfa_factors" USING "btree" ("user_id");


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_auth_pending_exp_idx" ON "auth"."oauth_authorizations" USING "btree" ("expires_at") WHERE ("status" = 'pending'::"auth"."oauth_authorization_status");


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_clients_deleted_at_idx" ON "auth"."oauth_clients" USING "btree" ("deleted_at");


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_client_idx" ON "auth"."oauth_consents" USING "btree" ("client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_user_client_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_user_order_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "granted_at" DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_relates_to_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("relates_to");


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_token_hash_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("token_hash");


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "one_time_tokens_user_id_token_type_key" ON "auth"."one_time_tokens" USING "btree" ("user_id", "token_type");


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_session_id_revoked_idx" ON "auth"."refresh_tokens" USING "btree" ("session_id", "revoked");


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_updated_at_idx" ON "auth"."refresh_tokens" USING "btree" ("updated_at" DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_providers_sso_provider_id_idx" ON "auth"."saml_providers" USING "btree" ("sso_provider_id");


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_created_at_idx" ON "auth"."saml_relay_states" USING "btree" ("created_at" DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_for_email_idx" ON "auth"."saml_relay_states" USING "btree" ("for_email");


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_sso_provider_id_idx" ON "auth"."saml_relay_states" USING "btree" ("sso_provider_id");


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_not_after_idx" ON "auth"."sessions" USING "btree" ("not_after" DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_oauth_client_id_idx" ON "auth"."sessions" USING "btree" ("oauth_client_id");


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_user_id_idx" ON "auth"."sessions" USING "btree" ("user_id");


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_domains_domain_idx" ON "auth"."sso_domains" USING "btree" ("lower"("domain"));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_domains_sso_provider_id_idx" ON "auth"."sso_domains" USING "btree" ("sso_provider_id");


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_providers_resource_id_idx" ON "auth"."sso_providers" USING "btree" ("lower"("resource_id"));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_providers_resource_id_pattern_idx" ON "auth"."sso_providers" USING "btree" ("resource_id" "text_pattern_ops");


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "unique_phone_factor_per_user" ON "auth"."mfa_factors" USING "btree" ("user_id", "phone");


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "user_id_created_at_idx" ON "auth"."sessions" USING "btree" ("user_id", "created_at");


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "users_email_partial_key" ON "auth"."users" USING "btree" ("email") WHERE ("is_sso_user" = false);


--
-- Name: INDEX "users_email_partial_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."users_email_partial_key" IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_is_anonymous_idx" ON "auth"."users" USING "btree" ("is_anonymous");


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_expires_at_idx" ON "auth"."webauthn_challenges" USING "btree" ("expires_at");


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_user_id_idx" ON "auth"."webauthn_challenges" USING "btree" ("user_id");


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "webauthn_credentials_credential_id_key" ON "auth"."webauthn_credentials" USING "btree" ("credential_id");


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_credentials_user_id_idx" ON "auth"."webauthn_credentials" USING "btree" ("user_id");


--
-- Name: idx_danh_sach_truong_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_danh_sach_truong_domain" ON "public"."danh_sach_truong" USING "btree" ("domain");


--
-- Name: idx_danh_sach_truong_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_danh_sach_truong_slug" ON "public"."danh_sach_truong" USING "btree" ("slug");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "ix_realtime_subscription_entity" ON "realtime"."subscription" USING "btree" ("entity");


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_inserted_at_topic_index" ON ONLY "realtime"."messages" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_01_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_01_inserted_at_topic_idx" ON "realtime"."messages_2026_05_01" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_02_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_02_inserted_at_topic_idx" ON "realtime"."messages_2026_05_02" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_03_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_03_inserted_at_topic_idx" ON "realtime"."messages_2026_05_03" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_04_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_04_inserted_at_topic_idx" ON "realtime"."messages_2026_05_04" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_05_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_05_inserted_at_topic_idx" ON "realtime"."messages_2026_05_05" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX "subscription_subscription_id_entity_filters_action_filter_selec" ON "realtime"."subscription" USING "btree" ("subscription_id", "entity", "filters", "action_filter", COALESCE("selected_columns", '{}'::"text"[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "buckets_analytics_unique_name_idx" ON "storage"."buckets_analytics" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_multipart_uploads_list" ON "storage"."s3_multipart_uploads" USING "btree" ("bucket_id", "key", "created_at");


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name" ON "storage"."objects" USING "btree" ("bucket_id", "name" COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name_lower" ON "storage"."objects" USING "btree" ("bucket_id", "lower"("name") COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "vector_indexes_name_bucket_id_idx" ON "storage"."vector_indexes" USING "btree" ("name", "bucket_id");


--
-- Name: messages_2026_05_01_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_01_inserted_at_topic_idx";


--
-- Name: messages_2026_05_01_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_01_pkey";


--
-- Name: messages_2026_05_02_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_02_inserted_at_topic_idx";


--
-- Name: messages_2026_05_02_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_02_pkey";


--
-- Name: messages_2026_05_03_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_03_inserted_at_topic_idx";


--
-- Name: messages_2026_05_03_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_03_pkey";


--
-- Name: messages_2026_05_04_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_04_inserted_at_topic_idx";


--
-- Name: messages_2026_05_04_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_04_pkey";


--
-- Name: messages_2026_05_05_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_05_inserted_at_topic_idx";


--
-- Name: messages_2026_05_05_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_05_pkey";


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER "tr_check_filters" BEFORE INSERT OR UPDATE ON "realtime"."subscription" FOR EACH ROW EXECUTE FUNCTION "realtime"."subscription_check_filters"();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "enforce_bucket_name_length_trigger" BEFORE INSERT OR UPDATE OF "name" ON "storage"."buckets" FOR EACH ROW EXECUTE FUNCTION "storage"."enforce_bucket_name_length"();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_buckets_delete" BEFORE DELETE ON "storage"."buckets" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_objects_delete" BEFORE DELETE ON "storage"."objects" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "update_objects_updated_at" BEFORE UPDATE ON "storage"."objects" FOR EACH ROW EXECUTE FUNCTION "storage"."update_updated_at_column"();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_auth_factor_id_fkey" FOREIGN KEY ("factor_id") REFERENCES "auth"."mfa_factors"("id") ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_flow_state_id_fkey" FOREIGN KEY ("flow_state_id") REFERENCES "auth"."flow_state"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_oauth_client_id_fkey" FOREIGN KEY ("oauth_client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_upload_id_fkey" FOREIGN KEY ("upload_id") REFERENCES "storage"."s3_multipart_uploads"("id") ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets_vectors"("id");


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."audit_log_entries" ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."flow_state" ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."identities" ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."instances" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_amr_claims" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_challenges" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_factors" ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."one_time_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."refresh_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_relay_states" ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."schema_migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sessions" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_domains" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."users" ENABLE ROW LEVEL SECURITY;

--
-- Name: tai_khoan Cho phép tài khoản đăng nhập sửa dữ liệu; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép tài khoản đăng nhập sửa dữ liệu" ON "public"."tai_khoan" FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: tai_khoan Cho phép tài khoản đăng nhập thêm dữ liệu; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép tài khoản đăng nhập thêm dữ liệu" ON "public"."tai_khoan" FOR INSERT TO "authenticated" WITH CHECK (true);


--
-- Name: danh_sach_truong Cho phép tài khoản đăng nhập toàn quyền trên danh_s; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép tài khoản đăng nhập toàn quyền trên danh_s" ON "public"."danh_sach_truong" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: dia_chi_truy_cap Cho phép tài khoản đăng nhập toàn quyền trên dia_ch; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép tài khoản đăng nhập toàn quyền trên dia_ch" ON "public"."dia_chi_truy_cap" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: tai_khoan Cho phép tài khoản đăng nhập xem dữ liệu; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép tài khoản đăng nhập xem dữ liệu" ON "public"."tai_khoan" FOR SELECT TO "authenticated" USING (true);


--
-- Name: tai_khoan Cho phép tài khoản đăng nhập xóa dữ liệu; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép tài khoản đăng nhập xóa dữ liệu" ON "public"."tai_khoan" FOR DELETE TO "authenticated" USING (true);


--
-- Name: dia_chi_truy_cap Cho phép đọc tên miền hợp lệ; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép đọc tên miền hợp lệ" ON "public"."dia_chi_truy_cap" FOR SELECT USING (true);


--
-- Name: danh_sach_truong Chỉ tài khoản đăng nhập mới được xem danh sách ; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ tài khoản đăng nhập mới được xem danh sách " ON "public"."danh_sach_truong" FOR SELECT TO "authenticated" USING (true);


--
-- Name: danh_sach_truong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."danh_sach_truong" ENABLE ROW LEVEL SECURITY;

--
-- Name: dia_chi_truy_cap; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."dia_chi_truy_cap" ENABLE ROW LEVEL SECURITY;

--
-- Name: tai_khoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tai_khoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_analytics" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_vectors" ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads_parts" ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."vector_indexes" ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: supabase_admin
--

CREATE PUBLICATION "supabase_realtime_messages_publication" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime_messages_publication" OWNER TO "supabase_admin";

--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: supabase_admin
--

ALTER PUBLICATION "supabase_realtime_messages_publication" ADD TABLE ONLY "realtime"."messages";


--
-- Name: SCHEMA "auth"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT USAGE ON SCHEMA "auth" TO "postgres";


--
-- Name: SCHEMA "extensions"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "extensions" TO "anon";
GRANT USAGE ON SCHEMA "extensions" TO "authenticated";
GRANT USAGE ON SCHEMA "extensions" TO "service_role";
GRANT ALL ON SCHEMA "extensions" TO "dashboard_user";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";


--
-- Name: SCHEMA "realtime"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "realtime" TO "postgres";
GRANT USAGE ON SCHEMA "realtime" TO "anon";
GRANT USAGE ON SCHEMA "realtime" TO "authenticated";
GRANT USAGE ON SCHEMA "realtime" TO "service_role";
GRANT ALL ON SCHEMA "realtime" TO "supabase_realtime_admin";


--
-- Name: SCHEMA "storage"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "storage" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";


--
-- Name: SCHEMA "vault"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "vault" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "vault" TO "service_role";


--
-- Name: FUNCTION "email"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";


--
-- Name: FUNCTION "jwt"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";


--
-- Name: FUNCTION "role"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";


--
-- Name: FUNCTION "uid"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."armor"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea", "text"[], "text"[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "dashboard_user";


--
-- Name: FUNCTION "crypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."crypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "dearmor"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."dearmor"("text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."digest"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."digest"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_bytes"(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_uuid"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_random_uuid"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text", integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text", integer) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_cron_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."grant_pg_graphql_access"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "grant_pg_net_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_net_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_key_id"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgrst_ddl_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_ddl_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgrst_drop_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_drop_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."set_graphql_placeholder"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "uuid_generate_v1"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v1mc"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v3"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v4"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v4"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v5"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_nil"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_nil"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_dns"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_dns"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_oid"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_oid"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_url"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_url"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_x500"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_x500"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "dashboard_user";


--
-- Name: FUNCTION "graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb"); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "pg_reload_conf"(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "pg_catalog"."pg_reload_conf"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "get_auth"("p_usename" "text"); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") TO "pgbouncer";


--
-- Name: FUNCTION "hash_password"("p_password" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."hash_password"("p_password" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."hash_password"("p_password" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."hash_password"("p_password" "text") TO "service_role";


--
-- Name: FUNCTION "rls_auto_enable"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rls_auto_enable"() TO "anon";
GRANT ALL ON FUNCTION "public"."rls_auto_enable"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."rls_auto_enable"() TO "service_role";


--
-- Name: FUNCTION "verify_custom_login"("p_username" "text", "p_password" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."verify_custom_login"("p_username" "text", "p_password" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."verify_custom_login"("p_username" "text", "p_password" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."verify_custom_login"("p_username" "text", "p_password" "text") TO "service_role";


--
-- Name: FUNCTION "apply_rls"("wal" "jsonb", "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "anon";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "dashboard_user";


--
-- Name: FUNCTION "build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "cast"("val" "text", "type_" "regtype"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "anon";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "dashboard_user";


--
-- Name: FUNCTION "quote_wal2json"("entity" "regclass"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "anon";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "subscription_check_filters"(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "anon";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "service_role";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "supabase_realtime_admin";


--
-- Name: FUNCTION "to_regrole"("role_name" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "topic"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."topic"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."topic"() TO "dashboard_user";


--
-- Name: FUNCTION "wal2json_escape_identifier"("name" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";


--
-- Name: FUNCTION "create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";


--
-- Name: FUNCTION "update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";


--
-- Name: TABLE "audit_log_entries"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."audit_log_entries" TO "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "custom_oauth_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "postgres";
GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "dashboard_user";


--
-- Name: TABLE "flow_state"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."flow_state" TO "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."flow_state" TO "dashboard_user";


--
-- Name: TABLE "identities"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."identities" TO "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";


--
-- Name: TABLE "instances"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."instances" TO "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "mfa_amr_claims"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_amr_claims" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";


--
-- Name: TABLE "mfa_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_challenges" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_challenges" TO "dashboard_user";


--
-- Name: TABLE "mfa_factors"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_factors" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_factors" TO "dashboard_user";


--
-- Name: TABLE "oauth_authorizations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "dashboard_user";


--
-- Name: TABLE "oauth_client_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_client_states" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_client_states" TO "dashboard_user";


--
-- Name: TABLE "oauth_clients"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_clients" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_clients" TO "dashboard_user";


--
-- Name: TABLE "oauth_consents"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_consents" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_consents" TO "dashboard_user";


--
-- Name: TABLE "one_time_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."one_time_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."one_time_tokens" TO "dashboard_user";


--
-- Name: TABLE "refresh_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."refresh_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "postgres" WITH GRANT OPTION;


--
-- Name: SEQUENCE "refresh_tokens_id_seq"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";


--
-- Name: TABLE "saml_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_providers" TO "dashboard_user";


--
-- Name: TABLE "saml_relay_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_relay_states" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_relay_states" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE "auth"."schema_migrations" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "sessions"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sessions" TO "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sessions" TO "dashboard_user";


--
-- Name: TABLE "sso_domains"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_domains" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_domains" TO "dashboard_user";


--
-- Name: TABLE "sso_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_providers" TO "dashboard_user";


--
-- Name: TABLE "users"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."users" TO "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "webauthn_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "dashboard_user";


--
-- Name: TABLE "webauthn_credentials"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE "extensions"."pg_stat_statements" FROM "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements_info"; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE "extensions"."pg_stat_statements_info" FROM "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "dashboard_user";


--
-- Name: TABLE "danh_sach_truong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."danh_sach_truong" TO "anon";
GRANT ALL ON TABLE "public"."danh_sach_truong" TO "authenticated";
GRANT ALL ON TABLE "public"."danh_sach_truong" TO "service_role";


--
-- Name: TABLE "dia_chi_truy_cap"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."dia_chi_truy_cap" TO "anon";
GRANT ALL ON TABLE "public"."dia_chi_truy_cap" TO "authenticated";
GRANT ALL ON TABLE "public"."dia_chi_truy_cap" TO "service_role";


--
-- Name: TABLE "duytricsdl"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."duytricsdl" TO "anon";
GRANT ALL ON TABLE "public"."duytricsdl" TO "authenticated";
GRANT ALL ON TABLE "public"."duytricsdl" TO "service_role";


--
-- Name: TABLE "tai_khoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tai_khoan" TO "anon";
GRANT ALL ON TABLE "public"."tai_khoan" TO "authenticated";
GRANT ALL ON TABLE "public"."tai_khoan" TO "service_role";


--
-- Name: TABLE "messages"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages" TO "dashboard_user";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "anon";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "authenticated";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "service_role";


--
-- Name: TABLE "messages_2026_05_01"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_01" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_01" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_02"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_02" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_02" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_03"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_03" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_03" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_04"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_04" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_04" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_05"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_05" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_05" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."schema_migrations" TO "postgres";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "anon";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "service_role";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "supabase_realtime_admin";


--
-- Name: TABLE "subscription"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."subscription" TO "postgres";
GRANT ALL ON TABLE "realtime"."subscription" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."subscription" TO "anon";
GRANT SELECT ON TABLE "realtime"."subscription" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."subscription" TO "service_role";
GRANT ALL ON TABLE "realtime"."subscription" TO "supabase_realtime_admin";


--
-- Name: SEQUENCE "subscription_id_seq"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "dashboard_user";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "anon";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "authenticated";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "service_role";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "supabase_realtime_admin";


--
-- Name: TABLE "buckets"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."buckets" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "buckets_analytics"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."buckets_analytics" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "anon";


--
-- Name: TABLE "buckets_vectors"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "service_role";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "authenticated";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "anon";


--
-- Name: TABLE "objects"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."objects" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "s3_multipart_uploads"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "anon";


--
-- Name: TABLE "s3_multipart_uploads_parts"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads_parts" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "anon";


--
-- Name: TABLE "vector_indexes"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."vector_indexes" TO "service_role";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "authenticated";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "anon";


--
-- Name: TABLE "secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";


--
-- Name: TABLE "decrypted_secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."decrypted_secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON SEQUENCES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON FUNCTIONS TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON TABLES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "service_role";


--
-- Name: ensure_rls; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER "ensure_rls" ON "ddl_command_end"
         WHEN TAG IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
   EXECUTE FUNCTION "public"."rls_auto_enable"();


ALTER EVENT TRIGGER "ensure_rls" OWNER TO "postgres";

--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_net_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_net_access"();


ALTER EVENT TRIGGER "issue_pg_net_access" OWNER TO "supabase_admin";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
   EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
   EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

\unrestrict 2DAufPS12b0sE2uWrkKeEeNIxZdYpGje7ARnbrHMbOmBgM9nwcm8ET6vFpFVbua

